package examples.recursion;

public final class RecursionExamples{
	
	private RecursionExamples(){
		// TODO Auto-generated constructor stub
	}

	/**
	 * generate factorial values using recursive algorithm
	 * @param num - starting number of algorithm
	 * @return final answer of num!
	 */
	public static int factorialR( int num){
		// base case, when to stop and return
		if( num <= 0){
			return 1;
		}
		return num * factorialR( num - 1);
		// below is one liner of above
		// return num<=0?1:num * factorialR(num-1);
	}

	/**
	 * generate factorial values using iterative algorithm
	 * @param num - starting number of algorithm
	 * @return final answer of num!
	 */
	public static int factorialI( int num){
		int factorial = 1;
		for( int i = num; i > 0; i--){
			factorial *= i;
		}
		return factorial;
	}

	/**
	 * generate fibonacci values using recursive algorithm
	 * @param num - starting number of algorithm
	 * @return final answer of fibonacci formula
	 */
	public static int fibonacciR( int num){
		// base case, when to stop and return
		if( num <= 1){
			return num;
		}
		return fibonacciR( num - 1) + fibonacciR( num - 2);
		// below is one liner of above
		// return num<=1?num:fibonacciR(num - 1) + fibonacciR(num - 2);
	}

	/**
	 * generate fibonacci values using iterative algorithm
	 * @param num - starting number of algorithm
	 * @return final answer of fibonacci formula
	 */
	public static int fibonacciI( int num){
		if( num <= 1){
			return num;
		}
		int fib = 1;
		int prevFib = 1;
		int temp;

		for( int i = 2; i < num; i++){
			temp = fib;
			fib += prevFib;
			prevFib = temp;
		}
		return fib;
	}

	/**
	 * find the Greatest Common Divisor between to given number using recursive algorithm
	 * @param num1 - first number
	 * @param num2 - second number
	 * @return Greatest Common Divisor
	 */
	public static int gcdR( int num1, int num2){
		// base case, when to stop and return
		if( num2 == 0){
			return num1;
		}
		return gcdR( num2, num1 % num2);
		// below is one liner of above
		// return num2 == 0?num1:gcdR(num2, num1 % num2);
	}

	/**
	 * find the Greatest Common Divisor between to given number using iterative algorithm
	 * @param num1 - first number
	 * @param num2 - second number
	 * @return Greatest Common Divisor
	 */
	public static int gcdI( int num1, int num2){
		while( num2 != 0){
			int temp = num2;
			num2 = num1 % num2;
			num1 = temp;
		}
		return num1;
	}
}
