package examples.recursion;

import javafx.application.Application;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.TableView;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TableColumn;

/**
 * 
 * @author Shahriar (Shawn) Emami
 * @version Jan 30, 2018
 * 
 * @see <a href="http://www.toves.org/books/java/ch18-recurex/"> Factorial, Fibonacci and other examples</a>
 * @see <a href="http://introcs.cs.princeton.edu/java/23recursion/"> Factorial, Fibonacci, gcd and other examples</a>
 * @see <a href="https://gist.github.com/meghakrishnamurthy/331bd9addab3dbb1b6a23802b1c6845e"> Fibonacci Iterative</a>
 */
public class RecursiveMathApplication extends Application{

	private static final String[] NAMES = { "Factorial R.", "Factorial I.", "Fibonacci R.", "Fibonacci I.", "G.C.D R.", "G.C.D I." };
	private static final int ROW_COUNT = 20;

	private ObservableList< int[]> list;

	@Override
	public void init() throws Exception{
		super.init();
		list = FXCollections.observableArrayList();
		for( int i = 0; i < ROW_COUNT; i++){
			list.add( new int[] {
					RecursionExamples.factorialR( i), RecursionExamples.factorialI( i),
					RecursionExamples.fibonacciR( i), RecursionExamples.fibonacciI( i),
					RecursionExamples.gcdR( i, i * i), RecursionExamples.gcdI( i, i * i) });
		}
	}

	@Override
	public void start( Stage primaryStage) throws Exception{

		// create a table with an observable list and set columns to fit width
		TableView< int[]> table = new TableView<>();
		table.setItems( list);
		table.setColumnResizePolicy( TableView.CONSTRAINED_RESIZE_POLICY);

		// create all columns and add them to table
		for( int i = 0; i < NAMES.length; i++){
			TableColumn< int[], Number> col = new TableColumn<>( NAMES[i]);
			// col.setMinWidth(85);
			final int colIndex = i;
			// connect each cell to a cell in list
			col.setCellValueFactory( param -> {
				return new SimpleIntegerProperty( param.getValue()[colIndex]);
			});
			table.getColumns().add( col);
		}
		// same as the lambda inside of the for loop above
		// setCellValueFactory( new Callback< CellDataFeatures< int[], Number>, ObservableValue< Number>>(){
		// @Override
		// public ObservableValue< Number> call( CellDataFeatures< int[], Number> param){
		// return new SimpleIntegerProperty( param.getValue()[colIndex]);
		// }
		// });

		// create a layout an add table
		BorderPane bpTable = new BorderPane();
		bpTable.setCenter( table);

		// create JavaFX popup window with table inside
		Alert alert = new Alert( AlertType.INFORMATION);
		alert.setTitle( "Recursion Data");
		alert.setHeaderText( "Running Factorial, Fibonacci and Greatest Common Divisor (G.C.D)");
		// alert.setContentText( "I have a great message for you!");
		alert.getDialogPane().setContent( bpTable);
		alert.show();
	}

	@Override
	public void stop() throws Exception{
		super.stop();
	}

	public static void main( String[] args){
		launch( args);
	}
}
