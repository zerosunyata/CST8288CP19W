package examples.recursion;

import java.util.Arrays;

import com.sun.javafx.application.PlatformImpl;

import javafx.application.Platform;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.TableView;
import javafx.scene.layout.BorderPane;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TableColumn;

/**
 * 
 * @author Shahriar (Shawn) Emami
 * @version Jan 30, 2018
 * 
 * @see <a href="http://www.toves.org/books/java/ch18-recurex/"> Factorial, Fibonacci and other examples</a>
 * @see <a href="http://introcs.cs.princeton.edu/java/23recursion/"> Factorial, Fibonacci, gcd and other examples</a>
 * @see <a href="https://gist.github.com/meghakrishnamurthy/331bd9addab3dbb1b6a23802b1c6845e"> Fibonacci Iterative</a>
 */
public class RecursiveMathPopUpDialog{

	public static void main( String[] args){
		final int count = 11;
		final String[] names = { "Factorial R.", "Factorial I.", "Fibonacci R.", "Fibonacci I.", "G.C.D R.", "G.C.D I." };
		final int[][] values = new int[count][names.length];
		System.out.printf( "%11s %11s %11s %11s %9s %9s%n", "FactorialR", "FactorialI", "FibonacciR", "FibonacciI", "G.C.D.R", "G.C.D.I");
		for( int i = 0; i < values.length; i++){
			values[i] = new int[] {
					RecursionExamples.factorialR( i), RecursionExamples.factorialI( i),
					RecursionExamples.fibonacciR( i), RecursionExamples.fibonacciI( i),
					RecursionExamples.gcdR( i, i * i), RecursionExamples.gcdI( i, i * i) };
			System.out.printf( "%11d %11d %11d %11d %9d %9d%n",
					RecursionExamples.factorialR( i), RecursionExamples.factorialI( i),
					RecursionExamples.fibonacciR( i), RecursionExamples.fibonacciI( i),
					RecursionExamples.gcdR( i, i * i), RecursionExamples.gcdI( i, i * i));
		}
		// Initialize the FXToolkit
		// jdk 9 can use line bellow
		//Platform.startup( () -> {});
		PlatformImpl.startup(()->{});
		Platform.runLater( () -> {
			// create an observable list with the generated data
			ObservableList< int[]> list = FXCollections.observableArrayList();
			list.addAll( Arrays.asList( values));

			// create a table with an observable list and set columns to fit width
			TableView< int[]> table = new TableView<>();
			table.setItems( list);
			table.setColumnResizePolicy( TableView.CONSTRAINED_RESIZE_POLICY);

			// create all columns and add them to table
			for( int i = 0; i < names.length; i++){
				TableColumn< int[], Number> col = new TableColumn<>( names[i]);
				// col.setMinWidth(85);
				final int colIndex = i;
				// connect each cell to a cell in list
				col.setCellValueFactory( param -> {
					return new SimpleIntegerProperty( param.getValue()[colIndex]);
				});
				table.getColumns().add( col);
			}
			// setCellValueFactory( new Callback< CellDataFeatures< Number, Number>, ObservableValue< Number>>(){
			// @Override
			// public ObservableValue< Number> call( CellDataFeatures< Number, Number> arg0){
			// return new SimpleIntegerProperty( 2);
			// }
			// });

			// create a layout an add table
			BorderPane bpTable = new BorderPane();
			bpTable.setCenter( table);

			// create JavaFX popup window with table inside
			Alert alert = new Alert( AlertType.INFORMATION);
			alert.setTitle( "Recursion Data");
			alert.setHeaderText( "Running Factorial, Fibonacci and Greatest Common Divisor (G.C.D)");
			// alert.setContentText( "I have a great message for you!");
			alert.getDialogPane().setContent( bpTable);
			alert.show();
		});
	}
}
