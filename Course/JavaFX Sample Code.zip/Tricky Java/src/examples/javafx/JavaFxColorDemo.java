package examples.javafx;

import java.lang.reflect.Field;
import java.util.function.UnaryOperator;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.control.TextFormatter.Change;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/**
 * Simple JavaFX 2 application that prints out values of standardly available
 * Color fields.
 * 
 * @author Dustin
 * @see <a href="https://www.javaworld.com/article/2074533/core-java/viewing-javafx-2-standard-colors.html">Viewing JavaFX 2 Standard Colors</a>
 */
public class JavaFxColorDemo extends Application{
	/** Width of label for color name. */
	private final static int COLOR_NAME_WIDTH = 150;
	/** Width of rectangle that displays color. */
	private final static int COLOR_RECT_WIDTH = 50;
	/** Height of rectangle that displays color. */
	private final static int COLOR_RECT_HEIGHT = 25;

	private VBox colorsPane;

	/**
	 * Build a pane containing details about the instance of Color provided.
	 * 
	 * @param color Instance of Color about which generated Pane should describe.
	 * @return Pane representing information on provided Color instance.
	 */
	private Pane buildColorBox( final Color color, final String colorName){
		HBox colorBox = new HBox();
		Label colorNameLabel = new Label( colorName);
		colorNameLabel.setMinWidth( COLOR_NAME_WIDTH);
		colorBox.getChildren().add( colorNameLabel);
		Rectangle colorRectangle = new Rectangle( COLOR_RECT_WIDTH, COLOR_RECT_HEIGHT);
		colorRectangle.setFill( color);
		colorRectangle.setStroke( Color.BLACK);
		colorBox.getChildren().add( colorRectangle);
		String rgbString = String.valueOf( color.getRed())
				+ " / " + String.valueOf( color.getGreen())
				+ " / " + String.valueOf( color.getBlue())
				+ " // " + String.valueOf( color.getOpacity());
		Label rgbLabel = new Label( rgbString);
		rgbLabel.setTooltip( new Tooltip( "Red / Green / Blue // Opacity"));
		colorBox.getChildren().add( rgbLabel);
		return colorBox;
	}

	/**
	 * Extracts a double between 0.0 and 1.0 inclusive from the provided String.
	 * 
	 * @param colorString String from which a double is extracted.
	 * @return Double between 0.0 and 1.0 inclusive based on provided String;
	 *         will be 0.0 if provided String cannot be parsed.
	 */
	private double extractValidColor( final String colorString){
		double colorValue = 0.0;
		try{
			colorValue = Double.valueOf( colorString);
		}catch( Exception exception){
			colorValue = 0.0;
			System.err.println( "Treating '" + colorString + "' as " + colorValue);
		}finally{
			if( colorValue < 0){
				colorValue = 0.0;
				System.err.println( "Treating '" + colorString + "' as " + colorValue);
			}else if( colorValue > 1){
				colorValue = 1.0;
				System.err.println( "Treating '" + colorString + "' as " + colorValue);
			}
		}
		return colorValue;
	}

	private Color buildColor( String red, String green, String blue){
		return new Color( extractValidColor( red),
				extractValidColor( green),
				extractValidColor( blue),
				1.0);
	}

	private class FloatFormatter implements UnaryOperator< TextFormatter.Change>{

		private boolean preFocus = false, inFocus = false;
		private boolean platformUpdate = false;

		@Override
		public Change apply( Change t){

			preFocus = inFocus;
			inFocus = t.getControl().isFocused();

			System.out.printf( "isFocus: %s, preFocus: %s%n", t.getControl().isFocused(), preFocus);
			System.out.printf( "isAdded: %s, isContentChange: %s, isDeleted: %s, isReplaced: %s%n", t.isAdded(), t.isContentChange(), t.isDeleted(), t.isReplaced());
			System.out.println( "CText: " + t.getControlText());
			System.out.println( "CAnchor: " + t.getControlAnchor());
			System.out.println( "CNewText: " + t.getControlNewText());
			System.out.println( "CCartP: " + t.getControlCaretPosition());
			System.out.println( "Text: " + (t.getText().isEmpty() ? "none" : (int) t.getText().charAt( 0)));
			System.out.println( "Anchor: " + t.getAnchor());
			System.out.println( "CartP: " + t.getCaretPosition());
			System.out.println( "REnd: " + t.getRangeEnd());
			System.out.println( "RStart: " + t.getRangeStart());
			System.out.println( "Selection: " + t.getSelection());

			TextField tf = ((TextField) t.getControl());

			if( platformUpdate){
				platformUpdate = false;
				System.out.println( "PUpdate");
				if( inFocus){
					int pos = t.getControlText().length() - 2;
					t.selectRange( pos, pos);
				}
				return t;
			}

			if( t.isDeleted() || (!t.isAdded() && !t.isContentChange() && !t.isDeleted() && !t.isReplaced())){
				if( !inFocus && preFocus && !t.getControlNewText().isEmpty()){
					platformUpdate = true;
					Platform.runLater( () -> {
						tf.setText( "0." + tf.getText());
					});
				}else if( inFocus && !preFocus && t.getControlNewText().length() >= 2){
					platformUpdate = true;
					Platform.runLater( () -> {
						tf.setText( tf.getText().substring( 2));
					});
				}
				return t;
			}else if( t.getText().matches( "\\p{N}")){
				return t;
			}
			return null;
		}
	}

	/**
	 * Build pane with ability to specify own RGB values and see color.
	 * 
	 * @return Pane with ability to specify colors.
	 */
	private Pane buildCustomColorPane(){
		HBox hbColor = new HBox();
		Button btAdd = new Button( "Add");

		TextField tfRed = new TextField();
		tfRed.setPromptText( "Red 0.0 to 1.0");
		tfRed.setTextFormatter( new TextFormatter<>( new FloatFormatter()));
		TextField tfGreen = new TextField();
		tfGreen.setPromptText( "Green 0.0 to 1.0");
		tfGreen.setTextFormatter( new TextFormatter<>( new FloatFormatter()));
		TextField tfBlue = new TextField();
		tfBlue.setPromptText( "Blue 0.0 to 1.0");
		tfBlue.setTextFormatter( new TextFormatter<>( new FloatFormatter()));

		Rectangle recCustom = new Rectangle( COLOR_RECT_WIDTH, COLOR_RECT_HEIGHT);
		recCustom.setFill( Color.WHITE);
		recCustom.setStroke( Color.BLACK);

		btAdd.setPrefWidth( COLOR_NAME_WIDTH);
		btAdd.setOnMouseClicked( t -> {
			Color customColor = buildColor( tfRed.getText(), tfGreen.getText(), tfBlue.getText());
			recCustom.setFill( customColor);
			colorsPane.getChildren().add( buildColorBox( customColor, "Test"));
		});

		hbColor.getChildren().add( btAdd);
		hbColor.getChildren().add( recCustom);
		hbColor.getChildren().add( tfRed);
		hbColor.getChildren().add( tfGreen);
		hbColor.getChildren().add( tfBlue);
		return hbColor;
	}

	/**
	 * Build the main pane indicating JavaFX 2's pre-defined Color instances.
	 * 
	 * @return Pane containing JavaFX 2's pre-defined Color instances.
	 */
	private Pane buildColorsPane(){
		colorsPane = new VBox();
		Field[] fields = Color.class.getFields(); // only want public
		for( Field field : fields){
			if( field.getType() == Color.class){
				try{
					Color color = (Color) field.get( null);
					String colorName = field.getName();
					colorsPane.getChildren().add( buildColorBox( color, colorName));
				}catch( IllegalAccessException illegalAccessEx){
					System.err.println(
							"Securty Manager does not allow access of field '"
									+ field.getName() + "'.");
				}
			}
		}
		colorsPane.getChildren().add( buildCustomColorPane());
		return colorsPane;
	}

	/**
	 * Start method overridden from parent Application class.
	 * 
	 * @param stage Primary stage.
	 * @throws Exception JavaFX application exception.
	 */
	@Override
	public void start( Stage stage) throws Exception{
		Group rootGroup = new Group();
		Scene scene = new Scene( rootGroup, 700, 725, Color.WHITE);
		ScrollPane scrollPane = new ScrollPane();
		scrollPane.setPrefWidth( scene.getWidth());
		scrollPane.setPrefHeight( scene.getHeight());
		scrollPane.setContent( buildColorsPane());
		rootGroup.getChildren().add( scrollPane);
		stage.setScene( scene);
		stage.setTitle( "JavaFX Standard Colors Demonstration");
		stage.show();
	}

	/**
	 * Main function for running JavaFX application.
	 * 
	 * @param arguments Command-line arguments; none expected.
	 */
	public static void main( String[] arguments){
		launch( arguments);
	}
}