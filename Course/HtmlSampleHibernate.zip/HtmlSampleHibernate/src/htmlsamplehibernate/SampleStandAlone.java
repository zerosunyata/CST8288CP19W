package htmlsamplehibernate;

import entity.Courses;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

/**
 *
 * @author Shariar
 */
public class SampleStandAlone {
    
    public static void main(String[] args){
        //get factory with the unit name defined in persistence.xml
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("Registrar");
        //create a EntityManger which handles the communication to DB
        EntityManager manager = factory.createEntityManager();
        //start the connection
        manager.getTransaction().begin();
        //create a new course
        Courses c1 = new Courses("test103", "oop3");
        //get a JPQL builder, a sql in OOP manner
        CriteriaBuilder builder = manager.getCriteriaBuilder();
        //create a query condition for given class
        CriteriaQuery<Courses> criteria = builder.createQuery( Courses.class);
        //get the root table with entity class that has the data type
        Root<Courses> root = criteria.from( Courses.class);
        //select everything where the courseNum column is same as c1.getCourseNum()
        criteria.select( root).where(builder.equal(root.get("courseNum"),c1.getCourseNum()));
        //get all matching rows
        List<Courses> exists = manager.createQuery(criteria).getResultList();
        if(exists.isEmpty()){
            System.out.println("adding new: " + c1);
            //add a course
            manager.persist(c1);
        }else{
            System.out.println("Already Exists: " + c1);
            //save the course to manager
            Courses merge = manager.merge(c1);
            //remove the managed course
            manager.remove(merge);
        }
        //commit changes to DB
        manager.getTransaction().commit();
        //select everything from the DB
        criteria.select( root);
        //execute query with created criteria and store result in list
        List<Courses> all = manager.createQuery(criteria).getResultList();
        //select everything where the name column contains oop
        criteria.select( root).where(builder.like(root.get("name"),"%oop%"));
        //execute query with created criteria and store result in list
        List<Courses> filtered = manager.createQuery(criteria).getResultList();
        //close managet, transaction is now closed
        manager.close();
        //print both lists
        all.forEach(c->System.out.println(c));
        filtered.forEach(c->System.out.println(c));
        //hibernate is shutoff
        factory.close();
    }
}
