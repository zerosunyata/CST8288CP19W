/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package htmlsamplehibernate;

import dao.EntityFactoryManager;
import entity.Courses;
import java.util.List;
import logic.CoursesLogic;

/**
 *
 * @author Shariar
 */
public class HtmlSampleHibernate {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CoursesLogic logic = new CoursesLogic();
        List<Courses> list = logic.getAll();
        System.out.println();
        System.out.println("***************print all********************");
        list.forEach(System.out::println);
        System.out.println();
        System.out.println("***************print CST8288********************");
        Courses c = logic.getCourseByCode("CST8288");
        System.out.println(c);
        System.out.println();
        System.out.println("***************print CST8288 registry********************");
        c.getRegistryList().forEach(System.out::println);
        System.out.println();
        System.out.println("***************print courses With Registry********************");
        list = logic.getAllCoursesWithRegistry();
        list.forEach(System.out::println);
        EntityFactoryManager.destroy();
    }
}
