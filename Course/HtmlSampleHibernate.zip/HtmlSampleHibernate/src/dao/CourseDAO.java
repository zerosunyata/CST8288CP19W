package dao;

import entity.Courses;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Shariar Emami
 * @since Jan 14, 2019
 */
public class CourseDAO extends GenericDAO<Courses> implements Serializable{
 private static final long serialVersionUID = 1L;

    public CourseDAO() {
        super(Courses.class);
    }
    
    public List<Courses> findAll(){
        return findResults( "Courses.findAll", null);
    }
    
    public List<Courses> findByCourseNum( String courseNum){
        Map<String, Object> map = new HashMap<>();
        map.put("courseNum", courseNum);
        return findResults( "Courses.findByCourseNum", map);
    }
    
    public List<Courses> findByName( String name){
        Map<String, Object> map = new HashMap<>();
        map.put("name", name);
        return findResults( "Courses.findByName", map);
    }
    
    public List<Courses> findByNoRegistry(){
        return findResults( "Courses.findByNoRegistry", null);
    }
    
    public List<Courses> findByHasRegistry(){
        return findResults( "Courses.findByHasRegistry", null);
    }
}
