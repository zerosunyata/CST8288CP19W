package dao;

import java.util.Objects;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Shariar
 */
public class EntityFactoryManagerSingleton {

    private static final EntityFactoryManagerSingleton SINGLETON = new EntityFactoryManagerSingleton();
    
    private String persistenceUnit = "Registrar";
    private EntityManagerFactory factory;

    private EntityFactoryManagerSingleton() {
    }
    
    public void checkInit( String persistenceUnit){
        if(factory==null || !persistenceUnit.equalsIgnoreCase(this.persistenceUnit)){
            factory = Persistence.createEntityManagerFactory(persistenceUnit);
            this.persistenceUnit = persistenceUnit;
        }
    }
    
    public EntityManager create(){
        Objects.requireNonNull(factory, "must call checkInit method first");
        return factory.createEntityManager();
    }
    
    public static EntityFactoryManagerSingleton getInstance(){
        return SINGLETON;
    }
    
    public static void destroy(){
        SINGLETON.factory.close();
    }
    
    public static EntityManager getManager( String persistenceUnit){
        SINGLETON.checkInit(persistenceUnit);
        return SINGLETON.create();
    } 
}
