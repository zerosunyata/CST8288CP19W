package dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Shariar
 */
public class EntityFactoryManager {
    
    private static final String PERSISTENCE_UNIT = "Registrar";
    private static final EntityManagerFactory FACTORY = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT);
    
    public static void destroy(){
        FACTORY.close();
    }
    
    public static EntityManager getManager(){
        return FACTORY.createEntityManager();
    } 
}
