package logic;

import dao.CourseDAO;
import entity.Courses;
import java.io.Serializable;
import java.util.List;

/**
 *
 * @author Shariar
 */
public class CoursesLogic  implements Serializable{
 private static final long serialVersionUID = 1L;
    
    private final CourseDAO dao ;

    public CoursesLogic() { 
        dao = new CourseDAO();
    }
    
    public List<Courses> getAll(){
        List<Courses> list;
        dao.beginTransaction();
        list = dao.findAll();
        dao.closeTransaction();
        return list;
    }
    
    public Courses getCourseByCode( String code){
        Courses c;
        dao.beginTransaction();
        c = dao.find(code);
        dao.closeTransaction();
        return c;
    }
    
    public List<Courses> getAllEmptyCourses(){
        List<Courses> list;
        dao.beginTransaction();
        list = dao.findByNoRegistry();
        dao.closeTransaction();
        return list;
    }
    
    public List<Courses> getAllCoursesWithRegistry(){
        List<Courses> list;
        dao.beginTransaction();
        list = dao.findByHasRegistry();
        dao.closeTransaction();
        return list;
    }
}
