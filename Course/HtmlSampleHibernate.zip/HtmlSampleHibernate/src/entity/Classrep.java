/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author Shariar
 */
@Entity
@Table(name = "classrep", catalog = "Registrar", schema = "")
@NamedQueries({
    @NamedQuery(name = "Classrep.findAll", query = "SELECT c FROM Classrep c")
    , @NamedQuery(name = "Classrep.findByStudentNum", query = "SELECT c FROM Classrep c WHERE c.classrepPK.studentNum = :studentNum")
    , @NamedQuery(name = "Classrep.findByCourseNum", query = "SELECT c FROM Classrep c WHERE c.classrepPK.courseNum = :courseNum")
    , @NamedQuery(name = "Classrep.findByTerm", query = "SELECT c FROM Classrep c WHERE c.term = :term")
    , @NamedQuery(name = "Classrep.findByYear", query = "SELECT c FROM Classrep c WHERE c.year = :year")})
public class Classrep implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ClassrepPK classrepPK;
    @Basic(optional = false)
    @Column(name = "term")
    private Character term;
    @Basic(optional = false)
    @Column(name = "year")
    private int year;
    @JoinColumn(name = "course_num", referencedColumnName = "course_num", insertable = false, updatable = false)
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    private Courses courses;
    @JoinColumn(name = "student_num", referencedColumnName = "student_num", insertable = false, updatable = false)
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    private Students students;

    public Classrep() {
    }

    public Classrep(ClassrepPK classrepPK) {
        this.classrepPK = classrepPK;
    }

    public Classrep(ClassrepPK classrepPK, Character term, int year) {
        this.classrepPK = classrepPK;
        this.term = term;
        this.year = year;
    }

    public Classrep(int studentNum, String courseNum) {
        this.classrepPK = new ClassrepPK(studentNum, courseNum);
    }

    public ClassrepPK getClassrepPK() {
        return classrepPK;
    }

    public void setClassrepPK(ClassrepPK classrepPK) {
        this.classrepPK = classrepPK;
    }

    public Character getTerm() {
        return term;
    }

    public void setTerm(Character term) {
        this.term = term;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public Courses getCourses() {
        return courses;
    }

    public void setCourses(Courses courses) {
        this.courses = courses;
    }

    public Students getStudents() {
        return students;
    }

    public void setStudents(Students students) {
        this.students = students;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (classrepPK != null ? classrepPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Classrep)) {
            return false;
        }
        Classrep other = (Classrep) object;
        if ((this.classrepPK == null && other.classrepPK != null) || (this.classrepPK != null && !this.classrepPK.equals(other.classrepPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Classrep[ classrepPK=" + classrepPK + " ]";
    }
    
}
