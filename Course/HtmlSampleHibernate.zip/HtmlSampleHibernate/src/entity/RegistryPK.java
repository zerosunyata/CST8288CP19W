/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author Shariar
 */
@Embeddable
public class RegistryPK implements Serializable {

    @Basic(optional = false)
    @Column(name = "student_num")
    private int studentNum;
    @Basic(optional = false)
    @Column(name = "course_num")
    private String courseNum;

    public RegistryPK() {
    }

    public RegistryPK(int studentNum, String courseNum) {
        this.studentNum = studentNum;
        this.courseNum = courseNum;
    }

    public int getStudentNum() {
        return studentNum;
    }

    public void setStudentNum(int studentNum) {
        this.studentNum = studentNum;
    }

    public String getCourseNum() {
        return courseNum;
    }

    public void setCourseNum(String courseNum) {
        this.courseNum = courseNum;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) studentNum;
        hash += (courseNum != null ? courseNum.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof RegistryPK)) {
            return false;
        }
        RegistryPK other = (RegistryPK) object;
        if (this.studentNum != other.studentNum) {
            return false;
        }
        if ((this.courseNum == null && other.courseNum != null) || (this.courseNum != null && !this.courseNum.equals(other.courseNum))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.RegistryPK[ studentNum=" + studentNum + ", courseNum=" + courseNum + " ]";
    }
    
}
