/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Shariar
 */
@Entity
@Table(name = "students", catalog = "Registrar", schema = "")
@NamedQueries({
    @NamedQuery(name = "Students.findAll", query = "SELECT s FROM Students s")
    , @NamedQuery(name = "Students.findByStudentNum", query = "SELECT s FROM Students s WHERE s.studentNum = :studentNum")
    , @NamedQuery(name = "Students.findByFirstName", query = "SELECT s FROM Students s WHERE s.firstName = :firstName")
    , @NamedQuery(name = "Students.findByLastName", query = "SELECT s FROM Students s WHERE s.lastName = :lastName")
    , @NamedQuery(name = "Students.findByDateBirth", query = "SELECT s FROM Students s WHERE s.dateBirth = :dateBirth")
    , @NamedQuery(name = "Students.findByEnrolled", query = "SELECT s FROM Students s WHERE s.enrolled = :enrolled")})
public class Students implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "student_num")
    private Integer studentNum;
    @Basic(optional = false)
    @Column(name = "first_name")
    private String firstName;
    @Basic(optional = false)
    @Column(name = "last_name")
    private String lastName;
    @Basic(optional = false)
    @Column(name = "date_birth")
    @Temporal(TemporalType.DATE)
    private Date dateBirth;
    @Basic(optional = false)
    @Column(name = "enrolled")
    @Temporal(TemporalType.DATE)
    private Date enrolled;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "students", fetch = FetchType.LAZY)
    private List<Classrep> classrepList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "students", fetch = FetchType.LAZY)
    private List<Registry> registryList;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "students", fetch = FetchType.EAGER)
    private Tuition tuition;

    public Students() {
    }

    public Students(Integer studentNum) {
        this.studentNum = studentNum;
    }

    public Students(Integer studentNum, String firstName, String lastName, Date dateBirth, Date enrolled) {
        this.studentNum = studentNum;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateBirth = dateBirth;
        this.enrolled = enrolled;
    }

    public Integer getStudentNum() {
        return studentNum;
    }

    public void setStudentNum(Integer studentNum) {
        this.studentNum = studentNum;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Date getDateBirth() {
        return dateBirth;
    }

    public void setDateBirth(Date dateBirth) {
        this.dateBirth = dateBirth;
    }

    public Date getEnrolled() {
        return enrolled;
    }

    public void setEnrolled(Date enrolled) {
        this.enrolled = enrolled;
    }

    public List<Classrep> getClassrepList() {
        return classrepList;
    }

    public void setClassrepList(List<Classrep> classrepList) {
        this.classrepList = classrepList;
    }

    public List<Registry> getRegistryList() {
        return registryList;
    }

    public void setRegistryList(List<Registry> registryList) {
        this.registryList = registryList;
    }

    public Tuition getTuition() {
        return tuition;
    }

    public void setTuition(Tuition tuition) {
        this.tuition = tuition;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (studentNum != null ? studentNum.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Students)) {
            return false;
        }
        Students other = (Students) object;
        if ((this.studentNum == null && other.studentNum != null) || (this.studentNum != null && !this.studentNum.equals(other.studentNum))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Students[ studentNum=" + studentNum + " ]";
    }
    
}
