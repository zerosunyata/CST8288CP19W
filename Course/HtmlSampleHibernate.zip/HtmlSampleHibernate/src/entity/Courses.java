/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author Shariar
 */
@Entity
@Table(name = "courses", catalog = "Registrar", schema = "")
@NamedQueries({
    @NamedQuery(name = "Courses.findAll", query = "SELECT c FROM Courses c")
    , @NamedQuery(name = "Courses.findByCourseNum", query = "SELECT c FROM Courses c WHERE c.courseNum = :courseNum")
    , @NamedQuery(name = "Courses.findByName", query = "SELECT c FROM Courses c WHERE c.name = :name")
    , @NamedQuery(name = "Courses.findByHasRegistry", query = "select c from Courses c where exists ( select r.courses from Registry r where r.courses.courseNum = c.courseNum )")
    , @NamedQuery(name = "Courses.findByNoRegistry", query = "select c from Courses c where not exists ( select r.registryPK.courseNum from Registry r where r.registryPK.courseNum = c.courseNum )")})
public class Courses implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "course_num")
    private String courseNum;
    @Basic(optional = false)
    @Column(name = "name")
    private String name;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "courses", fetch = FetchType.LAZY)
    private List<Classrep> classrepList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "courses", fetch = FetchType.LAZY)
    private List<Registry> registryList;

    public Courses() {
    }

    public Courses(String courseNum) {
        this.courseNum = courseNum;
    }

    public Courses(String courseNum, String name) {
        this.courseNum = courseNum;
        this.name = name;
    }

    public String getCourseNum() {
        return courseNum;
    }

    public void setCourseNum(String courseNum) {
        this.courseNum = courseNum;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Classrep> getClassrepList() {
        return classrepList;
    }

    public void setClassrepList(List<Classrep> classrepList) {
        this.classrepList = classrepList;
    }

    public List<Registry> getRegistryList() {
        return registryList;
    }

    public void setRegistryList(List<Registry> registryList) {
        this.registryList = registryList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (courseNum != null ? courseNum.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Courses)) {
            return false;
        }
        Courses other = (Courses) object;
        if ((this.courseNum == null && other.courseNum != null) || (this.courseNum != null && !this.courseNum.equals(other.courseNum))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Courses[ courseNum=" + courseNum + ", Name= " + name + " ]";
    }
    
}
