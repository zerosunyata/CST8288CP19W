/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 *
 * @author Shariar
 */
@Entity
@Table(name = "tuition", catalog = "Registrar", schema = "")
@NamedQueries({
    @NamedQuery(name = "Tuition.findAll", query = "SELECT t FROM Tuition t")
    , @NamedQuery(name = "Tuition.findByStudentNum", query = "SELECT t FROM Tuition t WHERE t.studentNum = :studentNum")
    , @NamedQuery(name = "Tuition.findByPaid", query = "SELECT t FROM Tuition t WHERE t.paid = :paid")
    , @NamedQuery(name = "Tuition.findByRemainder", query = "SELECT t FROM Tuition t WHERE t.remainder = :remainder")})
public class Tuition implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "student_num")
    private Integer studentNum;
    @Basic(optional = false)
    @Column(name = "paid")
    private BigDecimal paid;
    @Basic(optional = false)
    @Column(name = "remainder")
    private BigDecimal remainder;
    @JoinColumn(name = "student_num", referencedColumnName = "student_num", insertable = false, updatable = false)
    @OneToOne(optional = false, fetch = FetchType.EAGER)
    private Students students;

    public Tuition() {
    }

    public Tuition(Integer studentNum) {
        this.studentNum = studentNum;
    }

    public Tuition(Integer studentNum, BigDecimal paid, BigDecimal remainder) {
        this.studentNum = studentNum;
        this.paid = paid;
        this.remainder = remainder;
    }

    public Integer getStudentNum() {
        return studentNum;
    }

    public void setStudentNum(Integer studentNum) {
        this.studentNum = studentNum;
    }

    public BigDecimal getPaid() {
        return paid;
    }

    public void setPaid(BigDecimal paid) {
        this.paid = paid;
    }

    public BigDecimal getRemainder() {
        return remainder;
    }

    public void setRemainder(BigDecimal remainder) {
        this.remainder = remainder;
    }

    public Students getStudents() {
        return students;
    }

    public void setStudents(Students students) {
        this.students = students;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (studentNum != null ? studentNum.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tuition)) {
            return false;
        }
        Tuition other = (Tuition) object;
        if ((this.studentNum == null && other.studentNum != null) || (this.studentNum != null && !this.studentNum.equals(other.studentNum))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Tuition[ studentNum=" + studentNum + " ]";
    }
    
}
