/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author Shariar
 */
@Entity
@Table(name = "registry", catalog = "Registrar", schema = "")
@NamedQueries({
    @NamedQuery(name = "Registry.findAll", query = "SELECT r FROM Registry r")
    , @NamedQuery(name = "Registry.findByStudentNum", query = "SELECT r FROM Registry r WHERE r.registryPK.studentNum = :studentNum")
    , @NamedQuery(name = "Registry.findByCourseNum", query = "SELECT r FROM Registry r WHERE r.registryPK.courseNum = :courseNum")
    , @NamedQuery(name = "Registry.findByTerm", query = "SELECT r FROM Registry r WHERE r.term = :term")
    , @NamedQuery(name = "Registry.findByYear", query = "SELECT r FROM Registry r WHERE r.year = :year")})
public class Registry implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected RegistryPK registryPK;
    @Basic(optional = false)
    @Column(name = "term")
    private Character term;
    @Basic(optional = false)
    @Column(name = "year")
    private int year;
    @JoinColumn(name = "course_num", referencedColumnName = "course_num", insertable = false, updatable = false)
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    private Courses courses;
    @JoinColumn(name = "student_num", referencedColumnName = "student_num", insertable = false, updatable = false)
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    private Students students;

    public Registry() {
    }

    public Registry(RegistryPK registryPK) {
        this.registryPK = registryPK;
    }

    public Registry(RegistryPK registryPK, Character term, int year) {
        this.registryPK = registryPK;
        this.term = term;
        this.year = year;
    }

    public Registry(int studentNum, String courseNum) {
        this.registryPK = new RegistryPK(studentNum, courseNum);
    }

    public RegistryPK getRegistryPK() {
        return registryPK;
    }

    public void setRegistryPK(RegistryPK registryPK) {
        this.registryPK = registryPK;
    }

    public Character getTerm() {
        return term;
    }

    public void setTerm(Character term) {
        this.term = term;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public Courses getCourses() {
        return courses;
    }

    public void setCourses(Courses courses) {
        this.courses = courses;
    }

    public Students getStudents() {
        return students;
    }

    public void setStudents(Students students) {
        this.students = students;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (registryPK != null ? registryPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Registry)) {
            return false;
        }
        Registry other = (Registry) object;
        if ((this.registryPK == null && other.registryPK != null) || (this.registryPK != null && !this.registryPK.equals(other.registryPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Registry[ registryPK=" + registryPK + " ]";
    }
    
}
