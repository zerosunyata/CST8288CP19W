package examples.enumeration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * this enum represents the months and their days.
 * 
 * @author Shahriar (Shawn) Emami
 * @version Jan 29, 2018
 */
public enum Month{
	/**
	 * name of all the months. the order of deceleration remains the same.
	 */
	January( 31), February( 28), March( 31), April( 30), May( 31), June( 30), July( 31), August( 31), September( 30), October( 31), November( 30), December( 31);

	/**
	 * private value to hold number passed to months name like, January(31)
	 */
	private int days;

	/**
	 * Constructor for special values given to enums.
	 * if instead it was just January there would have been no need for days or constructor.
	 * @param days - number of days with which to initialize the month
	 */
	private Month( int days){
		this.days = days;
	}

	/**
	 * get the number of days in the month.
	 * @return number of days
	 */
	public int days(){
		return days;
	}
	
	/**
	 * if month is February return 29 days otherwise same behavior as {@linkplain Month#days()}
	 * @return number of days if year is leap
	 */
	public int leap(){
		return this==February?29:this.days;
	}

	/**
	 * get the next month
	 * @return next month
	 */
	public Month next(){
//		3 lines bellow do the same as the switch statement below them
//		int index = ordinal();
//		Month[] months = values();
//		return months[index==months.length-1?0:index+1];
		switch( this){
			case January:
				return February;
			case February:
				return March;
			case March:
				return April;
			case April:
				return May;
			case May:
				return June;
			case June:
				return July;
			case July:
				return August;
			case August:
				return September;
			case September:
				return October;
			case October:
				return November;
			case November:
				return December;
			case December:
				return January;
			default:
				throw new IllegalStateException( this + " does not exists");
		}
	}

	/**
	 * get the previous month
	 * @return previous month
	 */
	public Month prev(){
		int index = ordinal();
		Month[] months = values();
		return months[index==0?months.length-1:index-1];
	}
	
	/**
	 * find month that have the given number of days.
	 * @param days - number of days for which to search.
	 * @return list of months with given days, if none return empty list
	 */
	public static Month[] getMonthsWith( int days){
		List<Month> months = Collections.emptyList();
		for( Month m: values()){
			if( m.days==days){
				if( months.isEmpty()){
					months = new ArrayList<>(7);
				}
				months.add( m);
			}
		}
		return months.toArray( new Month[months.size()]);
	}
}