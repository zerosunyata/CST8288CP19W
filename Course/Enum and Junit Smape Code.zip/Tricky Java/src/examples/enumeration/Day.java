package examples.enumeration;

/**
 * this enum represents the days of the week.
 * 
 * @author Shahriar (Shawn) Emami
 * @version Jan 30, 2018
 */
public enum Day{
	/**
	 * name of all the days. the order of deceleration remains the same.
	 */
	Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday;
	
	//no need for constructor since none of the days take any argument
	
	/**
	 * get the next day
	 * @return next day
	 */
	public Day next(){
//		3 lines bellow do the same as the switch statement below them
//		int index = ordinal();
//		Day[] days = values();
//		return days[index==days.length-1?0:index+1];
		switch( this){
			case Monday:
				return Tuesday;
			case Tuesday:
				return Wednesday;
			case Wednesday:
				return Thursday;
			case Thursday:
				return Friday;
			case Friday:
				return Saturday;
			case Saturday:
				return Sunday;
			case Sunday:
				return Monday;
			default:
				throw new IllegalStateException( this + " does not exists");
		}
	}

	/**
	 * get the previous day
	 * @return previous day
	 */
	public Day prev(){
		int index = ordinal();
		Day[] days = values();
		return days[index==0?days.length-1:index-1];
	}
}
