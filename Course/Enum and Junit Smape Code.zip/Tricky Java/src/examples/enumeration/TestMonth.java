package examples.enumeration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestMonth{

	private static final String[] MONTH_NAMES = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
	private static final int[] MONTH_DAYS = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	private static final int[] MONTH_DAYS_LEAP = { 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	private static final int[][] MONTH_COMMON_DAYS = {{28,1},{30,4},{31,7}};
	private static final int[] MONTH_ORDER = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 };
	private static final Month[] MONTHS = Month.values();

	@Before
	public void setUp() throws Exception{
	}

	@After
	public void tearDown() throws Exception{
	}

	@Test
	public void testMonthNames(){
		for( int i = 0; i < MONTHS.length; i++){
			if( !MONTHS[i].name().equals( MONTH_NAMES[i])){
				fail( String.format( "\"%s\" is not equal to \"%s\"", MONTHS[i], MONTH_NAMES[i]));
			}
		}
	}

	@Test
	public void testMonthDays(){
		for( int i = 0; i < MONTHS.length; i++){
			if( MONTHS[i].days() != MONTH_DAYS[i]){
				fail( String.format( "\"%s\" does not have the correct days as \"%s\":%d", MONTHS[i], MONTH_NAMES[i], MONTH_DAYS[i]));
			}
		}
	}

	@Test
	public void testMonthDaysLeap(){
		for( int i = 0; i < MONTHS.length; i++){
			if( MONTHS[i].leap() != MONTH_DAYS_LEAP[i]){
				fail( String.format( "\"%s\" does not have the correct days as \"%s\":%d", MONTHS[i], MONTH_NAMES[i], MONTH_DAYS[i]));
			}
		}
	}

	@Test
	public void testMonthOrder(){
		for( int i = 0; i < MONTHS.length; i++){
			if( MONTHS[i].ordinal() != MONTH_ORDER[i]){
				fail( String.format( "\"%s\" is in wrong place", MONTHS[i]));
			}
		}
	}

	@Test
	public void testNext(){
		for( int i = 0; i < MONTHS.length - 1; i++){
			if( MONTHS[i].next().ordinal() != MONTH_ORDER[i + 1]){
				fail( String.format( "\"%s\"'s next month \"%s\" should be \"%s\"", MONTHS[i], MONTHS[i].next(), MONTH_NAMES[i + 1]));
			}
		}
		assertEquals( "Next month for December should be Januray", MONTH_ORDER[0], MONTHS[MONTHS.length - 1].next().ordinal());
	}

	@Test
	public void testPrev(){
		for( int i = 1; i < MONTHS.length - 1; i++){
			if( MONTHS[i].prev().ordinal() != MONTH_ORDER[i - 1]){
				fail( String.format( "\"%s\"'s previous month \"%s\" should be \"%s\"", MONTHS[i], MONTHS[i].next(), MONTH_NAMES[i - 1]));
			}
		}
		assertEquals( "Previous month for Januray should be December", MONTH_ORDER[MONTH_ORDER.length - 1], MONTHS[0].prev().ordinal());
	}
	
	@Test
	public void testGetMonthsWith(){
		for( int[] test : MONTH_COMMON_DAYS){
			if( Month.getMonthsWith( test[0]).length!=test[1]){
				fail( String.format( "There should only be %d months that have %d days.", test[1], test[0]));
			}
		}
	}
}