package examples.enumeration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestDay{

	private static final String[] DAY_NAMES = { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
	private static final int[] DAY_ORDER = { 0, 1, 2, 3, 4, 5, 6};
	private static final Day[] DAYS = Day.values();

	@Before
	public void setUp() throws Exception{
	}

	@After
	public void tearDown() throws Exception{
	}

	@Test
	public void testDayNames(){
		for( int i = 0; i < DAYS.length; i++){
			if( !DAYS[i].name().equals( DAY_NAMES[i])){
				fail( String.format( "\"%s\" is not equal to \"%s\"", DAYS[i], DAY_NAMES[i]));
			}
		}
	}

	@Test
	public void testDayOrder(){
		for( int i = 0; i < DAYS.length; i++){
			if( DAYS[i].ordinal() != DAY_ORDER[i]){
				fail( String.format( "\"%s\" is in wrong place", DAYS[i]));
			}
		}
	}

	@Test
	public void testNext(){
		for( int i = 0; i < DAYS.length - 1; i++){
			if( DAYS[i].next().ordinal() != DAY_ORDER[i + 1]){
				fail( String.format( "\"%s\"'s next day \"%s\" should be \"%s\"", DAYS[i], DAYS[i].next(), DAY_NAMES[i + 1]));
			}
		}
		assertEquals( "Next day for Sunday should be Monday", DAY_ORDER[0], DAYS[DAYS.length - 1].next().ordinal());
	}

	@Test
	public void testPrev(){
		for( int i = 1; i < DAYS.length - 1; i++){
			if( DAYS[i].prev().ordinal() != DAY_ORDER[i - 1]){
				fail( String.format( "\"%s\"'s previous day \"%s\" should be \"%s\"", DAYS[i], DAYS[i].next(), DAY_NAMES[i - 1]));
			}
		}
		assertEquals( "Previous day for Monday should be Sunday", DAY_ORDER[DAY_ORDER.length - 1], DAYS[0].prev().ordinal());
	}
}