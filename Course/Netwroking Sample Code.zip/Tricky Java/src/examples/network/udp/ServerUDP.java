package examples.network.udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ServerUDP implements Runnable{

	/**
	 * port address which this server will listen for incoming connections
	 */
	private static final int SERVER_PORT = 80;
	
	/**
	 * thread pool manager for all active threads
	 */
	private ExecutorService service;
	
	/**
	 * create new server
	 */
	public ServerUDP(){
		// create a new cached pool of threads since we don't know the max number of threads needed
		service = Executors.newCachedThreadPool();
	}

	/**
	 * start the server Thread
	 */
	public void start() {
		// submit to thread pool run method (Runnable) of server class to be executed
		service.submit(this);
	}
	
	/**
	 * main method to run the server
	 */
	public void run(){
		// create a new DatagramSocket in try and resource block, this way when you exit your program
		// all socket resources such as ports will be released or
		// call socket.close() if outside of try and resource block, must be finally block
		try( DatagramSocket datagramSocket = new DatagramSocket( SERVER_PORT)){
			//create a buffer to be filled by incoming package
			byte[] buffer = new byte[1024];
			
			//create packet with giver buffer
			DatagramPacket packetIn = new DatagramPacket(buffer, buffer.length);
			//pass the packet to socket to be filled with incoming message
			datagramSocket.receive(packetIn);
			//extract incoming message and override the buffer
			buffer = packetIn.getData();
			
			//create a new packet the new buffer and send the info back to the client
			DatagramPacket packetOut = new DatagramPacket( buffer, packetIn.getLength(), packetIn.getAddress(), packetIn.getPort());
			datagramSocket.send(packetOut);
		}catch( IOException e){
			e.printStackTrace();
		}
		// shutdown the thread pool
		service.shutdown();
	}
	
	/**
	 * start application
	 */
	public static void main(String[] args) {
		// create a new server and start it
		new ServerUDP().start();
	}
}
