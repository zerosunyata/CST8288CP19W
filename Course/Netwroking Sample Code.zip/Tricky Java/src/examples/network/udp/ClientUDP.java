package examples.network.udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ClientUDP implements Runnable{
	
	/**
	 * IP address of the Host/Server to connect to
	 */
	private static final String HOST_IP = "127.0.0.1";
	
	/**
	 * Port number of the Host/Server to connect to
	 */
	private static final int HOST_PORT = 9876;

	/**
	 * thread pool manager for all active threads
	 */
	private ExecutorService service;

	/**
	 * create new client
	 */
	public ClientUDP() {
		// create a thread pool of size 2
		// one thread is get information form console
		// other thread is to get information from server
		service = Executors.newFixedThreadPool(2);
	}

	/**
	 * start client thread
	 */
	public void start() {
		// submit client run method (Runnable Interface) to ExecutorService which will start
		service.submit(this);
	}

	/**
	 * main run method to run client features
	 */
	public void run(){
		// create a new DatagramSocket in try and resource block, this way when you exit your program
		// all socket resources such as ports will be released or
		// call socket.close() if outside of try and resource block, must be finally block
		// using zero means use any available port
		try( DatagramSocket datagramSocket = new DatagramSocket( 0)){
			// a buffer for incoming message
			byte[] in = new byte[1024];
			// a buffer for outgoing message
			byte[] out = "Hello".getBytes();

			//send a packet to the server
			DatagramPacket packetOut = new DatagramPacket( out, out.length, new InetSocketAddress(HOST_IP, HOST_PORT));
			datagramSocket.send(packetOut);
			
			// receive a package form the server
			DatagramPacket packetIn = new DatagramPacket(in, in.length);
			datagramSocket.receive(packetIn);
			in = packetIn.getData();
			System.out.printf( "Server: %s%n", new String( in, 0, packetIn.getLength()));
		}catch( IOException e){
			e.printStackTrace();
		}
		//stop the thread pool
		service.shutdown();
	}

	/**
	 * start program
	 */
	public static void main(String[] args) {
		// create a new client object and start client thread
		new ClientUDP().start();
	}
}
