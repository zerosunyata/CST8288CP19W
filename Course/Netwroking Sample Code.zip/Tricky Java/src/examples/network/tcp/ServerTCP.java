package examples.network.tcp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class ServerTCP implements Runnable{

	/**
	 * port address which this server will listen for incoming connections
	 */
	private static final int SERVER_PORT = 8888;

	/**
	 * list of PrintWriter connections to clients to echo messages to
	 */
	private List< PrintWriter> clients;

	/**
	 * thread pool manager for all active threads
	 */
	private ExecutorService service;

	/**
	 * create new server
	 */
	public ServerTCP(){
		// create a new cached pool of threads since we don't know the max number of threads needed
		service = Executors.newCachedThreadPool();
		// create an array list which will hold the connection to clients with initial size 100
		clients = new ArrayList<>( 100);
	}

	/**
	 * start the server Thread
	 */
	public void start(){
		// submit to thread pool run method (Runnable) of server class to be executed
		service.submit( this);
	}

	/**
	 * main method to run the server
	 */
	public void run(){
		// a thread safe object that will keep state of this thread as true or false for running or stop
		AtomicBoolean alive = new AtomicBoolean( true);
		// create a new ServerSocket in try and resource block, this way when you exit your program
		// all socket resources such as ports will be released or
		// call socket.close() if outside of try and resource block, must be finally block
		try( ServerSocket socket = new ServerSocket( SERVER_PORT)){
			// amount of time to wait before timing out the connection for unsuccessful connect
			socket.setSoTimeout( 1000);
			// only loop if alive is true
			while( alive.get()){
				try{
					// accept a new Socket call client.close() when done with socket, must be in finally block.
					// accept waits for a client to connect and returns that client as a socket.
					Socket client = socket.accept();
					// if for whatever reason returned socket is null try again
					if( client == null){
						continue;
					}
					// using the two methods below you can see the IP and post of connected client
					System.out.printf( "%s:%d: Connected%n", client.getInetAddress(), client.getPort());
					// start a new thread for every time a client connects
					service.submit( () -> {
						// create in and out objects in try and resource block
						// Separating with ";", when exiting these resources will quit and resources released
						// create a new PrintWriter which outputs information to the client, using true means no need to
						// flush
						try( PrintWriter out = new PrintWriter( client.getOutputStream(), true);
								// create a new BufferedReader which reads information from client
								BufferedReader in = new BufferedReader(
										new InputStreamReader( client.getInputStream()))){
							// add the output of this client to the client lists so other threads can send
							// message to this client as well
							clients.add( out);
							// continue to loop as long as alive is true
							while( alive.get()){
								// create a buffer of characters to read input from incoming clients
								char[] cbuf = new char[1024];
								// pass the buffer to BufferedReader to be filled with incoming information
								// return the length of the buffer that is used
								int length = in.read( cbuf);
								// create a string from the buffer
								String input = String.valueOf( cbuf, 0, length);
								System.out.printf( "%s:%d: %s%n", client.getInetAddress(), client.getPort(), input);
								// send the input text to every client
								clients.forEach( t -> t.println( input));
								// if quit is requested, stop the server by setting alive to false
								if( input.equalsIgnoreCase( "quit")){
									alive.set( false);
									clients.clear();
								}
							}
						}catch( IOException e){
							System.err.println( "something when wrong with client connection: " + e.getMessage());
						}finally{
							try{
								client.close();
							}catch( IOException e){
								System.err.println( "something when wrong closing client connection: " + e.getMessage());
							}
						}
					});
				}catch( SocketTimeoutException e){
					// Connection timed out try again.
				}
			}
		}catch( IOException e){
			System.err.println( "something when wrong with server connection: " + e.getMessage());
		}
		// shutdown the thread pool
		service.shutdown();
	}

	/**
	 * start application
	 */
	public static void main( String[] args){
		// create a new server and start it
		new ServerTCP().start();
	}
}
