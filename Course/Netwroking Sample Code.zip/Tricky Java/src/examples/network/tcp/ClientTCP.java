package examples.network.tcp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class ClientTCP implements Runnable{

	/**
	 * IP address of the Host/Server to connect to
	 */
	private static final String HOST_IP = "127.0.0.1";

	/**
	 * Port number of the Host/Server to connect to
	 */
	private static final int HOST_PORT = 8888;

	/**
	 * thread pool manager for all active threads
	 */
	private ExecutorService service;

	/**
	 * create new client
	 */
	public ClientTCP(){
		// create a thread pool of size 2
		// one thread is get information form console
		// other thread is to get information from server
		service = Executors.newFixedThreadPool( 2);
	}

	/**
	 * start client thread
	 */
	public void start(){
		// submit client run method (Runnable Interface) to ExecutorService which will start
		service.submit( this);
	}

	/**
	 * main run method to run client features
	 */
	public void run(){
		// a thread safe object that will keep state of this thread as true or false for running or stop
		AtomicBoolean alive = new AtomicBoolean( true);
		// create a new socket in try and resource block, this way when you exit your program
		// all socket resources such as port will be released or
		// call socket.close() if outside of try and resource block, must be finally block
		// after socket also create in and out objects in the same try and resource block
		// Separating with ";", when exiting these resources like socket will quit and resources released
		try( Socket socket = new Socket( InetAddress.getByName( HOST_IP), HOST_PORT);
				// create a new PrintWriter which outputs information to the server, using true means no need to flush
				PrintWriter out = new PrintWriter( socket.getOutputStream(), true);
				// create a new BufferedReader which reads information from server
				BufferedReader in = new BufferedReader( new InputStreamReader( socket.getInputStream()))){
			// amount of time to wait before timing out the connection for unsuccessful connect
			socket.setSoTimeout( 1000);
			// start a new thread that will read user input and submit to server
			service.submit( () -> {
				// using try and resource block create a BufferedReader for inputs from the console
				try( BufferedReader console = new BufferedReader( new InputStreamReader( System.in))){
					System.out.print( "Client>> ");
					String input;
					// only loop if alive is true
					while( alive.get()){
						// wait until we have data to complete a readLine()
						if( !console.ready()){
							try{
								// if no input sleep and check again
								Thread.sleep( 200);
							}catch( InterruptedException e){
								// try again
							}
						}else{// if there is data from console
							// read the data
							input = console.readLine();
							if( input != null && !input.isEmpty()){
								// if not null or empty send to server
								out.println( input);
								// if input is equal to quit set alive to false so loop stops and program quits
								if( input.equalsIgnoreCase( "quit")){
									alive.set( false);
								}
							}
						}
					}
				}catch( IOException e){
					// problem reading from console
					System.err.println( "problem reading from console: " + e.getMessage());
				}
			});
			// loop as long as alive is true and read messages coming from server
			while( alive.get()){
				try{
					String input = in.readLine();
					// if null, end of stream is reached
					if( input == null)
						break;
					// read the message from server and print it on console
					System.out.printf( "Server: %s%n", input);
				}catch( SocketTimeoutException e){
					// Connection timed out try again.
				}catch( SocketException e){
					System.err.println( "problem with input stream: " + e.getMessage());
					break;
				}
			}
			System.out.println( "not waiting for server anymore");
		}catch( IOException e){
			System.err.println( "problem with input stream: " + e.getMessage());
		}
		alive.set( false);
		// stop the thread pool
		service.shutdown();
	}

	/**
	 * start program
	 */
	public static void main( String[] args){
		// create a new client object and start client thread
		new ClientTCP().start();
	}
}
