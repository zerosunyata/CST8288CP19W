package examples.threads.startingthread;

/**
 * <p>
 * this is an example of how to create a thread in java
 * using lambda and method reference.
 * </p>
 * 
 * @author Shahriar (Shawn) Emami
 * @version Apr 5, 2019
 */
public class ThreadLambdaStart{

	public static void someCode(){
		// to get the current Thread Object running this code
		// Thread.currentThread() can be used.
		// method getName() is part of Thread class and
		// can be used to get the name of running thread
		String threadName = Thread.currentThread().getName();
		for( int i = 0; i < 3; i++){
			System.out.printf( "Name: \"%s\", printing: %d%n", threadName, i);
		}
	}
	
	public static void main( String[] args){
		//create a Runnable object using lambda
		Runnable run = ()->{
			someCode();
		};
		
		//start a thread by passing to it the runnable object and a name for thread
		Thread lambdaObjectThread = new Thread( run, "Thread using Runnable Lambda Object");
		startThreadAndWait( lambdaObjectThread);

		//start a thread by passing to it a method reference.
		//the method used must have the same signature as run method in Runnable interface.
		//in this case we are using the run method itself as method reference.
		Thread methodRefrenceThread = new Thread( ThreadLambdaStart::someCode, "Thread using Method Refrence");
		startThreadAndWait( methodRefrenceThread);

		//start a thread by passing to it a lambda with zero arguments and no return type plus a name for thread
		Thread lambdaThread = new Thread( ()->{
			someCode();
		}, "Thread using Runnable Lambda");
		startThreadAndWait( lambdaThread);
	}
	
	public static void startThreadAndWait( Thread t){
		// start the thread object. this function is none blocking
		// meaning program will not wait on start, it will call it
		// and move on regardless of thread running state.
		t.start();
		// join method is a special method in Thread class that allows
		// program execution to be blocked till thread object has finished its work.
		try{
			t.join();
		}catch( InterruptedException e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.printf( "%s is done.%n%n", t.getName());
	}
}
