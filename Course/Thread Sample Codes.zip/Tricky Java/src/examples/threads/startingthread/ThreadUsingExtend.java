package examples.threads.startingthread;

/**
 * <p>
 * this is an example of how to create a thread in java
 * by extending from {@link Thread} class.
 * </p>
 * <p>
 * when extending from a {@link Thread} class the {@link Thread#run()}
 * method must be overridden and the code to be executed placed inside.
 * </p>
 * 
 * @author Shahriar (Shawn) Emami
 * @version Apr 5, 2019
 */
public class ThreadUsingExtend extends Thread{

	/**
	 * constructor is optional, default constructor is here
	 * to allow for no argument thread object
	 */
	public ThreadUsingExtend(){
		// no need to call super for default constructor
	}

	/**
	 * create a new thread and give a special name
	 * @param threadName - a special name for this thread
	 */
	public ThreadUsingExtend( String threadName){
		super( threadName);
	}

	@Override
	public void run(){
		// method getName() is part of Thread class and
		// can be used to get the name of running thread
		String threadName = getName();
		for( int i = 0; i < 5; i++){
			System.out.printf( "Name: \"%s\", printing: %d%n", threadName, i);
		}
	}

	public static void main( String[] args){
		// create a new thread Object
		ThreadUsingExtend t = new ThreadUsingExtend( "Thread using Extend");
		// start the thread object. this function is none blocking
		// meaning program will not wait on start, it will call it
		// and move on regardless of thread running state.
		t.start();
		// join method is a special method in Thread class that allows
		// program execution to be blocked till thread object has finished its work.
		try{
			t.join();
		}catch( InterruptedException e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println( "main thread is over.");
	}
}
