package examples.threads.startingexecutor;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * <p>
 * in this class we look at how to use a thread through {@link ExecutorService}.
 * the idea of {@link ExecutorService} is to create a pool of threads and reuse
 * created threads instead creating new ones for every task.
 * </p>
 * <p>
 * to start a thread using {@link ExecutorService} a task of type {@link Runnable}
 * must be passed to {@link ExecutorService#submit(Runnable)}.
 * </p>
 * <p>
 * finally {@link ExecutorService} must be shutdown using {@link ExecutorService#shutdown()}.
 * have in mind that when shutting down {@link ExecutorService} active threads will not be
 * affected as they need to finish. when {@link ExecutorService#shutdown()} is called no more
 * tasks can be submitted. however, any tasks that are already in queue waiting to be executed
 * will be executed.
 * </p>
 * 
 * @author Shahriar (Shawn) Emami
 * @version Apr 6, 2019
 */
public class ExecutorServiceStart{

	/**
	 * create an ExecutorService that will only have one thread.
	 * new tasks have to wait for this single thread to become available.
	 */
	private ExecutorService singleService = Executors.newSingleThreadExecutor();

	/**
	 * create an ExecutorService that will have a fixed number of threads.
	 * new tasks will be assigned to thread pool and after all threads are busy
	 * any new task has to wait for one of the threads to become free.
	 */
	private ExecutorService fixedService = Executors.newFixedThreadPool( 5);

	/**
	 * create an ExecutorService that will have an open ended number of threads.
	 * new tasks will be assigned to any available idle thread first then new tasks
	 * will be assigned to new threads till an old thread become available.
	 */
	private ExecutorService cachedService = Executors.newCachedThreadPool();

	/**
	 * shutdown all services
	 */
	public void shutdown(){
		singleService.shutdown();
		fixedService.shutdown();
		cachedService.shutdown();
	}

	public void startThreadUsingLambda(){
		singleService.submit( () -> {
			runSomeCode( "Lambda ExecutorService Single Pool");
		});
		fixedService.submit( () -> {
			runSomeCode( "Lambda ExecutorService Fixed Pool");
		});
		cachedService.submit( () -> {
			runSomeCode( "Lambda ExecutorService Open Ended Pool");
		});
	}

	public void runSomeCode( String name){
		// this line sets the name for the current thread
		Thread.currentThread().setName( name);
		String threadName = Thread.currentThread().getName();
		System.out.printf( "Name: \"%s\"%n", threadName);
	}

	public static void main( String[] args){
		ExecutorServiceStart es = new ExecutorServiceStart();
		es.startThreadUsingLambda();
		es.shutdown();
	}
}
