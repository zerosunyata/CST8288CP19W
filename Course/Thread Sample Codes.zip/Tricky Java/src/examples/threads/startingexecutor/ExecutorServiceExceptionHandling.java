package examples.threads.startingexecutor;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * <p>
 * catching exceptions is a little different in {@link ExecutorService}. this
 * service eat any exception thrown in the submitted task. this class has
 * multiple methods exploring how to handle this situation.
 * </p>
 * 
 * @author Shahriar (Shawn) Emami
 * @version Apr 6, 2019
 */
public class ExecutorServiceExceptionHandling{

	/**
	 * create an ExecutorService that will have an open ended number of threads.
	 * new tasks will be assigned to any available idle thread first then new tasks
	 * will be assigned to new threads till an old thread become available.
	 */
	private ExecutorService cachedService = Executors.newCachedThreadPool();

	/**
	 * shutdown all services
	 */
	public void shutdown(){
		cachedService.shutdown();
	}

	/**
	 * when this method is called no exception will be displayed on console.
	 * even though, the task simply throws a new {@link Exception}.
	 */
	public void startThreadEatException(){
		cachedService.submit( () -> {
			System.out.println( "no exception will be displayed on console");
			throw new Exception( "this exception is invisible");
		});
	}

	/**
	 * when this method is called we catch the exception inside of the task/lambda/run
	 * using basic try and catch block.
	 */
	public void startThreadCatchExceptionInTryCatch(){
		cachedService.submit( () -> {
			try{
				throw new Exception( "this exception is caught in Try and Catch inside of task/lambda/run");
			}catch( Exception e){
				e.printStackTrace();
			}
		});
	}

	/**
	 * <p>
	 * when this method is called we catch the exception out side of the task/lambda/run
	 * using the {@link Future} object returned by {@link ExecutorService#submit(Runnable)}.
	 * </p>
	 * <p>
	 * {@link Future} object represents the return type of thread that is executing task/lambda/run.
	 * {@link Runnable} does not have a return type so return will always be empty for runnable task
	 * however we can find any exceptions that might have been thrown during the execution of task/lambda/run.
	 * the only down side of this method is {@link Future#get()} being blocking method. meaning it will wait
	 * for task/lambda/run to finish before it can continue.
	 * </p>
	 */
	public void startThreadCatchUsingFuture(){
		Future< ?> future = cachedService.submit( () -> {
			throw new Exception( "this exception is caught in Try and Catch inside of task/lambda/run");
		});
		try{
			future.get();
		}catch( InterruptedException | ExecutionException e){
			e.printStackTrace();
		}
	}

	public static void main( String[] args){
		ExecutorServiceExceptionHandling ex = new ExecutorServiceExceptionHandling();
		ex.startThreadEatException();
		ex.startThreadCatchExceptionInTryCatch();
		ex.startThreadCatchUsingFuture();
		ex.shutdown();
	}
}
