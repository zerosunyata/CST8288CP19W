package examples.threads.syncing;

import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Executors;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * this is the same example is other two producer consumer threads.
 * However, instead of writing all the code for synchronization ourselves
 * we can just use {@link BlockingQueue} which is provided by JDK.
 * 
 * @author Shahriar (Shawn) Emami
 * @version Apr 7, 2019
 */
public class ProducerConsumerBlockingQueue {

	private final Random RAND = new Random( 1);
	private final AtomicBoolean running = new AtomicBoolean( false);
	private final ExecutorService executor = Executors.newCachedThreadPool();
	private final BlockingQueue< Integer> data = new LinkedBlockingQueue<>(5);

	public void produce(){
		int push = 0;
		while( running.get()){
			push = RAND.nextInt( 1000);
			try{
				data.put( push);
			}catch( InterruptedException e){
				e.printStackTrace();
			}
			System.out.println( "Pushed: " + push + ", " + data);
		}
	}

	public void consume(){
		int pop = 0;
		while( running.get()){
			try{
				pop = data.take();
			}catch( InterruptedException e){
				e.printStackTrace();
			}
			System.out.println( "Popped: " + pop + ", " + data);
		}
	}

	public void stop(){
		running.set( false);
		System.out.println( "shutdown executor");
		executor.shutdown();
	}

	public void simulate(){
		System.out.println( "Main Started");
		running.set( true);
		executor.submit( this::consume);
		executor.submit( this::produce);
	}

	public static void main( String[] args) throws InterruptedException{
		ProducerConsumerBlockingQueue pct = new ProducerConsumerBlockingQueue();
		pct.simulate();
		TimeUnit.SECONDS.sleep( 5);
		pct.stop();
	}
}
