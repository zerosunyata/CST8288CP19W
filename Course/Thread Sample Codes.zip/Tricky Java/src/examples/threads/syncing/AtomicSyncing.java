package examples.threads.syncing;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.DoubleAdder;
import java.util.concurrent.atomic.LongAccumulator;

/**
 * <p>
 * Atomic variables provided by JDK guarantee the data in atomic variables are
 * always the same regardless of thread accessing them. these atomic objects
 * are Thread-Safe.
 * </p>
 * <p>
 * this class hold examples of three different atomic variables.
 * </p> 
 * 
 * @author Shahriar (Shawn) Emami
 * @version Apr 7, 2019
 */
public class AtomicSyncing{

	/**
	 * this is an example of custom counter. this object adds Long numbers using the lambda from constructor.
	 */
	private LongAccumulator counter = new LongAccumulator( ( a, b) -> a + 2*b, 0);
	
	/**
	 * this is an example of simple adder. this object simply adds to current value stored in it.
	 */
	private DoubleAdder adder = new DoubleAdder();
	
	/**
	 * this is an example of boolean flag.
	 */
	private AtomicBoolean stopFlag = new AtomicBoolean( false);

	public void startAdding( final int NUM) throws InterruptedException{
		Thread t1 = new Thread( () -> {
			while( !stopFlag.get()){
				adder.add( NUM);
				counter.accumulate( NUM);
			}
			System.out.printf( "Adder: %d, Counter: %d%n", adder.intValue(), counter.longValue());
		});
		Thread t2 = new Thread( () -> {
			while( !stopFlag.get()){
				adder.add( NUM);
				counter.accumulate( NUM);
			}
			System.out.printf( "Adder: %d, Counter: %d%n", adder.intValue(), counter.longValue());
		});
		t1.start();
		t2.start();
	}
	
	public void stop(){
		stopFlag.set( true);
	}

	public static void main( String[] args) throws InterruptedException{
		AtomicSyncing atomic = new AtomicSyncing();
		atomic.startAdding( 2);
		Thread.sleep( 1000);
		atomic.stop();
	}
}
