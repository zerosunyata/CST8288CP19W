package examples.threads.syncing;

import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

import examples.threads.DataStack;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * <p>
 * in this example we can have multiple threads called producer and consumer. the idea
 * is for the producer threads to create data that is stored in the stack and the consumer
 * threads will remove the data from the stack. now the main objective is to make sure
 * threads are only working when there is data available or need to be produced. Consumer
 * threads should only work when there is data available in the stack. Producer threads
 * should only work when there is room available in the stack.
 * </p>
 * <p>
 * to achieve synchronization between consumer and producer we can use {@link ReentrantLock} 
 * which is similar to <code>synchronized</code>. {@link ReentrantLock} is better and faster
 * way of creating thread-safe code. {@link ReentrantLock} object itself is a lock. when the method
 * {@link ReentrantLock#lock()} is called only one thread can call it and pass it. the other
 * threads have to wait till {@link ReentrantLock#unlock()} is called and next thread can be
 * released. {@link ReentrantLock} is used with try and finally block. {@link ReentrantLock#lock()}
 * is called before the try and {@link ReentrantLock#unlock()} inside of finally to guarantee
 * the call of {@link ReentrantLock#unlock()} which will prevent dead locks.
 * </p>
 * <p>
 * {@link ReentrantLock} can create an object of type {@link Condition} using the method
 * {@link ReentrantLock#newCondition()}. this object can be used to force a thread to wait
 * or signal them out of wait. very similar to notify and wait. condition can only be used
 * by the thread that holds the lock that created the condition.
 * </p>
 * 
 * @author Shahriar (Shawn) Emami
 * @version Apr 7, 2019
 */
public class ProducerConsumerReentrantLock{
	
	private final Random RAND = new Random( 1);
	private final DataStack stack = new DataStack( 5);
	
	private final AtomicBoolean runningFlag = new AtomicBoolean( false);
	
	private final ExecutorService executor = Executors.newCachedThreadPool();
	
	private final ReentrantLock poducerLock = new ReentrantLock();
	private final ReentrantLock consumerLock = new ReentrantLock();
	
	private final Condition stackIsEmpty = consumerLock.newCondition();
	private final Condition stackIsFull = poducerLock.newCondition();


	public void producer(){
		//continue running as long as running flag is true
		while( runningFlag.get()){
			//Acquire the pLock if available, if not wait till it becomes available.
			//only one thread can hold the lock.
			poducerLock.lock();
			//try and finally is used primarily for the use of finally block.
			try{
				//as long as stack isFull and flag is true continue looping
				while( stack.isFull() && runningFlag.get()){
					try{
						//block/wait in this method till signaled
						stackIsFull.await();
					}catch( InterruptedException e){
						e.printStackTrace();
					}
				}
				int push = RAND.nextInt( 1000);
				stack.push( push);
				//it is possible there are more than one producer thread.
				//therefore, notify/signal all threads that might be waiting.
				stackIsFull.signal();
				System.out.println( "Pushed: " + push + ", " + stack);
			}finally{
				//release the lock that was acquired.
				//this is in finally block to guarantee its executions.
				poducerLock.unlock();
			}
			//notify all consumers who are are waiting in stackIsEmpty.await() of consumer.
			//this will force the threads to check the while loop again for valid condition.
			consumerLock.lock();
			try{
				stackIsEmpty.signal();
			}finally{
				consumerLock.unlock();
			}
		}
	}

	public void consumer(){
		//continue running as long as running flag is true
		while( runningFlag.get()){
			//Acquire the cLock if available, if not wait till it becomes available.
			//only one thread can hold the lock.
			consumerLock.lock();
			//try and finally is used primarily for the use of finally block.
			try{
				//as long as stack isEmpty and flag is true continue looping
				while( stack.isEmpty() && runningFlag.get()){
					try{
						//block/wait in this method till signaled
						stackIsEmpty.await();
					}catch( InterruptedException e){
						e.printStackTrace();
					}
				}
				int pop = stack.pop();
				//it is possible there are more than one consumer thread.
				//therefore, notify all threads that might be waiting.
				stackIsEmpty.signal();
				System.out.println( "Popped: " + pop + ", " + stack);
			}finally{
				//release the lock that was acquired.
				//this is in finally block to guarantee its executions.
				consumerLock.unlock();
			}
			//notify all producers who are are waiting in stackIsFull.await(); of producer.
			//this will force the threads to check the while loop again for valid condition.
			poducerLock.lock();
			try{
				stackIsFull.signal();
			}finally{
				poducerLock.unlock();
			}
		}
	}

	public void stop(){
		runningFlag.set( false);
		System.out.println( "shutdown executor");
		executor.shutdown();
	}

	public void simulate(){
		System.out.println( "Main Started");
		runningFlag.set( true);
		executor.submit( this::consumer);
		executor.submit( this::consumer);
		executor.submit( this::consumer);
		executor.submit( this::producer);
	}

	public static void main( String[] args) throws InterruptedException{
		ProducerConsumerReentrantLock pct = new ProducerConsumerReentrantLock();
		pct.simulate();
		TimeUnit.SECONDS.sleep( 5);
		pct.stop();
	}
}
