package examples.threads.syncing;

/**
 * <p>
 * in this class we can see the example of how key word volatile is used
 * to synchronize data between threads.
 * </p>
 * <p>
 * so what is volatile? when a thread is changing an object the change will not
 * always directly save the change to heap. instead the changes are cached in the
 * thread and periodically (not granted) saved back to heap. this will cause an
 * issue when multiple threads try to access the same object as the object
 * might not be the same from perspective of threads.
 * </p>
 * <p>
 * to mitigate this issue the keyword <code>volatile</code> is used on the class
 * Variable we want to guarantee synchronized access between threads. volatile
 * will force object to be directly updated on heap no data is cached.
 * </p>
 * <p>
 * the code below has two different functions, one uses volatile and one does not.
 * the method that does not use volatile has a chance of getting stuck in an infinite loop.
 * </p>
 * <p>
 * extra research, volatile also prevents line reordering by the java runtime (HotSpot).
 * </p>
 * 
 * @author Shahriar (Shawn) Emami
 * @version Apr 6, 2019
 */
public class ThreadSyncingUsingVolatile{

	/**
	 * create a counter object with volatile variable to guarantee
	 * counter is always saved on heap and not cached in thread.
	 */
	static class VolatileCounter{

		private volatile int counter = 0;

		public void increment(){
			++counter;
		}

		public int get(){
			return counter;
		}
	}

	/**
	 * create a counter object without volatile variable.
	 * counter variable will be cached in thread first.
	 */
	static class Counter{

		private int counter = 0;

		public void increment(){
			++counter;
		}

		public int get(){
			return counter;
		}
	}

	private VolatileCounter vCounter = new VolatileCounter();
	private Counter counter = new Counter();

	/**
	 * running this method will always guarantee that both threads will reach MAX_COUNT
	 * and both threads will properly quit when reaching MAX_COUNT.
	 * @param MAX_COUNT - the max number that both threads should reach before quitting
	 */
	public void startThreadWithVolatileCounter( final int MAX_COUNT) throws InterruptedException{
		//thread one increments value of VolatileCounter till it reaches MAX_COUNT
		Thread t1 = new Thread( () -> {
			while( vCounter.get() <= MAX_COUNT)
				vCounter.increment();
			System.out.println( "Thread increment stopped at: " + vCounter.get());
		});
		//thread two will continue checking VolatileCounter till MAX_COUNT is reach
		Thread t2 = new Thread( () -> {
			while( vCounter.get() <= MAX_COUNT);
			System.out.println( "Thread get stopped at: " + vCounter.get());
		});
		System.out.println( "Threads with volatile, stop at " + MAX_COUNT);
		t1.start();
		t2.start();
		t1.join();
		t2.join();
		System.out.println();
	}
	
	/**
	 * running this method will not guarantee that both threads will reach MAX_COUNT.
	 * this will cause thread 2 to get stuck in an infinite loop because after thread one
	 * reaches MAX_COUNT it will quit. the data that thread 2 is seeing is old and will never
	 * reach MAX_COUNT.
	 * @param MAX_COUNT - the max number that both threads should reach before quitting
	 */
	public void startThreadWithOutVolatileCounter( final int MAX_COUNT) throws InterruptedException{
		//thread one increments value of Counter till it reaches MAX_COUNT
		Thread t1 = new Thread( () -> {
			while( counter.get() <= MAX_COUNT)
				counter.increment();
			System.out.println( "Thread increment stopped at: " + counter.get());
		});
		//thread two will continue checking Counter till MAX_COUNT is reach
		Thread t2 = new Thread( () -> {
			while( counter.get() <= MAX_COUNT);
			System.out.println( "Thread get stopped at: " + counter.get());
		});
		System.out.println( "Threads without volatile, stop at " + MAX_COUNT);
		t1.start();
		t2.start();
		t1.join();
		t2.join();
		System.out.println();
	}

	/**
	 * run this code multiple times to catch when the program will stuck in an infinite loop.
	 */
	public static void main( String[] args) throws InterruptedException{
		ThreadSyncingUsingVolatile volatileThread = new ThreadSyncingUsingVolatile();
		volatileThread.startThreadWithVolatileCounter( 1000000);
		volatileThread.startThreadWithOutVolatileCounter( 1000000);
	}
}
