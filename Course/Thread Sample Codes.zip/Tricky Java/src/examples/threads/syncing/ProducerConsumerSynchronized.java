package examples.threads.syncing;

import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import examples.threads.DataStack;

/**
 * <p>
 * in this example we can have multiple threads called producer and consumer. the idea
 * is for the producer threads to create data that is stored in the stack and the consumer
 * threads will remove the data from the stack. now the main objective is to make sure
 * threads are only working when there is data available or need to be produced. Consumer
 * threads should only work when there is data available in the stack. Producer threads
 * should only work when there is room available in the stack.
 * </p>
 * <p>
 * to achieve synchronization between consumer and producer we can use <code>synchronized</code>.
 * synchronized is a keyword in java which guarantees a block of code is only accessed by one
 * thread and one thread only. synchronized takes an argument called a lock object. this object
 * can only be used by one thread at a time. this means if there is a synchronized block and a thread
 * enters the block of code it will take control of lock. from here on out if another thread tries
 * to enter the synchronized block it will be blocked till the last thread leaved the synchronized
 * code. synchronized can also be placed on a method signature making the whole method synchronized
 * using <code>this</code> as the lock. this is not the recommended way of using synchronized.
 * </p>
 * <p>
 * in this example we have two locks called pLock for producer and cLock for consumer. here we are
 * just using {@link Object} as the type for the locks. lock can be any object but it is good
 * practice to create dedicated lock objects. locks are used in conjunction with synchronized.
 * this is where we can use methods {@link Object#wait()} and {@link Object#notifyAll()}. {@link Object#wait()}
 * is used to force the thread that is running to be blocked indefinitely at this method. {@link Object#notifyAll()}
 * is used to unblock all threads that have been placed in wait state. these to methods are
 * directly connected to each other. they can only be called from inside of the synchronized
 * block which is using the lock you are calling these methods on.
 * </p>
 * 
 * @author Shahriar (Shawn) Emami
 * @version Apr 7, 2019
 */
public class ProducerConsumerSynchronized{

	private final Random RAND = new Random( 1);
	private final Object producerLock = new Object();
	private final Object consumerLock = new Object();
	private final DataStack stack = new DataStack( 5);
	private final AtomicBoolean runningFlag = new AtomicBoolean( false);

	public void producer(){
		//continue running as long as AtomicBoolean is true
		while( runningFlag.get()){
			//only allow one thread to execute the code in block below
			synchronized( producerLock){
				//as long as stack isFull and flag is true continue looping
				while( stack.isFull() && runningFlag.get()){
					try{
						//block/wait in this method till notified
						producerLock.wait();
					}catch( InterruptedException e){
						e.printStackTrace();
					}
				}
				//if stack is full continue
				if( stack.isFull())
					continue;
				int push = RAND.nextInt( 1000);
				stack.push( push);
				//it is possible there are more than one producer thread.
				//therefore, notify all threads that might be waiting.
				producerLock.notifyAll();
				System.out.println( "Pushed: " + push + ", " + stack);
			}
			//notify all consumers who are are waiting in consumerLock.wait() of consumer.
			//this will force the threads to check the while loop again for valid condition.
			synchronized( consumerLock){
				consumerLock.notifyAll();
			}
		}
	}

	public void consumer(){
		//continue running as long as AtomicBoolean is true
		while( runningFlag.get()){
			//only allow one thread to execute the code in block below
			synchronized( consumerLock){
				//as long as stack isEmpty and flag is true continue looping
				while( stack.isEmpty() && runningFlag.get()){
					try{
						//block/wait in this method till notified
						consumerLock.wait();
					}catch( InterruptedException e){
						e.printStackTrace();
					}
				}
				//if stack is empty continue
				if( stack.isEmpty())
					continue;
				int pop = stack.pop();
				//it is possible there are more than one consumer thread.
				//therefore, notify all threads that might be waiting.
				consumerLock.notifyAll();
				System.out.println( "Popped: " + pop + ", " + stack);
			}
			//notify all producers who are are waiting in roducerLock.wait(); of producer.
			//this will force the threads to check the while loop again for valid condition.
			synchronized( producerLock){
				producerLock.notifyAll();
			}
		}
	}

	public void stop(){
		System.out.println( "stopping");
		runningFlag.set( false);
	}

	public void simulate(){
		System.out.println( "Main Started");
		runningFlag.set( true);
		new Thread( this::consumer, "Consumer 1").start();
		new Thread( this::consumer, "Consumer 2").start();
		new Thread( this::consumer, "Consumer 3").start();
		new Thread( this::producer, "Producer 1").start();
		new Thread( this::producer, "Producer 2").start();
		new Thread( this::producer, "Producer 3").start();
		System.out.println( "Main exiting");
	}

	public static void main( String[] args) throws InterruptedException{
		ProducerConsumerSynchronized pct = new ProducerConsumerSynchronized();
		pct.simulate();
		TimeUnit.SECONDS.sleep( 5);
		pct.stop();
	}
}
