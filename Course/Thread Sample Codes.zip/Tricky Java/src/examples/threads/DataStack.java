package examples.threads;

import java.util.Arrays;

public class DataStack{

	private final int SIZE;
	private final int DATA[];
	private int index;

	public DataStack( final int SIZE){
		this.SIZE = SIZE;
		this.DATA = new int[SIZE];
		clear();
	}

	public void push( int num){
		if( isFull())
			throw new IllegalStateException( "DataStack is full");
		DATA[index++] = num;
	}

	public void push( int...nums){
		for( int num : nums)
			push( num);
	}

	public int pop(){
		if( isEmpty())
			throw new IllegalStateException( "DataStack is empty");
		int temp = DATA[--index];
		DATA[index] = -1;
		return temp;
	}
	
	public int peek(){
		if( isEmpty())
			throw new IllegalStateException( "DataStack is empty");
		return DATA[index];
	}

	public boolean isEmpty(){
		return index <= 0;
	}

	public boolean isFull(){
		return index >= SIZE;
	}
	
	public void clear(){
		for( int i = 0; i < DATA.length; i++)
			DATA[i] = -1;
		index = 0;
	}

	public String toString(){
		StringBuilder builder = new StringBuilder();
		builder.append( "Size: ");
		builder.append( SIZE);
		builder.append( ", Index: ");
		builder.append( index);
		builder.append( ", Array: ");
		builder.append( Arrays.toString( DATA));
		return builder.toString();
	}

	public static void main( String[] args){
		DataStack stack = new DataStack( 10);
		stack.push( 1, 2, 3, 4, 5);
		System.out.println( stack);
		System.out.printf( "Poped: %d, %s%n", stack.pop(), stack);
		System.out.printf( "Poped: %d, %s%n", stack.pop(), stack);
		System.out.printf( "Poped: %d, %s%n", stack.pop(), stack);
		System.out.printf( "Poped: %d, %s%n", stack.pop(), stack);
		System.out.printf( "Poped: %d, %s%n", stack.pop(), stack);
		stack.push( 1, 2, 3, 4, 5);
		System.out.println( stack);
		System.out.printf( "Poped: %d, %s%n", stack.pop(), stack);
		stack.push( 5);
		System.out.println( stack);
	}
}