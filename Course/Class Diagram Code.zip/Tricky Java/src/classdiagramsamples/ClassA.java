package classdiagramsamples;

public class ClassA implements InterfaceA<Double>{

	public static int staticVariable = 0;
	public final int FINAL_VARIABLE = 1;
	public static final int STATIC_FINAL_VARIABLE = 2;

	public int publicVariable=0;
	int defaultVariable=0;
	protected int protectedVariable=0;
	private int priavteVariable=0;
	
	@Override
	public Double methodAPublic( Double t){
		return null;
	}
	
	String methodADefault( String t){
		return null;
	}
	
	protected String methodAProtected( String t){
		return null;
	}
	
	private Double methodAPrivate( Double t){
		return null;
	}
}