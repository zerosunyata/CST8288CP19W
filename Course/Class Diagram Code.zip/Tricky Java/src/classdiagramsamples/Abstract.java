package classdiagramsamples;

public abstract class Abstract{
	
	public abstract void abstractMethod();
}
