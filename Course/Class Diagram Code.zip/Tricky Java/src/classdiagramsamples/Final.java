package classdiagramsamples;

public final class Final extends Abstract{

	public final void finalMethod(){
		
	}

	@Override
	public void abstractMethod(){
	}
}
