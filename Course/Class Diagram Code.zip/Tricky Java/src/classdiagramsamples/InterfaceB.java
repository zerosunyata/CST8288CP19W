package classdiagramsamples;

public interface InterfaceB<T extends Number> extends InterfaceA< T>{
	
	public T methodBPublic( T t);
}
