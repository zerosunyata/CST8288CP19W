package classdiagramsamples;

public class ClassB extends ClassA implements InterfaceB< Double>{

	@Override
	public Double methodAPublic( Double t){
		return null;
	}

	@Override
	public Double methodBPublic( Double t){
		return null;
	}
}
