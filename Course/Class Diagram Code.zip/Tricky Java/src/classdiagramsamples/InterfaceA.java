package classdiagramsamples;

public interface InterfaceA<T>{
	
	int defaultVariable=0;

	public static int staticVariable = 0;
	public final int FINAL_VARIABLE = 1;
	public static final int STATIC_FINAL_VARIABLE = 2;
	
	public T methodAPublic( T t);
	
	default public T defaultMethod(){
		return null;
	}
	
	public static <R> R staticMethod(){
		return null;
	}
}
