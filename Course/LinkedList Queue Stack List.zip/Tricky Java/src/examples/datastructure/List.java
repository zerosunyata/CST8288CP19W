package examples.datastructure;

/**
 * this interface is used on ADT (Abstract Data Type) like ArrayList, LinkedList and etc.
 * this list also enforces {@link Iterable} which allows the list to be placed in for each loop.
 * 
 * @author Shahriar (Shawn) Emami
 * @version Mar 12, 2019
 */
public interface List< E> extends Iterable< E>{

	void addFirst( E e);

	void addLast( E e);

	void add( E e, int index);

	void set( E e, int index);

	E removeFirst();

	E removeLast();

	E remove( int index);

	E remove( E e);

	E getFirst();

	E getLast();

	E get( int index);
	
	int indexOf( Object obj);
	
	boolean contains( Object obj);

	boolean isEmpty();

	int size();
	
	void clear();
}
