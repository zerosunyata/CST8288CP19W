package examples.datastructure;

/**
 * First In Last Out, FILO;
 * 
 * @author Shahriar (Shawn) Emami
 * @version Mar 12, 2019
 */
public interface Stack<E>{

	/**
	 * add the the given element to the end of the list
	 * @param r - the new element to be added
	 */
	void push(E e);
	
	/**
	 * remove the last element
	 * @return removed element
	 */
	E pop();

	/**
	 * @return the last element in the list
	 * @throws IndexOutOfBoundsException if given index is not valid
	 */
	E peekTop();
}
