package examples.datastructure;

import java.util.Iterator;

public class LinkedList <R> implements List<R>, Stack< R>, Queue< R>{
	
	private Node< R> head, tail;
	private int size;

	private class Node< T> {
		private Node< T> next;
		private T element;

		private Node( T t){
			this( t, null);
		}

		private Node( T t, Node< T> next){
			element = t;
			this.next = next;
		}

		@Override
		public int hashCode(){
			final int prime = 31;
			int result = 1;
			result = prime * result + ((next == null) ? 0 : next.hashCode());
			result = prime * result + ((element == null) ? 0 : element.hashCode());
			return result;
		}

		@Override
		public boolean equals( Object obj){
			if( this == obj)
				return true;
			if( obj == null)
				return false;
			if( getClass() != obj.getClass())
				return false;
			@SuppressWarnings( "unchecked")
			Node< T> other = (Node< T>) obj;
			if( element == null){
				if( other.element != null)
					return false;
			}else if( !element.equals( other.element))
				return false;
			return true;
		}

		@Override
		public String toString(){
			return element.toString();
		}
	}
	
	public LinkedList(){
	}
	
	/**
	 * create a list by copying the data from given list
	 * @param list - source of data to be copied
	 */
	public LinkedList( List< R> list){
		for(R r:list)
			addLast( r);
	}

	/**
	 * add the the given element to the end of the list
	 * @param r - the new element to be added
	 */
	@Override
	public void addLast( R r){
		add( r, size);
	}

	/**
	 * add the the given element to the beginning of the list
	 * @param r - the new element to be added
	 */
	@Override
	public void addFirst( R r){
		add( r, 0);
	}

	/**
	 * add the the given element to the at provided index. the old index will be pushed forward.
	 * @param r - the new element to be added
	 * @param index - index of position to be inserted
	 */
	@Override
	public void add( R r, int index){
		checkIndex( index);
		Node< R> insert, temp = new Node<>( r);
		if( isEmpty()){
			head = tail = temp;
		}else if( index==0){//head
			temp.next = head;
			head = temp;
		}else if( index==size){//tail
			tail.next = temp;
			tail = temp;
		}else {
			insert = getNodeBefore( index);
			temp.next = insert.next;
			insert.next = temp;
		}
		size++;
	}

	/**
	 * replace the current value of given index with the new data
	 * @param r - the new element to replace the current one
	 * @param index - the index to be updated
	 */
	@Override
	public void set( R r, int index){
		checkIndex( index);
		Node<R> node = getNodeBefore( index);
		if(node==null)
			head.element=r;
		else
			node.next.element=r;
	}
	
	/**
	 * remove the first element
	 * @return removed element
	 */
	@Override
	public R removeFirst(){
		return remove( 0);
	}
	
	/**
	 * remove the last element
	 * @return removed element
	 */
	@Override
	public R removeLast(){
		return remove( size-1);
	}
	
	/**
	 * remove the given element
	 * @return removed element or null if element not found.
	 */
	@Override
	public R remove( R e){
		int index = indexOf( e);
		if(index==-1)
			return null;
		return remove( index);
	}
	
	/**
	 * remove the element at the given index
	 * @return element as the given index after removal.
	 * @throws IndexOutOfBoundsException if given index is not valid
	 */
	@Override
	public R remove( int index){
		checkIndex( index);
		Node<R> temp, beforeIndex = getNodeBefore( index);
		size--;
		//removing from head
		if(beforeIndex==null){
			temp = head;
			head = head.next;
			temp.next = null;
			return temp.element;
		}else{
			temp = beforeIndex.next;
			beforeIndex.next = temp.next;
			//if next is null it has to be tail
			if(temp.next==null)
				tail = beforeIndex;
			temp.next = null;
			return temp.element;
		}
	}
	
	/**
	 * return the node before the index of the given index
	 * @param index - index of the node to find the node before it
	 * @return the node before the index of the given index. if index is zero or size, null.
	 * @throws IndexOutOfBoundsException if given index is not valid
	 */
	private Node<R> getNodeBefore( int index){
		checkIndex( index);
		if(index==size)
			throw new IndexOutOfBoundsException();
		if(index==0) 
			return null;
		if(index==1)
			return head;
		int i = 2;
		for( Node< R> e = head.next; e.next != null; e = e.next){
			//index is out of bound, index-1 will eventually reach tail, index-2 stops before tail
			if(i==index)
				return e;
			i++;
		}
		//should never be called as all conditions are already covered.
		return null;
	}
	
	/**
	 * @return the element as given index, 
	 * @throws IndexOutOfBoundsException if given index is not valid
	 */
	@Override
	public R get( int index){
		checkIndex( index);
		if(isEmpty())
			return null;
		if( index>=size-1)
			return tail.element;
		if( index==0)
			return head.element;
		int i = 1;
		//head condition already checked
		for( Node< R> n = head.next; n != null; n = n.next, i++){
			if(i==index)
				return n.element;
		}
		//should never be called as all conditions are already covered.
		return null;
	}
	
	/**
	 * @return the first element in the list
	 * @throws IndexOutOfBoundsException if given index is not valid
	 */
	@Override
	public R getFirst(){
		return get( 0);
	}
	
	/**
	 * @return the last element in the list
	 * @throws IndexOutOfBoundsException if given index is not valid
	 */
	@Override
	public R getLast(){
		return get(size);
	}
	
	/**
	 * find the index of given object.
	 * @param obj - Object to be checked against list for its index
	 * @return index of given object or -1 if not found or list is empty
	 */
	@Override
	public int indexOf( Object obj){
		if(isEmpty())
			return -1;
		int i=0;
		for( R r : this){
			if(obj==null||r.equals( obj))
				return i;
			i++;
		}
		return -1;
	}
	
	/**
	 * loop throw all elements and return true if object is found in list.
	 * Assumption, the containing data has implemented equals.
	 * @param obj - Object to be checked against list for existence
	 * @return true of object in list
	 */
	@Override
	public boolean contains( Object obj){
		return isIndexValid(indexOf( obj));
	}

	/**
	 *@return current size of list
	 */
	@Override
	public int size(){
		return size;
	}

	/**
	 * @return true of list is empty
	 */
	@Override
	public boolean isEmpty(){
		return size == 0;
	}

	/**
	 * clear the current list by setting head and tail to null and size to zero.
	 */
	@Override
	public void clear(){
		head = tail = null;
		size = 0;
	}
	
	/**
	 * if index is not between zero and list size
	 * @param index - index to check
	 * @return true if index is not between zero and list size
	 */
	private boolean isIndexValid( int index){
		return  index >= 0 && index <= size;
	}
	
	/**
	 * if index is not between zero and list size throw an exception 
	 * @param index - index to check
	 * @throws IndexOutOfBoundsException if index is not between zero and list size
	 */
	private void checkIndex( int index){
		if( !isIndexValid( index))
			throw new IndexOutOfBoundsException( " Index=\"" + index +"\" must be between zero and list size");
	}

	@Override
	public String toString(){
		StringBuffer str = new StringBuffer( "size:").append( size).append( ", [");
		String seprator = "";
		for( Node< R> e = head; e != null; e = e.next){
			str.append( seprator).append( e);
			seprator = ", ";
		}
		str.append( "]");
		return str.toString();
	}
	
	/**
	 * Allows the use of for each loop
	 * 
	 * @author Shahriar (Shawn) Emami
	 * @version Mar 12, 2019
	 */
	private class LinkedListIterator implements Iterator< R>{

		private Node<R> current = head;
		private int index = 0, prevIndex = 0;
		
		private LinkedListIterator(){
		}
		
		@Override
		public boolean hasNext(){
			return current!=null;
		}

		@Override
		public R next(){
			R temp = current.element;
			current = current.next;
			prevIndex = index++;
			return temp;
		}
		
		@Override
		public void remove(){
			LinkedList.this.remove( prevIndex);
			prevIndex--;
			index--;
		}
	}

	@Override
	public Iterator< R> iterator(){
		return new LinkedListIterator();
	}

	/**
	 * same as {@linkplain LinkedList#addFirst(Object)}
	 */
	@Override
	public void enqueue( R r){
		addLast( r);
	}

	/**
	 * same as {@linkplain LinkedList#removeFirst()}
	 */
	@Override
	public R dequeue(){
		return removeFirst();
	}

	/**
	 * same as {@linkplain LinkedList#getFirst()}
	 */
	@Override
	public R peekFront(){
		return getFirst();
	}

	/**
	 * same as {@linkplain LinkedList#addLast(Object)}
	 */
	@Override
	public void push( R r){
		addLast( r);
	}

	/**
	 * same as {@linkplain LinkedList#removeLast()}
	 */
	@Override
	public R pop(){
		return removeLast();
	}

	/**
	 * same as {@linkplain LinkedList#getLast()}
	 */
	@Override
	public R peekTop(){
		return getLast();
	}
	
	public static void main( String[] args){
		System.out.println( "List:");
		List< String> list = new LinkedList<>();
		list.addLast( "H");
		list.addLast( "e");
		list.addLast( "L");
		list.addLast( "l");
		list.addLast( "o");
		list.addFirst( "!");
		list.addFirst( "I");
		list.addFirst( "I");
		list.addFirst( "P");
		list.addFirst( "O");
		list.addFirst( "O");
		list.add( "?", 5);
		System.out.println( list);
		Iterator< String> iter = list.iterator();
		while( iter.hasNext()){
			String str = iter.next();
			if( str.matches( "(\\W)")){
				iter.remove();
			}else{
				System.out.print(str);
			}
		}
		System.out.println();
		System.out.println( list);
		System.out.printf( "removed: %d=%s, %s%n", 0, list.remove( 0), list);
		System.out.printf( "removed: %d=%s, %s%n", list.size(), list.removeLast(), list);
		System.out.printf( "removed: %d=%s, %s%n", 1, list.remove( 1), list);
		System.out.printf( "removed: %d=%s, %s%n", 4, list.remove( 4), list);
		System.out.printf( "removed: %d=%s, %s%n", list.size()-1, list.remove( list.size()-2), list);

		System.out.println();
		System.out.println();
		System.out.println( "Queue:");
		Queue< String> queue = new LinkedList<>();
		queue.enqueue( "First");
		System.out.printf( "enqueue: %s, %s%n", "First", queue);
		queue.enqueue( "Second");
		System.out.printf( "enqueue: %s, %s%n", "Second", queue);
		queue.enqueue( "Third");
		System.out.printf( "enqueue: %s, %s%n", "Third", queue);
		queue.enqueue( "Fourth");
		System.out.printf( "enqueue: %s, %s%n", "Fourth", queue);
		queue.enqueue( "Fifth");
		System.out.printf( "enqueue: %s, %s%n", "Fifth", queue);
		System.out.println();
		System.out.printf( "dequeue: %s, %s%n", queue.dequeue(), queue);
		System.out.printf( "dequeue: %s, %s%n", queue.dequeue(), queue);
		System.out.printf( "dequeue: %s, %s%n", queue.dequeue(), queue);
		System.out.printf( "dequeue: %s, %s%n", queue.dequeue(), queue);
		System.out.printf( "dequeue: %s, %s%n", queue.dequeue(), queue);

		System.out.println();
		System.out.println();
		System.out.println( "Stack:");
		Stack< String> stack = new LinkedList<>();
		stack.push( "First");
		System.out.printf( "enqueue: %s, %s%n", "First", stack);
		stack.push( "Second");
		System.out.printf( "enqueue: %s, %s%n", "Second", stack);
		stack.push( "Third");
		System.out.printf( "enqueue: %s, %s%n", "Third", stack);
		stack.push( "Fourth");
		System.out.printf( "enqueue: %s, %s%n", "Fourth", stack);
		stack.push( "Fifth");
		System.out.printf( "enqueue: %s, %s%n", "Fifth", stack);
		System.out.println();
		System.out.printf( "pop: %s, %s%n", stack.pop(), stack);
		System.out.printf( "pop: %s, %s%n", stack.pop(), stack);
		System.out.printf( "pop: %s, %s%n", stack.pop(), stack);
		System.out.printf( "pop: %s, %s%n", stack.pop(), stack);
		System.out.printf( "pop: %s, %s%n", stack.pop(), stack);
	}
}
