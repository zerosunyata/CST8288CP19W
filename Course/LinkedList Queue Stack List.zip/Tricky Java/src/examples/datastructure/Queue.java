package examples.datastructure;

/**
 * First In First Out, FIFO;
 * 
 * @author Shahriar (Shawn) Emami
 * @version Mar 12, 2019
 */
public interface Queue<E>{

	/**
	 * add the the given element to the end of the list
	 * @param r - the new element to be added
	 */
	void enqueue(E e);
	
	/**
	 * remove the first element
	 * @return removed element
	 */
	E dequeue();
	
	/**
	 * @return the first element in the list
	 * @throws IndexOutOfBoundsException if given index is not valid
	 */
	E peekFront();
}
