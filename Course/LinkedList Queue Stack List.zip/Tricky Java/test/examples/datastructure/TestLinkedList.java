package examples.datastructure;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Random;
import java.util.function.Function;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import examples.datastructure.LinkedList;
import examples.datastructure.List;

public class TestLinkedList{
	private Random rand = new Random();
	private List< Integer> list;

	@BeforeEach
	void setUp() throws Exception{
		list = new LinkedList<>();
	}

	@AfterEach
	void tearDown() throws Exception{
		list.clear();
	}

	< T> void loadSomeData( List< T> array, final int offset, final int COUNT, Function< Integer, T> sup){
		for( int i = offset; i < COUNT; i++)
			array.addLast( sup.apply( i));
	}

	< T> void loadSomeData( List< T> array, final int COUNT, Function< Integer, T> sup){
		loadSomeData( array, 0, COUNT, sup);
	}

	@Test
	final void testLinkedList(){
		assertNotNull( list);
		assertEquals( 0, list.size());
		assertTrue( list.isEmpty());
	}

	@Test
	final void testLinkedListInt(){
		list = new LinkedList<>();
		assertNotNull( list);
		assertEquals( 0, list.size());
		assertTrue( list.isEmpty());
	}

	@Test
	final void testLinkedListLinkedList(){
		loadSomeData( list, 9, i -> i);
		list = new LinkedList<>( list);
		assertNotNull( list);
		assertEquals( 9, list.size());
		assertFalse( list.isEmpty());
	}

	@Test
	final void testSize(){
		assertEquals( 0, list.size());
		assertTrue( list.isEmpty());
		loadSomeData( list, 9, i -> i);
		assertEquals( 9, list.size());
		assertFalse( list.isEmpty());
	}

	@Test
	final void testsize(){
		assertEquals( 0, list.size());
		loadSomeData( list, 9, i -> i);
		assertEquals( 9, list.size());
		list.addLast( 9);
		assertEquals( 10, list.size());
		loadSomeData( list, 10, 15, i->i);
		assertEquals( 15, list.size());
		list.addLast( 15);
		assertEquals( 16, list.size());
		loadSomeData( list, 16, 22, i->i);
		assertEquals( 22, list.size());
	}

	@Test
	final void testClear(){
		assertTrue( list.isEmpty());
		assertEquals( 0, list.size());
		list.clear();
		assertTrue( list.isEmpty());
		assertEquals( 0, list.size());
		loadSomeData( list, 9, i -> i);
		assertEquals( 9, list.size());
		assertFalse( list.isEmpty());
		list.clear();
		assertTrue( list.isEmpty());
		assertEquals( 0, list.size());
	}

	@Test
	final void testIsEmpty(){
		assertTrue( list.isEmpty());
		assertEquals( 0, list.size());
		list.clear();
		assertEquals( 0, list.size());
		assertTrue( list.isEmpty());
		loadSomeData( list, 9, i -> i);
		assertEquals( 9, list.size());
		assertFalse( list.isEmpty());
		list.clear();
		assertEquals( 0, list.size());
		assertTrue( list.isEmpty());
	}

	@Test
	final void testaddLastGeneric(){
		assertTrue( list.isEmpty());
		for( int i = 0; i < 100; i++){
			int num = rand.nextInt( Integer.MAX_VALUE);
			list.addLast( num);
			assertEquals( i + 1, list.size());
			assertEquals( num, (int) list.get( i));
		}
	}

	@Test
	final void testaddLastIntGeneric(){
		assertTrue( list.isEmpty());
		assertThrows( IndexOutOfBoundsException.class, () -> list.add( 1, -2));
		assertThrows( IndexOutOfBoundsException.class, () -> list.add( 1, -1));
		assertThrows( IndexOutOfBoundsException.class, () -> list.add( 1, 1));
		assertThrows( IndexOutOfBoundsException.class, () -> list.add( 1, 2));
		loadSomeData( list, 5, i -> i);
		list.add( 6, 0);
		list.add( 7, list.size() / 2);
		list.add( 8, list.size() - 1);
		assertEquals( 6, (int) list.get( 0));
		assertEquals( 7, (int) list.get( 3));
		assertEquals( 8, (int) list.get( list.size() - 2));
	}

	@Test
	final void testaddLastIntGenericRandom(){
		assertTrue( list.isEmpty());
		assertThrows( IndexOutOfBoundsException.class, () -> list.add( 1, -2));
		assertThrows( IndexOutOfBoundsException.class, () -> list.add( 1, -1));
		assertThrows( IndexOutOfBoundsException.class, () -> list.add( 1, 1));
		assertThrows( IndexOutOfBoundsException.class, () -> list.add( 1, 2));
		java.util.LinkedList< Integer> linkedList = new java.util.LinkedList<>();
		list.add( 0, 0);
		linkedList.add( 0, 0);
		assertEquals( 1, list.size());
		assertEquals( 0, (int) list.get( 0));
		for( int i = 1; i < 100; i++){
			int insertIndex = rand.nextInt( list.size());
			int num = rand.nextInt( Integer.MAX_VALUE);
			linkedList.add( insertIndex, num);
			list.add( num, insertIndex);
			assertEquals( i + 1, list.size());
			assertEquals( num, (int) list.get( insertIndex));
		}
		for( int i = 0; i < list.size(); i++){
			assertEquals( linkedList.get( i), list.get( i));
		}
	}

	@Test
	final void testContains(){
		assertFalse( list.contains( null));
		assertTrue( list.isEmpty());
		assertFalse( list.contains( 1));
		assertFalse( list.contains( 2));
		assertFalse( list.contains( 3));
		assertFalse( list.contains( 4));
		for( int i = 0; i < 100; i++){
			int num = rand.nextInt( Integer.MAX_VALUE);
			list.addLast( num);
			assertTrue( list.contains( num));
		}
	}

	@Test
	final void testGet(){
		assertTrue( list.isEmpty());
		assertThrows( IndexOutOfBoundsException.class, () -> list.get( -2));
		assertThrows( IndexOutOfBoundsException.class, () -> list.get( -1));
		assertNull( list.get( 0));
		assertThrows( IndexOutOfBoundsException.class, () -> list.get( 1));
		assertThrows( IndexOutOfBoundsException.class, () -> list.get( 2));
		list.addLast( 0);
		list.addLast( 1);
		for( int i = 2; i < 100; i++){
			list.addLast( i);
			assertEquals( i - 2, (int) list.get( i - 2));
			assertEquals( i - 1, (int) list.get( i - 1));
			assertEquals( i, (int) list.get( i));
		}
	}

	@Test
	final void testIndexOf(){
		String error = "error could be because of dublicated value and random "
				+ "nature of test run it agian with larger max value if possible";
		assertTrue( list.isEmpty());
		assertEquals( -1, list.indexOf( null));
		for( int i = 0; i < 100; i++){
			int num = rand.nextInt( Integer.MAX_VALUE);
			list.addLast( num);
			assertEquals( list.size() - 1, (int) list.indexOf( num), error);
		}
	}

	@Test
	final void testRemoveInt(){
		String error = "error could be because of dublicated value and random "
				+ "nature of test run it agian with larger max value if possible";
		assertTrue( list.isEmpty());
		assertThrows( IndexOutOfBoundsException.class, () -> list.remove( -2));
		assertThrows( IndexOutOfBoundsException.class, () -> list.remove( -1));
		assertThrows( IndexOutOfBoundsException.class, () -> list.remove( 0));
		assertThrows( IndexOutOfBoundsException.class, () -> list.remove( 1));
		assertThrows( IndexOutOfBoundsException.class, () -> list.remove( 2));
		java.util.LinkedList< Integer> linkedList = new java.util.LinkedList<>();
		loadSomeData( list, 100, i -> rand.nextInt( Integer.MAX_VALUE));
		for( int i = 0; i < list.size(); i++){
			linkedList.add( list.get( i));
		}
		assertEquals( 100, list.size());
		assertEquals( linkedList.remove( 0), list.remove( 0), error);
		assertEquals( linkedList.remove( 1), list.remove( 1), error);
		assertEquals( linkedList.remove( 2), list.remove( 2), error);
		assertEquals( linkedList.remove( linkedList.size()/2), list.remove( list.size()/2), error);
		assertEquals( linkedList.remove( linkedList.size()-2), list.remove( list.size()-2), error);
		assertEquals( linkedList.remove( linkedList.size()-1), list.remove( list.size()-1), error);
		for( int i = 1; i < 1000; i++){
			int insertIndex = rand.nextInt( list.size());
			int num = rand.nextInt( Integer.MAX_VALUE);
			list.add( num, insertIndex);
			assertEquals( 95, list.size());
			assertEquals( num, (int) list.remove( insertIndex), error);
			assertEquals( 94, list.size());
		}
		for( int i = 0; i < list.size(); i++){
			assertEquals( linkedList.get( i), list.get( i));
		}
	}

	@Test
	final void testRemoveGeneric(){
		String error = "error could be because of dublicated value and random "
				+ "nature of test run it agian with larger max value if possible";
		assertTrue( list.isEmpty());
		assertNull( list.remove( null));
		assertNull( list.remove( Integer.valueOf( -2)));
		assertNull( list.remove( Integer.valueOf( -1)));
		assertNull( list.remove( Integer.valueOf( 0)));
		assertNull( list.remove( Integer.valueOf( 1)));
		assertNull( list.remove( Integer.valueOf( 2)));
		java.util.LinkedList< Integer> linkedList = new java.util.LinkedList<>();
		loadSomeData( list, 100, i -> rand.nextInt( Integer.MAX_VALUE));
		for( int i = 0; i < list.size(); i++){
			linkedList.add( list.get( i));
		}
		assertEquals( 100, list.size());
		for( int i = 1; i < 1000; i++){
			int insertIndex = rand.nextInt( list.size());
			int num = rand.nextInt( Integer.MAX_VALUE);
			list.add( num, insertIndex);
			assertEquals( 101, list.size());
			assertNotNull( list.remove( Integer.valueOf( num)), error);
			assertEquals( 100, list.size());
		}
		for( int i = 0; i < list.size(); i++){
			assertEquals( linkedList.get( i), list.get( i));
		}
	}

	@Test
	final void testSet(){
		assertTrue( list.isEmpty());
		assertThrows( IndexOutOfBoundsException.class, () -> list.set( -2, 1));
		assertThrows( IndexOutOfBoundsException.class, () -> list.set( -1, 1));
		assertThrows( IndexOutOfBoundsException.class, () -> list.set( 1, 1));
		assertThrows( IndexOutOfBoundsException.class, () -> list.set( 2, 1));
		loadSomeData( list, 100, i -> 100 - i);
		assertEquals( 100, list.size());
		for( int i = 0; i < 100; i++){
			list.set( i, i);
			assertEquals( 100, list.size());
			assertEquals( i, (int) list.get( i));
		}
	}
	
	@Test
	final void testToString(){
		loadSomeData( list, 5, i->i);
		assertEquals( "size:5, [0, 1, 2, 3, 4]", list.toString());
	}
}
