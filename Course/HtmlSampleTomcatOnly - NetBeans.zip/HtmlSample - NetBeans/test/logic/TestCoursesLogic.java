package logic;

import business.CourseLogic;
import hthurow.tomcatjndi.TomcatJNDI;

import java.nio.file.Files;
import java.nio.file.Paths;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * a demo of JUnit for running a test on DAO with Tomcat using TomcatJNDI. for netbeans add Junit and Hamcrest to TestLibraries. then add the 2 jar
 * files tomcat8jndi and tomcat-juli to same folder. for eclipse follow the above steps but just add them to your project by right clicking then
 * adding as library.
 *
 * @author Shahriar (Shawn) Emami
 * @date November 11, 2018
 * @see <a href="https://www.youtube.com/watch?v=N8uZnPR5QVw">JUnit tutorial(youtube)</a>
 * @see <a href="https://github.com/h-thurow/TomcatJNDI">TomcatJNDI for JUnit</a>
 */
public class TestCoursesLogic {

    private static TomcatJNDI tomcatJNDI;
    private CourseLogic logic;

    @BeforeClass
    public static void setUpClass() {
        tomcatJNDI = new TomcatJNDI();
        String webFolder = "web";
        if (!Files.exists(Paths.get(webFolder))) {
            webFolder = "WebContent";
        }
        tomcatJNDI.processContextXml(Paths.get(webFolder + "\\META-INF\\context.xml").toFile());
        tomcatJNDI.processWebXml(Paths.get(webFolder + "\\WEB-INF\\web.xml").toFile());
        tomcatJNDI.start();
    }

    @Before
    public void setup() {
        logic = new CourseLogic();
    }

    @Test
    public void testGetAllCourses() {
        assertEquals(24, logic.getAllCourses().size());
    }

    @After
    public void tearDown() {
        logic = null;
    }

    @AfterClass
    public static void tearDownClass() {
        tomcatJNDI.tearDown();
    }
}
