package dto.factory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * this abstract class inherits form Factory interface. it implements any common method between all Factories.</br>
 * </p>
 * 
 * @author Shawn
 * @param <T> - Type of DTO to be created in this factory
 */
public abstract class AbstractFactory< T> implements Factory< T> {
    
    /**
     * this method creates a {@link List} of DTOs from the given {@link ResultSet}.
     * this method can simply call {@link Factory#createFromResultSet(java.sql.ResultSet)} multiple times.
     *
     * @param rs - SQL server courser
     * @return list of created DTOs, if none {@link Collections#emptyList()} is returned
     * @throws SQLException - something gone wrong with reading the results
     */
    @Override
    public List< T> createListFromResultSet(ResultSet rs) throws SQLException {
        //create a list and store the created dtos in it.
        //finlay return the list.
        List< T> dtos = new ArrayList<>(100);
        T dto = null;
        while ((dto = createFromResultSet(rs)) != null) {
            dtos.add(dto);
        }
        return dtos;
    }
}
