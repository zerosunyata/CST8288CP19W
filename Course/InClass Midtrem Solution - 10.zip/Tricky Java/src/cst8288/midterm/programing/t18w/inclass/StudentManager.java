package cst8288.midterm.programing.t18w.inclass;

import java.util.LinkedList;
import java.util.Random;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class StudentManager {

	private Random rand;
	private ObservableList<Student> students;
	
	public StudentManager() {
		rand = new Random();
//		LinkedList<Student> temp = new LinkedList<Student>();
//		students = FXCollections.observableList(temp);
		students = FXCollections.observableList(new LinkedList<Student>());
	}
	
	public void addStudent( String fName, String lName) {
		Student s = new Student(fName, lName, rand.nextLong());
		students.add(s);
	}
	
	public ObservableList<Student> getStudents(){
		return students;
	}
}
