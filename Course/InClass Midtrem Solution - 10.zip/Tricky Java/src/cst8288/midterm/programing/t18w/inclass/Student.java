package cst8288.midterm.programing.t18w.inclass;

public class Student {

	private final long ID;
	private String fName, lName;
	
	public Student( String fName, String lName, long ID) {
		this.ID = ID;
		setName( fName, lName);
	}

	public void setName(String fName2, String lName2) {
		if( fName2!=null && lName2!=null) {
			fName = fName2;
			lName = lName2;
		}
	}

	public long getID() {
		return ID;
	}

	public String getfName() {
		return fName;
	}

	public String getlName() {
		return lName;
	}
	
	@Override
	public String toString() {
		return String.format("Student: %s, %s, ID: %d%n", lName, fName,ID);
	}
}
