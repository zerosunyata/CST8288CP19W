package cst8288.midterm.programing.t18w.inclass;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import javafx.application.Application;
import javafx.collections.ListChangeListener.Change;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class StudentViewSkeleton extends Application{

	private Button start, stop, clear;
	private TextArea area;

	private AtomicBoolean alive; 
	private StudentManager manager; 
	
	@Override
	public void init() throws Exception{
		super.init();
		alive = new AtomicBoolean();
		manager = new StudentManager();
	}

	@Override
	public void start( Stage primaryStage) throws Exception{
		area = new TextArea();
		area.setEditable( false);

		start = new Button( "Start");
		stop = new Button( "Stop");
		clear = new Button( "Clear");

		GridPane controlPane = new GridPane();
		controlPane.setHgap( 5);
		controlPane.setVgap( 5);
		controlPane.setPadding( new Insets( 5));
		controlPane.add( start, 0, 0);
		controlPane.add( stop, 0, 1);
		controlPane.add( clear, 0, 2);

		BorderPane rootPane = new BorderPane();
		rootPane.setCenter( area);
		rootPane.setRight( controlPane);

		Scene scene = new Scene( rootPane, 500, 300);
		primaryStage.setScene( scene);
		primaryStage.setTitle( "Student MVC-O");
		primaryStage.addEventHandler( KeyEvent.KEY_RELEASED, ( KeyEvent event) -> {
			if( KeyCode.ESCAPE == event.getCode()){
				primaryStage.hide();
			}
		});
		primaryStage.show();
		registerListeners();
	}
	
	@Override
	public void stop() throws Exception{
		super.stop();
		alive.set( false);
	}
	
	public void registerListeners(){
		//start.setOnAction(e->startDataThread(e));
		start.setOnAction(this::startDataThread);
		//stop.setOnAction(e->stopDataThread(e));
		stop.setOnAction(this::stopDataThread);
		clear.setOnAction(e -> area.clear());
		manager.getStudents().addListener( this::createStudents);
	}

	public void stopDataThread( ActionEvent e){
		alive.set(false);
	}

	public void createStudents( Change< ? extends Student> c){
		if (c.next()) {
			List< ? extends Student> updates = c.getAddedSubList();
			for (Student student : updates) {
				area.appendText(student.toString());
			}
		}
	}

	public void startDataThread( ActionEvent e){
		Runnable run = ()->{
			alive.set(true);
			for (int i = 0; i < 100 && alive.get(); i++) {
				try {
					Thread.sleep(50);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				manager.addStudent(i+"", Integer.toString(i));
			}
		};
		Thread t = new Thread(run);
		t.start();
	}

	public static void main( String[] args){
		launch( args);
	}
}
