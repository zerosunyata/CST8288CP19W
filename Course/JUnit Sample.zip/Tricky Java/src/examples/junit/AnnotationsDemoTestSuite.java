package examples.junit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/**
 * a demo of JUnit 4 for running multiple set of test classes
 * 
 * @author J Steven Perry
 * @version Sep 19, 2016
 * @author Shahriar (Shawn) Emami
 * @version Sep 14, 2017
 * @see <a href="https://www.youtube.com/watch?v=N8uZnPR5QVw">JUnit 4 tutorial(youtube)</a>
 */
//this annotation defines what type of runner is used to run the test
//we used the built in runner.
@RunWith( Suite.class)
//this annotation runs the test in all given class
@SuiteClasses( { AnnotationsDemoTest.class/* , more classes if any */ })
public class AnnotationsDemoTestSuite{

	@BeforeClass
	public static void setupBeforeSuiteRuns(){
		System.out.println( "@BeforeClass - Runs one time, before the test suite.");
	}

	@AfterClass
	public static void tearDownAfterSuiteRuns(){
		System.out.println( "@AfterClass - Runs one time, after all tests in the test suite.");
	}
}