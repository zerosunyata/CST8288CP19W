package examples.junit;

import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.After;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import static org.junit.Assert.*;
import static org.hamcrest.core.Is.*;
import static org.hamcrest.core.IsNull.*;

/**
 * a demo of JUnit 4 for StudentExample
 * 
 * @author J Steven Perry
 * @version Sep 19, 2016
 * @author Shahriar (Shawn) Emami
 * @version Jan 18, 2018
 * @version Sep 14, 2017
 * @see <a href="https://www.youtube.com/watch?v=N8uZnPR5QVw">JUnit 4 tutorial(youtube)</a>
 * @see <a href="https://github.com/junit-team/junit4/wiki/exception-testing">Eception handelong in JUnit 4</a>
 * @see <a href="https://objectpartners.com/2013/09/18/the-benefits-of-using-assertthat-over-other-assert-methods-in-unit-tests/">Benifest of assertThat</a>
 */
public class AnnotationsDemoTest {

	/**
	 * class object of student to be used in all tests
	 */
	private StudentExample student;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("@BeforeClass - Runs one time, before any tests in this class.");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("@AfterClass - Runs one time, after all tests in this class.");
	}

	@Before
	public void setUp() throws Exception {
		System.out.println("@Before - Runs before each test in this class.");
		student = new StudentExample( "John", "Doe", "jd");
		assertNotNull(student);
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("@After - Runs after each test in this class.");
		student = null;
	}

	//use to skip a test
	@Ignore("SKIPPING THIS TEST!")
	@Test
	public void testReturn1() {
		//Enforce a fail 
		fail("Not yet implemented");
	}

	@Test
	public void testwithAsserThat() {
		System.out.println("@Test - Running testwithAsserThat...");
		//Benefit of assertThat is just readability
		//pairs of asserts bellow do the same thing
		assertThat("Match Name", "John",  is(student.getFirstName()));
		assertEquals("Match Name", "John",  student.getFirstName());
		
		assertThat("Check not null", student, is(notNullValue()));
		assertNotNull("Check not null", student);
	}

	@Rule
	public ExpectedException thrown = ExpectedException.none();
	@Test
	public void testGPAWithExceptionWithRule() {
		System.out.println("@Test - Running testGPAWithException...");
        thrown.expect(IllegalArgumentException.class);
		student.setGPA(-1);
	}
	
	@Test
	public void testGPAWithExceptionWithOutRule() {
		System.out.println("@Test - Running testGPAWithException...");
        try{
        	student.setGPA(-1);
        	assertTrue("Negative was accepted",false);
        }catch(IllegalArgumentException ex){
        	assertTrue("Negative was not accepted",true);
        }
	}
	
	@Test
	public void testGPAAccuracy() {
		System.out.println("@Test - Running testDecimal...");
		student.setGPA(3.9873);
		//define an acceptable error range for the number being checked
		float delta = 0.01f;
		assertEquals( "close enough", 3.98, student.getGPA(), delta);
	}
}