//Package for class placement
package examples.junit;

import java.util.ArrayList;
import java.util.regex.Pattern;

/**
 * sample class structure for a student
 * 
 * @author Shahriar (Shawn) Emami
 * @version Jan 18, 2018
 * @version Sep 16, 2017
 */
public class StudentExample{

	// order bellow is optional however grouping similar categories is recommended
	// add documentation to attributes as needed when name is not clear or there is a special behavior.
	
	/**
	 * Standard nickname to be used for all students
	 */
	private static final String DEFAULT_NICKNAME = "none";
	
	/**
	 *  match any string which starts with 3 letters followed by 4 numbers
	 *  using pattern "\\b\\p{Alpha}{3}\\p{Digit}{4}\\b"
	 */
	private static final String COURSE_PATTERN = "\\b\\p{Alpha}{3}\\p{Digit}{4}\\b";
	private static final Pattern PATTERN = Pattern.compile( COURSE_PATTERN);
	//default id to be used for test students
	private static final int TEST_ID = 0;
	
	private static int ID_COUNTER = 1;

	// must be initialized in constructor
	private final String FIRST_NAME;
	private final String LAST_NAME;
	private final int STUDENT_ID;
	
	private ArrayList<String> courses;
	private String nickName;
	private double gpa;
	
	/**
	 * default constructor, without any arguments
	 * not used here just for sake of details
	 */
	protected StudentExample(){
		//super(); is implied and not necessary
		this( "John/Jane", "Doe", "none", TEST_ID);
	}

	/**
	 * create a student object with given parameters 
	 * @param FIRST - final variable for student first name, cannot be null
	 * @param LAST - final variable for student last name, cannot be null
	 * @param nickName - changeable nickname, if null "none" is used
	 * @throws NullPointerException if first or last name is null
	 */
	public StudentExample( final String FIRST, final String LAST, String nickName){
		//super(); is implied and not necessary
		//using this you can chain constructors
		this( FIRST, LAST, nickName, ID_COUNTER++);
	}

	/**
	 * create a student object with given parameters  
	 * @param FIRST - final variable for student first name, cannot be null
	 * @param LAST - final variable for student last name, cannot be null
	 * @param nickName - changeable nickname, if null "none" is used
	 * @param ID - final integer for ID, cannot be negative
	 * @throws NullPointerException if first or last name is null
	 * @throws IllegalArgumentException if ID is negative, internal error only since ID_COUNTER is not public
	 */
	private StudentExample( final String FIRST, final String LAST, String nickName, final int ID){
		//super(); is implied and not necessary
		//error checking
		if( FIRST==null || LAST==null) {
			//NullPointerException is a RunTimeExceptions meaning it does not force try and catch block
			//unlike exceptions like IOException which much have try and catch or throws statement on method.
			//for more information read about checked and unchecked exceptions
			throw new NullPointerException( "First or last name cannot be null");
		}
		if( ID<0) {
			//IllegalArgumentException is a RunTimeExceptions
			throw new IllegalArgumentException( "ID must be a positive integer");
		}
		STUDENT_ID = ID;
		//it is better to call your setter instead of directly assigning
		//Specially if you have proper error handling in setter
		setNickName( nickName);
		FIRST_NAME = FIRST;
		LAST_NAME = LAST;
		courses = new ArrayList<>();
		gpa = -1;//meaning it is not set, or use a static final variable for -1 instead
	}

	/**
	 * Document your getters to something meaningful not just "this is a getter"
	 * Documentation should reflect the behavior and return of your method
	 * @return a number (can be more specific too like the range of number or format of string)
	 */
	public ArrayList< String> getCourses(){
		return courses;
	}

	/**
	 * @return the First Name
	 */
	public String getFirstName(){
		return FIRST_NAME;
	}

	/**
	 * @return the Last Name
	 */
	public String getLastName(){
		return LAST_NAME;
	}

	/**
	 * @return the Student ID
	 */
	public int getStudentID(){
		return STUDENT_ID;
	}

	/**
	 * @return the Nick Name
	 */
	public String getNickName(){
		return nickName;
	}
	
	/**
	 * @return GPA of this student
	 */
	public double getGPA() {
		return gpa;
	}

	/* MODIFIERS ----------------------------------------------------- */
	/**
	 * Document your setters to something meaningful not just "this is a setter".
	 * set a nickname for the this student
	 * @param nickName - string value, if null "none" will be used
	 */
	public void setNickName( String nickName){
		//condition?true:false is short form of if and else block
		this.nickName = nickName==null?DEFAULT_NICKNAME:nickName;
	}
	
	/**
	 * set a new gpa for this student, gpa cannot be negative
	 * @param gpa - a non negative number
	 * @throws IllegalArgumentException if GPA is negative number
	 */
	public void setGPA( double gpa) /*throws IllegalArgumentException*/{
		if( gpa<0) {//Optionally max limit can be added as well
			// throw an exception because student cannot have negative gpa 
			throw new IllegalArgumentException("GPA cannot be negative");
		}
		this.gpa = gpa;
	}

	/**
	 * add new courses from an array list.
	 * for more details {@link StudentExample#addCourse(String)}
	 * @param courses - list of courses to be appended
	 */
	//this method overload the other addCourse method
	public void addCourse( ArrayList< String> courses){
		if( courses!=null){
			for( String course: courses) {
				addCourse( course);
			}
		}
	}

	/**
	 * Append one course to this student.
	 * each entry will be trimmed and raised to upper case.
	 * if course is null or does not match 
	 * 3 letters followed by 4 numbers it will be ignored
	 * @param courses the courses to set
	 */
	//this method overload the other addCourse method
	public void addCourse( String course){
		if( course!=null){
			// remove any extra spaces and change to upper case
			course = course.trim().toUpperCase();
			if(matches(course)) {
				this.courses.add( course);
			}
		}
	}

	/**
	 * Convert this class to a meaningful string. meaning need to be sufficient enough to be useful in your debugging.
	 * @return This class as a meaningful string.
	 */
	public String toString(){
		return "[Student=" + FIRST_NAME + " " + LAST_NAME + ", ID=" + STUDENT_ID + ", Courses=" + courses.toString() + "]";
	}

	/* HELPER METHODS ------------------------------------------------- */
	/**
	 * private method for matching course name pattern.
	 * must follow {@link StudentExample#COURSE_PATTERN}
	 * @param str - string to be checked
	 * @return true if matches
	 */
	private static boolean matches( String str) {
		return PATTERN.matcher( str).matches();
	}

	/* ENTRY POINT for STAND-ALONE OPERATION -------------------------- */
	/**
	 * Entry point "main()" as required by the JVM.
	 * @param args Standard command line parameters (arguments) as a
	 *            string array.
	 */
	public static void main( String args[]){
		StudentExample student = new StudentExample( "John", "Doe", "jd");
		student.setGPA( 3.11);
		student.addCourse("CST8288");
		ArrayList<String> courses = new ArrayList<>();
		courses.add( "CST8102");
		student.addCourse(courses);
		System.out.println( student);
	}
}