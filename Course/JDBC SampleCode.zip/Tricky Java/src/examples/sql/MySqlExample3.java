package examples.sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MySqlExample3{

	public static void main( String[] args){

		String connectionString = "jdbc:mysql://localhost/books";
		String username = "cst8288";
		String password = "8288";

		// close connection when everything is done
		try( Connection connection = DriverManager.getConnection( connectionString, username, password)){
			executeAndPrint( MySqlExample3::printAuthors, connection, "SELECT * from authors");
			executeAndPrint( MySqlExample3::printAuthorISBN, connection, "SELECT * from authorisbn");
			executeAndPrint( MySqlExample3::printTitles, connection, "SELECT * from titles");
			executeAndPrint( MySqlExample3::printAuthors, connection, "select * from authors where LastName='Deitel' order by AuthorID asc");
			executeAndPrint( MySqlExample3::printTitles, connection, "select * from titles where Title like '%how%' order by Title asc");
			// UPDATE authors SET LastName='Deitel2' WHERE AuthorID=3;
			// UPDATE authors SET LastName='Deitel' WHERE AuthorID=3;
			// INSERT INTO authors VALUES ( 6, "Shawn","Emami" );
			// delete from authors where AuthorID=6;
		}catch( SQLException e){
			e.printStackTrace();
		}
	}

	/**
	 * execute query and print the content of ResultSet
	 * @param connection
	 * @param query
	 * @param printer
	 * @throws SQLException
	 */
	public static void executeAndPrint( TablePrinter< ResultSet> printer, Connection connection, String query) throws SQLException{
		// close both statement and result when everything is done
		try( PreparedStatement statement = connection.prepareStatement( query);
				ResultSet result = statement.executeQuery()){
			printer.print( result);
		}
	}

	/**
	 * print all content received from results
	 * @param result
	 * @throws SQLException
	 */
	public static void printAuthors( ResultSet result) throws SQLException{
		System.out.printf( "%-9s%-10s%-10s%n", "AuthorID", "FirstName", "LastName");
		while( result.next()){
			System.out.printf( "%-9d%-10s%-10s%n", result.getInt( "AuthorID"), result.getString( "FirstName"),
					result.getString( "LastName"));
		}
	}

	/**
	 * print all content received from results
	 * @param result
	 * @throws SQLException
	 */
	public static void printTitles( ResultSet result) throws SQLException{
		System.out.printf( "%-16s%-55s%-8s%-10s%n", "ISBN", "Title", "Edition", "Copyright");
		while( result.next()){
			System.out.printf( "%-16s%-55s%-8d%-10s%n", result.getString( "ISBN"), result.getString( "Title"),
					result.getInt( "EditionNumber"), result.getString( "Copyright"));
		}
	}

	/**
	 * print all content received from results
	 * @param result
	 * @throws SQLException
	 */
	public static void printAuthorISBN( ResultSet result) throws SQLException{
		System.out.printf( "%-9s%-10s%n", "AuthorID", "ISBN");
		while( result.next()){
			System.out.printf( "%-9d%-10s%n", result.getInt( "AuthorID"), result.getString( "ISBN"));
		}
	}

	/**
	 * interface for passing method reference of print methods.
	 * this interface is same is Consumer<T> but throws exception
	 * 
	 * @author Shahriar (Shawn) Emami
	 * @date Dec 12, 2017
	 */
	@FunctionalInterface
	private interface TablePrinter< T> {
		public void print( T t) throws SQLException;
	}
}
