package examples.sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MySqlExample2 {

	private static final int AUTHORS = 0;
	private static final int AUTHORISBN = 1;
	private static final int TITLES = 2;
	
	public static void main(String[] args) {
		String connectionString = "jdbc:mysql://localhost/books";
		String username = "cst8288";
		String password = "8288";
		
		try (Connection connection = DriverManager.getConnection(connectionString, username, password)){
			queryAndPrint(connection, "SELECT * from books.authors", AUTHORS);
			queryAndPrint(connection, "SELECT * from books.authorisbn", AUTHORISBN);
			queryAndPrint(connection, "SELECT * from books.titles", TITLES);
			queryAndPrint(connection, "select * from books.authors where LastName='Deitel' order by AuthorID asc", AUTHORS);
			queryAndPrint(connection, "select * from books.titles where Title like '%how%' order by Title asc", TITLES);
			//UPDATE books.authors SET LastName='Deitel2' WHERE AuthorID=3;
			//UPDATE books.authors SET LastName='Deitel' WHERE AuthorID=3;
			//INSERT INTO books.authors VALUES ( 6, "Shawn","Emami" );
			//delete from books.authors where AuthorID=6;
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void queryAndPrint(Connection connection, String query, int printType)throws SQLException{
		try(PreparedStatement statement = connection.prepareStatement(query)){
			ResultSet result = statement.executeQuery();
			switch( printType){
				case AUTHORS:printAuthors(result);break;
				case AUTHORISBN:printAuthorISBN(result);break;
				case TITLES:printTitles(result);break;
				default: throw new IllegalArgumentException("invalid print type");
			}
		}
	}

	public static void printAuthors(ResultSet result) throws SQLException {
		System.out.printf("%-9s%-10s%-10s%n", "AuthorID", "FirstName","LastName");
		while (result.next()) {
			System.out.printf("%-9d%-10s%-10s%n", result.getInt("AuthorID"), result.getString("FirstName"),
					result.getString("LastName"));
		}
	}

	public static void printTitles(ResultSet result) throws SQLException {
		System.out.printf("%-16s%-55s%-8s%-10s%n", "ISBN", "Title","Edition","Copyright");
		while (result.next()) {
			System.out.printf("%-16s%-55s%-8d%-10s%n", result.getString("ISBN"), result.getString("Title"),
					result.getInt("EditionNumber"),result.getString("Copyright"));
		}
	}

	public static void printAuthorISBN(ResultSet result) throws SQLException {
		System.out.printf("%-9s%-10s%n", "AuthorID", "ISBN");
		while (result.next()) {
			System.out.printf("%-9d%-10s%n", result.getInt("AuthorID"), result.getString("ISBN"));
		}
	}
}
