package examples.sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MySqlExample {

	public static void main(String[] args) {
		String connectionString = "jdbc:mysql://localhost/books";
		String username = "cst8288";
		String password = "8288";

		ResultSet result = null;
		try (Connection connection = DriverManager.getConnection(connectionString, username, password)) {
			result = query(connection, "SELECT * from books.authors");
			printAuthors(result);
			result = query(connection, "SELECT * from books.authorisbn");
			printAuthorISBN(result);
			result = query(connection, "SELECT * from books.titles");
			printTitles(result);
			result = query(connection, "select * from books.authors where LastName='Deitel' order by AuthorID asc");
			printAuthors(result);
			result = query(connection, "select * from books.titles where Title like '%how%' order by Title asc");
			printTitles(result);
			// UPDATE books.authors SET LastName='Deitel2' WHERE AuthorID=3;
			// UPDATE books.authors SET LastName='Deitel' WHERE AuthorID=3;
			// INSERT INTO books.authors VALUES ( 6, "Shawn","Emami" );
			// delete from books.authors where AuthorID=6;
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	static PreparedStatement statement = null;
	public static ResultSet query(Connection connection, String query) throws SQLException {
		statement = connection.prepareStatement(query);
		return statement.executeQuery();
	}

	public static void printAuthors(ResultSet result) throws SQLException {
		System.out.printf("%-9s%-10s%-10s%n", "AuthorID", "FirstName", "LastName");
		while (result.next()) {
			System.out.printf("%-9d%-10s%-10s%n", result.getInt("AuthorID"), result.getString("FirstName"),
					result.getString("LastName"));
		}
		if( statement!=null){
			statement.close();
		}
	}

	public static void printTitles(ResultSet result) throws SQLException {
		System.out.printf("%-16s%-55s%-8s%-10s%n", "ISBN", "Title", "Edition", "Copyright");
		while (result.next()) {
			System.out.printf("%-16s%-55s%-8d%-10s%n", result.getString("ISBN"), result.getString("Title"),
					result.getInt("EditionNumber"), result.getString("Copyright"));
		}
	}

	public static void printAuthorISBN(ResultSet result) throws SQLException {
		System.out.printf("%-9s%-10s%n", "AuthorID", "ISBN");
		while (result.next()) {
			System.out.printf("%-9d%-10s%n", result.getInt("AuthorID"), result.getString("ISBN"));
		}
	}
}
