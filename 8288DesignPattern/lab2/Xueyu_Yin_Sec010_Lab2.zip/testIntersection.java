package test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import org.junit.*;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import raycast.animator.AbstractAnimator;
import raycast.animator.TextAnimator;

class Param{
	private RayPoint rs;
	private RayPoint re;
	private RayPoint ss;
	private RayPoint se;
	private boolean expected;
	private RayPoint point;
	private double scalar;
	
	public Param(String strrs, String strre, String strss, String strse, boolean expected, String point, double scalar) {
		this.rs = new RayPoint(strrs);
		this.re = new RayPoint(strre);
		this.ss = new RayPoint(strss);
		this.se = new RayPoint(strse);
		setExpected(expected);
		this.point = new RayPoint(point);
		setScalar(scalar);
	}
	

	public RayPoint getRs() {
		return rs;
	}


	public RayPoint getRe() {
		return re;
	}


	public RayPoint getSs() {
		return ss;
	}


	public RayPoint getSe() {
		return se;
	}


	public boolean isExpected() {
		return expected;
	}

	private void setExpected(boolean expected) {
		this.expected = expected;
	}

	public RayPoint getPoint() {
		return point;
	}

	public double getScalar() {
		return scalar;
	}

	private void setScalar(double scalar) {
		this.scalar = scalar;
	}
	
}

class RayPoint{
	private double x,y;
	public RayPoint(double x, double y) {
		setX(x);
		setY(y);
	}
	
	private void setX(double x) {
		this.x = x;
	}
	
	private void setY(double y) {
		this.y = y;
	}
	
	public RayPoint(String s) {
		switch(s.toLowerCase()) {
		case "a":setX(100);setY(100);break;
		case "b":setX(200);setY(100);break;
		case "c":setX(200);setY(200);break;
		case "d":setX(100);setY(200);break;
		case "e":setX(150);setY(150);break;
		case "f":setX(150);setY(100);break;
		case "g":setX(200);setY(150);break;
		case "h":setX(150);setY(200);break;
		case "i":setX(100);setY(150);break;
		}
	}
	
	public double getX() {
		return this.x;
	}
	
	public double getY() {
		return this.y;
	}
}

@RunWith(Parameterized.class)
public class testIntersection {	

	private Param param;
	
	private AbstractAnimator a;
	private static final double DELTA = 1.0E-12;
	
	@Before
	public void setUp() {
		a = new TextAnimator();
	}

	public testIntersection(Param param) {
		this.param = param;
	}
	
	@Parameterized.Parameters
	public static Collection testConditions() {		

		return Arrays.asList(new Object[] {
				new Param("a", "b", "a", "d", true, "a", 0.0),//1
				new Param("a", "b", "f", "h", true, "f", 0.5),//2
				new Param("a", "b", "b", "c", true, "b", 1.0),//3
				new Param("b", "a", "a", "d", true, "a", 1.0),//4
				new Param("b", "a", "f", "h", true, "f", 0.5),//5
				new Param("b", "a", "b", "c", true, "b", 0.0),//6
				new Param("a", "b", "i", "d", false, "a", 0.0),//7
				new Param("a", "b", "e", "h", false, "a", 0.0),//8
				new Param("a", "b", "g", "c", false, "a", 0.0),//9
				new Param("a", "b", "i", "g", false, "a", 0.0),//10
				new Param("b", "a", "i", "d", false, "a", 0.0),//11
				new Param("b", "a", "e", "h", false, "a", 0.0),//12
				new Param("b", "a", "g", "c", false, "a", 0.0),//13
				new Param("b", "a", "i", "g", false, "a", 0.0),//14
				new Param("a", "f", "a", "d", true, "a", 0.0),//15
				new Param("a", "f", "f", "h", true, "f", 1.0),//16
				new Param("a", "f", "b", "c", true, "b", 2.0),//17
				new Param("f", "a", "a", "d", true, "a", 1.0),//18
				new Param("f", "a", "f", "h", true, "f", 0.0),//19
				new Param("f", "a", "b", "c", false, "a", 0.0)//20
			
		});
		
	}
	
	@Test
	public void test() {
		System.out.printf("(%2.0f, %2.0f)->(%2.0f, %2.0f) intersect (%2.0f, %2.0f)->(%2.0f, %2.0f)",
				param.getRs().getX(),
				param.getRs().getY(),
				param.getRe().getX(),
				param.getRe().getY(),
				param.getSs().getX(),
				param.getSs().getY(),
				param.getSe().getX(),
				param.getSe().getY());
		
		
		boolean doesIntersect = a.getIntersection(				
				param.getRs().getX(),
				param.getRs().getY(),
				param.getRe().getX(),
				param.getRe().getY(),
				param.getSs().getX(),
				param.getSs().getY(),
				param.getSe().getX(),
				param.getSe().getY());
		
		double[] inter = a.intersect();
		if(param.isExpected()) {
			assertTrue(doesIntersect);
			System.out.println(" True");
			
			assertEquals(inter[0], param.getPoint().getX(), DELTA);
			assertEquals(inter[1], param.getPoint().getY(), DELTA);
			assertEquals(inter[2], param.getScalar(), DELTA);
		}else {
			assertFalse(doesIntersect);
			System.out.println(" False");
		}
	
	}	
	

	
	@After
	public void tearDown() {
		a = null;
	}
	

}
