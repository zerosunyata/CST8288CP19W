package test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import org.junit.*;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import raycast.animator.AbstractAnimator;
import raycast.animator.TextAnimator;

@RunWith(Parameterized.class)
public class testIntersection {	
	private double[] inputNumber;
	private boolean expected;
	private double[] expectedResult;
	private AbstractAnimator a;
	private static final double DELTA = 1.0E-12;
	
	@Before
	public void setUp() {
		a = new TextAnimator();
	}

	public testIntersection(	double i0, 
									double i1,
									double i2,
									double i3,
									double i4,
									double i5,
									double i6,
									double i7,
									boolean b,
									double o0,
									double o1,
									double o2) {
		inputNumber = new double[]{i0, i1, i2, i3, i4, i5, i6, i7};
		expected = b;
		expectedResult = new double[] {o0, o1, o2};
	}
	
	@Parameterized.Parameters
	public static Collection testConditions() {		
		
		return Arrays.asList(new Object[][] {
			{100, 100, 200, 100, 100, 100, 100, 200, true, 100, 100, 0},//1
			{100, 100, 200, 100, 150, 100, 150, 200, true, 150, 100, 0.5},//2
			{100, 100, 200, 100, 100, 150, 100, 200, false, 0, 0, 0},//7
		});
		
	}
	
	@Test
	public void test() {
		System.out.printf("(%2.0f, %2.0f)->(%2.0f, %2.0f) intersect (%2.0f, %2.0f)->(%2.0f, %2.0f)",inputNumber[0],
				  inputNumber[1],
				  inputNumber[2],
				  inputNumber[3],
				  inputNumber[4],
				  inputNumber[5],
				  inputNumber[6],
				  inputNumber[7]);
		
		
		boolean doesIntersect = a.getIntersection(inputNumber[0],
												  inputNumber[1],
												  inputNumber[2],
												  inputNumber[3],
												  inputNumber[4],
												  inputNumber[5],
												  inputNumber[6],
												  inputNumber[7]);
		double[] inter = a.intersect();
		if(expected) {
			assertTrue(doesIntersect);
			System.out.println(" True");
			
			assertEquals(inter[0], expectedResult[0], DELTA);
			assertEquals(inter[1], expectedResult[1], DELTA);
			assertEquals(inter[2], expectedResult[2], DELTA);
		}else {
			assertFalse(doesIntersect);
			System.out.println(" False");
		}
	
	}	
	

	
	@After
	public void tearDown() {
		a = null;
	}
	

}
