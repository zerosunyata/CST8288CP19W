package trail;


import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import com.sun.jndi.url.iiopname.iiopnameURLContextFactory;
import com.sun.org.apache.xpath.internal.operations.Mult;

import javafx.animation.AnimationTimer;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import math.Vector;

public class Animator extends AnimationTimer implements DrawInterface{

	private static final double ONE_SECOND = 1000000000L;
	private static final double HALF_SECOND = ONE_SECOND / 2F;
	private static final int MAX_VECTORS = 360;
	private final Random RAND = new Random();

	private LinkedList< Vector> trailVectors;
	private GraphicsContext gc;
	private String fpsDisplay;
	private Canvas canvas;
	private Vector lastVector;
	
	//last 6 class variables need to be added to the Code
	
	private LinkedList<Vector> trails;
	private boolean clean;
	private int frameCount;
	private double hue;
	private double hueShift;
	private double lastTime;

	//last 7 methods need to be added to the Code
	
	//+drawingLoop(vectors : List<Vector>, drawInterface : DrawInterface) : void
	public void drawingLoop(List<Vector> trailVectors, DrawInterface drawInterface){
		for(Vector currentVector : trailVectors) {
			
			
			//Vector class follows the fluent DP, 
			//similar to the builder from last assignment with one difference being, 
			//it returns a new Vector every time. meaning Vector class is immutable.
			
			//1.1
			//1.2: mult(length : double = 4) : Vector
			//1.3: perpendicularY() : Vector 
			//1.4: perpendicularY
			Vector perpendicularY =  currentVector.sub(lastVector).mult(4).perpendicularY();
			//1.5: sub(vec : Vector = lastVector) : Vector
			//1.6: mult(length : double = 4) : Vector 
			//1.7: perpendicularX() : Vector 
			//1.8: perpendicularX
			Vector perpendicularX = currentVector.sub(lastVector).mult(4).perpendicularX();
			
			//1.9: add(vec : Vector = currentVector) : Vector
			//1.10: mult(length : double = 0.5) : Vector 
			//1.11: middle
			Vector middle = lastVector.add(currentVector).mult(0.5);
			
			//1.12: add(vec : Vector = middle) : Vector 
			//1.13: perpendicularCenterY
			Vector perpendicularCenterY = perpendicularY.add(middle);
			
			//1.14: add(vec : Vector = middle) : Vector //1.15: perpendicularCenterX
			Vector perpendicularCenterX = perpendicularX.add(middle);
			
			//1.16: draw(middle : Vector = middle, perpendicularCenterX : Vector = perpendicularCenterX, perpendicularCenterY : Vector = perpendicularCenterY) : void
			drawInterface.draw(middle, perpendicularCenterX, perpendicularCenterY);
			
			//at the end of the loop assign currentVector to lastVector
			lastVector = currentVector;
		}
			
	}

//	+addVector(x : double, y : double) : void
	public void addVector(double x, double y) {
		if(trailVectors.size()>=MAX_VECTORS) {
			removeFirst(1);
		}
		trailVectors.addLast(new Vector(x, y));
	}
	
//	+removeFirst(count : int) : void
	public void removeFirst(int count) {
		int i = 0; //??
		while(i < count && !trailVectors.isEmpty()) {
			trailVectors.removeFirst();
			i++;
			
		}
	}
	
//	+resetColorAndVector() : void
	public void resetColorAndVector() {
		// increment hueShift then store hueShift modules 360 in hue
		hueShift++;
		hue = hueShift % 360;
		if(!trailVectors.isEmpty()) {
			lastVector = trailVectors.getFirst();
		}
	}
	
//	+calculateFPS(now : long) : void
	public void calculateFPS(long now) {
		if(now - lastTime >= HALF_SECOND) {
			fpsDisplay = Integer.toString(frameCount * 2);
		
			frameCount = 0;
			lastTime = now;
		}
		frameCount ++;
	}
	
//	+shortenTrail(count : int) : void
	public void shortenTrail(int count) {
		if(clean && !trailVectors.isEmpty()) {
			removeFirst(count);
		}
		
	}

	public Animator( Canvas canvas){
		this.canvas = canvas;
		gc = canvas.getGraphicsContext2D();
	}
	
@Override
	public void start(){
		if( trailVectors == null)
			trailVectors = new LinkedList<>();
		trailVectors.clear();
		frameCount = 0;
		clean = false;
		lastTime = System.nanoTime();
		//pay attention to start method in AnimatorSkeleton as it is overridden, 
		//you must call the super start at the end of the method.
		super.start();
	}

	public void clean(){
		clean = true;
	}

	public void addStartVector( double x, double y){
		clean = false;
		lastVector = new Vector( x, y);
	}

	public double rand( double min, double max){
		return min + (max - min) * RAND.nextDouble();
	}

	public double roughRand( double min, double max, double minScale, double maxScale){
		if( min > max){
			double temp = min;
			min = max;
			max = temp;
		}
		return rand( min * rand( minScale, maxScale), max * rand( minScale, maxScale));
	}

	public void clearCanvas(){
		gc.clearRect( 0, 0, canvas.getWidth(), canvas.getHeight());
	}

	public void displayFPS(){
		gc.setFont( Font.font( gc.getFont().getFamily(), FontWeight.BLACK, 24));
		gc.setStroke( Color.WHITE);
		gc.setLineWidth( 1);
		gc.strokeText( fpsDisplay, 10, 25);
	}

	public void drawPerpendicularLines( Vector middle, Vector perpendicularCenterX, Vector perpendicularCenterY){
		gc.setLineWidth( 5);
		gc.setStroke( Color.hsb( (hue += .5f) % 360, 1, 1));
		gc.strokeLine( middle.getX(), middle.getY(), perpendicularCenterX.getX(), perpendicularCenterX.getY());
		gc.strokeLine( middle.getX(), middle.getY(), perpendicularCenterY.getX(), perpendicularCenterY.getY());
	}
/**
 * 
 * @param middle : Vector 
 * @param perpendicularCenterX : Vector
 * @param perpendicularCenterY : Vector
 */
	public void drawCloud( Vector middle, Vector perpendicularCenterX, Vector perpendicularCenterY){
		gc.setFill( Color.hsb( (hue += .5f) % 360, 1, .7));
		for( int i = 0; i < 100; i++){
			double x = roughRand( perpendicularCenterY.getX(), perpendicularCenterX.getX(), .95, 1.05);
			double y = roughRand( perpendicularCenterY.getY(), perpendicularCenterX.getY(), .95, 1.05);
			gc.fillOval( x, y, 2, 2);
		}
	}

	//
	@Override
	public void draw(Vector middle, Vector perpendicularCenterX, Vector perpendicularCenterY) {
		// TODO Auto-generated method stub
		
	}

	//
	@Override
	public void handle(long now) {
		// TODO Auto-generated method stub
		if(lastVector != null)
		{
			this.calculateFPS(now);
			this.clearCanvas();
			this.shortenTrail(5);
			this.drawingLoop(trailVectors, (m,px,py)-> drawCloud(m, px, py));
			this.resetColorAndVector();
			this.drawingLoop(trailVectors, (m,px,py)-> drawPerpendicularLines(m,px,py));
			this.resetColorAndVector();
			this.displayFPS();
		}
	}

}