package dao;

import entity.Player;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class PlayerDAO extends GenericDAO<Player> {

    public PlayerDAO() {
        super(Player.class);
    }
    
    public List<Player> findAll(){
        return findResults( "Player.findAll", null);
    }
    
    public Player findByID( int playerID){
        Map<String, Object> map = new HashMap<>();
        map.put("id", playerID);
        return findResult( "Player.findById", map);
    }
    
    public List<Player> findByFirstName( String firstname){
        Map<String, Object> map = new HashMap<>();
        map.put("firstName", firstname);
        return findResults( "Player.findByFirstName", map);
    }
    
    public Player deleteByID(int playerID){
        this.beginTransaction();
        Player p = find(playerID);
        delete(p);
        this.commit();
        return p;
    }
    
    public Player updateByID(int playerID, Player player){
        this.beginTransaction();
        Player p = update(player);
        this.commit();
        return p;
    }
}
