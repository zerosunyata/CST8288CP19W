package dao;

import entity.Score;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class ScoreDAO extends GenericDAO<Score> {

    public ScoreDAO() {
        super(Score.class);
    }
    
    public List<Score> findAll(){
        return findResults( "Score.findAll", null);
    }
    
    public Score findByID( int playerID){
        Map<String, Object> map = new HashMap<>();
        map.put("id", playerID);
        return findResult( "Score.findById", map);
    }
    
    public List<Score> findByScore( String score){
        Map<String, Object> map = new HashMap<>();
        map.put("score", score);
        return findResults( "Score.findByScore", map);
    }    
    
    public Score deleteByID(int id){
        beginTransaction();
        Score s = find(id);
        delete(s);
        commit();  
        return s;        
    }
    
    public Score updateByID(int id, Score score){
        this.beginTransaction();
        Score s = this.find(id);
        s.setPlayerid(score.getPlayerid());
        s.setScore(score.getScore());
        s.setSubmission(score.getSubmission());
        this.update(s);
        this.commit();
        return s;
    }
}
