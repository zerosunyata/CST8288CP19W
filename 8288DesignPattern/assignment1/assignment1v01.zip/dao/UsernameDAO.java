package dao;

import entity.Player;
import entity.Username;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Shariar Emami
 * @since Jan 14, 2019
 */
public class UsernameDAO extends GenericDAO<Username> {

    public UsernameDAO() {
        super(Username.class);
    }
    
    public List<Username> findAll(){
        return findResults( "Username.findAll", null);
    }
    
    public Username findByPlayerID( int playerID){
        Map<String, Object> map = new HashMap<>();
        map.put("playerid", playerID);
        return findResult( "Username.findByPlayerid", map);
    }
    
    public List<Username> findByUsername( String username){
        Map<String, Object> map = new HashMap<>();
        map.put("username", username);
        return findResults( "Username.findByUsername", map);
    }
    
    public Username deleteByPlayerID(int playerid){
        beginTransaction();
        Username u = find(playerid);
        delete(u);
        commit();  
        return u;
    }
    
    public Username updateByID(int id, Username username){
        this.beginTransaction();
        Username u = this.find(id);
        Player p = new Player();
        p.setId(username.getPlayerid());
        u.setPlayer(p);
        u.setUsername(username.getUsername());
        this.update(u);
        this.commit();
        return u;
    }
}
