package logic;

import dao.PlayerDAO;
import entity.Player;
import java.util.List;
import java.util.Map;

public class PlayerLogic extends GenericLogic<Player, PlayerDAO>{
    public static final String PLAYER_ID = "id";
    public static final String FIRSTNAME = "firstname";
    public static final String LASTNAME = "lastname";
    public static final String JOINED = "joined";
    public static final String EMAIL = "email";

    public PlayerLogic() { 
        super( new PlayerDAO());
    }
    
    public List<Player> getAll(){
        return get(()->dao().findAll());
    }
    
    public Player getByID( int playerID){
        return get(()->dao().findByID(playerID));
    }
    
    public List<Player> getByFirstName( String firstName){
        return get(()->dao().findByFirstName(firstName));
    }

    public Player deleteById(int id){
        return get(()->dao().deleteByID(id));
    }
 
    
    public Player createEntity(Map<String, String[]> parameterMap) {
        Player player = new Player();
        if(parameterMap.containsKey(PLAYER_ID)){
            player.setId(Integer.valueOf(parameterMap.get(PLAYER_ID)[0]));
        }
        player.setFirstName(parameterMap.get(FIRSTNAME)[0]);
        player.setLastName(parameterMap.get(LASTNAME)[0]);
        //player.setJoined(parameterMap.get(JOINED)[0]);
        player.setEmail(parameterMap.get(EMAIL)[0]);
        return player;
    }    
}
