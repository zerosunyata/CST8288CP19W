package logic;

import dao.PlayerDAO;
import entity.Player;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Clock;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class PlayerLogic extends GenericLogic<Player, PlayerDAO> {

    public static final String ID = "id";
    public static final String FIRSTNAME = "firstname";
    public static final String LASTNAME = "lastname";
    public static final String JOINED = "joined";
    public static final String EMAIL = "email";

    private static final Pattern VALID_EMAIL_ADDRESS_REGEX = 
    Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);

    public PlayerLogic() {
        super(new PlayerDAO());
    }

    public List<Player> getAllPlayers() {
        return get(() -> dao().findAll());
    }

    public Player getPlayerWithId(int id) {
        return get(() -> dao().findById(id));
    }

    public List<Player> getPlayersWithFirstName(String firstName) {
        return get(() -> dao().findByFirstName(firstName));
    }

    public List<Player> getPlayersWithLastName(String lastName) {
        return get(() -> dao().findByLastName(lastName));
    }

    public List<Player> getPlayersJoinedOn(Date date) {
        return get(() -> dao().findByJoined(date));
    }

    public Player getPlayerWithEmail(String email) {
        return get(() -> dao().findByEmail(email));
    }

    public Player deleteById(int id) {
        return get(() -> dao().deleteByID(id));
    }

    public Player createEntity(Map<String, String[]> parameterMap) {
        Player player = new Player();
        if (parameterMap.containsKey(ID)) {
            player.setId(Integer.valueOf(parameterMap.get(ID)[0]));
        }
        player.setFirstName(parameterMap.get(FIRSTNAME)[0]);
        player.setLastName(parameterMap.get(LASTNAME)[0]);
        player.setJoined(Date.from(Instant.now(Clock.systemDefaultZone())));
        
        player.setEmail(parameterMap.get(EMAIL)[0]);
        return player;
    }
    
    public boolean validateID(String id) {
        String s = id.trim();
        if (s.isEmpty()) {
            return false;
        }
        if(getPlayerWithId(Integer.valueOf(id))==null)
            return true;
        return false;
    }

    public boolean validateFirstName(String firstName) {
        String s = firstName.trim();
        if (s.isEmpty()) {
            return false;
        }
        if (s.length() >= 1 && s.length() <= 95) {
            return true;
        }
        return false;
    }

    public boolean validateLastName(String lastName) {
        String s = lastName.trim();
        if (s.isEmpty()) {
            return false;
        }
        if (s.length() >= 1 && s.length() <= 95) {
            return true;
        }
        return false;
    }

    public boolean validateJoined(String joined) {
        String s = joined.trim();
        if (s.isEmpty()) {
            return false;
        }
        try {
            Date date;
            date = new SimpleDateFormat("yyyy-MM-dd").parse(s);            
        } catch (ParseException ex) {
            return false;
        }
        return true;
    }

    public Date convertJoined(String joined){
        Date date = null;
        try {
            date = new SimpleDateFormat("yyyy-MM-dd").parse(joined);
        } catch (ParseException ex) {
        }
        return date;        
    }
    
    public boolean validateEmail(String email) {
        String s = email.trim();
        if (!checkEmail(email)) {
            return false;
        }
        if(this.getPlayerWithEmail(s)==null)
            return true;
        return false;
    }

  
    public boolean checkEmail(String email) {
        String s = email.trim();
        if (s.isEmpty()) {
            return false;
        }    
        
        //https://stackoverflow.com/questions/8204680/java-regex-email        
        Matcher matcher = VALID_EMAIL_ADDRESS_REGEX .matcher(s);
        return matcher.find();
    }

}
