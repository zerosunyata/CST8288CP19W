package logic;

import dao.ScoreDAO;
import entity.Score;
import entity.Player;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Clock;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Map;


public class ScoreLogic extends GenericLogic<Score, ScoreDAO>{
    
    public static final String ID = "scoreid";
    public static final String SCORE = "score";
    public static final String PLAYER_ID = "id";
    public static final String SUBMISSION = "submission";

    public ScoreLogic() { 
        super( new ScoreDAO());
    }
    
    public List<Score> getAll(){
        return get(()->dao().findAll());
    }
    
    public Score getById( int id){
        return get(()->dao().findById(id));
    }

    public List<Score> getScoresWith( int score){
        return get(()->dao().findByScore(score));
    }
    
    public List<Score> getScoreOnDate( Date submission){
        return get(()->dao().findBySubmission(submission));
    }

    public List<Score> getScoresForPlayerID( int playerid){
        return get(()->dao().findByPlayerID(playerid));
    }

    public Score deleteByID(int id){
        return get(()->dao().deleteByID(id));
    }
    
    public Score updateByID(int id, Score score){
        return get(()->dao().updateByID(id, score));
    }

    public boolean validateID(String id) {
        String s = id.trim();
        if (s.isEmpty()) {
            return false;
        }
        if(getById(Integer.valueOf(id))==null)
            return true;
        return false;
    }

    public boolean validatePlayerId(String playerid) {
        String s = playerid.trim();
        if (s.isEmpty()) {
            return false;
        }
        PlayerLogic logic = new PlayerLogic();
        if(logic.getPlayerWithId(Integer.valueOf(playerid))==null)
            return true;
        return false;
    }
    
    public boolean checkPlayerId(String playerid) {
        String s = playerid.trim();
        if (s.isEmpty()) {
            return false;
        }
        PlayerLogic logic = new PlayerLogic();
        if(logic.getPlayerWithId(Integer.valueOf(playerid))!=null)
            return true;
        return false;
    }
 
    public boolean validateScore(String score){
        String s = score.trim();
        if (s.isEmpty()) {
            return false;
        }
        if(Integer.valueOf(score)>=0)
            return true;
        return false;        
    }

    public boolean validateSubmission(String submission) {
        String s = submission.trim();
        if (s.isEmpty()) {
            return false;
        }
        try {
            Date date;
            date = new SimpleDateFormat("yyyy-MM-dd").parse(submission);
        } catch (ParseException ex) {
            return false;
        }
        return true;
    }

    
    public Score createEntity(Map<String, String[]> parameterMap) {
        Score score = new Score();
        PlayerLogic logic = new PlayerLogic();
        Player p = logic.getPlayerWithId(Integer.valueOf(parameterMap.get(ScoreLogic.PLAYER_ID)[0]));
        if(p!=null){
            score.setPlayerid(p);
            score.setScore(Integer.valueOf(parameterMap.get(ScoreLogic.SCORE)[0]));
        
            score.setSubmission(Date.from(Instant.now(Clock.systemDefaultZone())));
            return score;
        }
        return null;
    }    
}
