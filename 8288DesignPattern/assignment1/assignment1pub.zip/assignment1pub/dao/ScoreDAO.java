package dao;

import entity.Score;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class ScoreDAO extends GenericDAO<Score> {

    public ScoreDAO() {
        super(Score.class);
    }
    
    public List<Score> findAll(){
        return findResults( "Score.findAll", null);
    }
    
    public Score findById( int id){
        Map<String, Object> map = new HashMap<>();
        map.put("id", id);
        return findResult( "Score.findById", map);
    }
    
    public List<Score> findByScore( int score){
        Map<String, Object> map = new HashMap<>();
        map.put("score", score);
        return findResults( "Score.findByScore", map);
    }    

    public List<Score> findBySubmission( Date submission){
        Map<String, Object> map = new HashMap<>();
        map.put("submission", submission);
        return findResults( "Score.findBySubmission", map);
    }    

    public List<Score> findByPlayerID( int playerid){
        Map<String, Object> map = new HashMap<>();
        map.put("playerid", playerid);
        return findResults( "Score.findByPlayerID", map);
    }    
    
    public Score deleteByID(int id){
        beginTransaction();
        Score s = find(id);
        delete(s);
        commit();  
        return s;        
    }
    
    public Score updateByID(int id, Score score){
        this.beginTransaction();
        Score s = this.find(id);
        s.setPlayerid(score.getPlayerid());
        s.setScore(score.getScore());
        s.setSubmission(score.getSubmission());
        this.update(s);
        this.commit();
        return s;
    }
}
