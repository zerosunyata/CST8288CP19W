package dao;

import entity.Player;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PlayerDAO extends GenericDAO<Player> {

    public PlayerDAO() {
        super(Player.class);
    }
    
    public List<Player> findAll(){
        return findResults( "Player.findAll", null);
    }
    
    public Player findById( int id){
        Map<String, Object> map = new HashMap<>();
        map.put("id", id);
        return findResult( "Player.findById", map);
    }
    
    public List<Player> findByFirstName( String firstname){
        Map<String, Object> map = new HashMap<>();
        map.put("firstName", firstname);
        return findResults( "Player.findByFirstName", map);
    }

    public List<Player> findByLastName( String lastname){
        Map<String, Object> map = new HashMap<>();
        map.put("lastName", lastname);
        return findResults( "Player.findByLastName", map);
    }

    public List<Player> findByJoined( Date date){
        Map<String, Object> map = new HashMap<>();
        map.put("joined", date);
        return findResults( "Player.findByJoined", map);
    }

    public Player findByEmail( String email){
        Map<String, Object> map = new HashMap<>();
        map.put("email", email);
        return findResult( "Player.findByEmail", map);
    }
    
    public Player deleteByID(int playerID){
        this.beginTransaction();
        Player p = find(playerID);
        delete(p);
        this.commit();
        return p;
    }
    
    public Player updateByID(int playerID, Player player){
        this.beginTransaction();
        Player p = update(player);
        this.commit();
        return p;
    }
}
