package view;

import entity.Player;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import logic.PlayerLogic;


public class CreatePlayer extends HttpServlet {

    private MessageServlet message = new MessageServlet();
    private final static String copyright = "CST8288 Assignment 1";

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.message.setHeader("CreatePlayer");
        ArrayList<String> labels = new ArrayList<String>();
        ArrayList<String> type = new ArrayList<String>();
        ArrayList<String> inputs = new ArrayList<String>();
        ArrayList<String> values = new ArrayList<String>();
        labels.add("ID");
        type.add("number");
        inputs.add(PlayerLogic.ID);
        values.add("");
        labels.add("First Name");
        type.add("text");
        inputs.add(PlayerLogic.FIRSTNAME);
        values.add("");
        labels.add("Last Name");
        type.add("text");
        inputs.add(PlayerLogic.LASTNAME);
        values.add("");
        labels.add("Email");
        type.add("email");
        inputs.add(PlayerLogic.EMAIL);
        values.add("");
        this.message.setFormInfo("CreatePlayer", labels, type, inputs, values);
        this.message.setFooter(CreatePlayer.copyright);
        this.message.doProcess(request, response);
    }

    private String toStringMap(Map<String, String[]> values) {
        StringBuilder builder = new StringBuilder();
        values.forEach((k, v) -> builder.append("Key=").append(k)
                .append(", ")
                .append("Value/s=").append(Arrays.toString(v))
                .append(System.lineSeparator()));
        return builder.toString();
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //you can add you logic here
        //response.sendRedirect("CourseForm");
        PlayerLogic logic = new PlayerLogic();
        String[] id = request.getParameterValues(PlayerLogic.ID);
        String[] firstName = request.getParameterValues(PlayerLogic.FIRSTNAME);
        String[] lastName = request.getParameterValues(PlayerLogic.LASTNAME);
        
        String[] email = request.getParameterValues(PlayerLogic.EMAIL);
        
        boolean bid = logic.validateID(id[0]);
        boolean bfirstname = logic.validateFirstName(firstName[0]);
        boolean blastname = logic.validateLastName(lastName[0]);
        
        boolean bemail = logic.validateEmail(email[0]);
        
        if(bid && bfirstname && blastname && bemail){
            Player player = logic.createEntity(request.getParameterMap());
            logic.add(player);
            this.message.setHeader("CreatePlayer");
            this.message.setMessage("Create Player Success!");
            this.message.addMessage("Add Player :");
            this.message.addMessage(toStringMap(request.getParameterMap()));
            this.message.setFooter(CreatePlayer.copyright);
            this.message.doInfo(request, response);
        }else{
            this.message.setHeader("CreatePlayer");
            this.message.setMessage("Input Error!");
            if(!bid){
                this.message.addMessage("ID Error:");
                this.message.addMessage(request.getParameterValues(PlayerLogic.ID)[0]);
            }
            if(!bfirstname){
                this.message.addMessage("First name Error:");
                this.message.addMessage(request.getParameterValues(PlayerLogic.FIRSTNAME)[0]);
            }
            if(!blastname){
                this.message.addMessage("Last name Error:");
                this.message.addMessage(request.getParameterValues(PlayerLogic.LASTNAME)[0]);
            }

            if(!bemail){
                this.message.addMessage("EMail Error:");
                this.message.addMessage(request.getParameterValues(PlayerLogic.EMAIL)[0]);
            }
            this.message.setFooter(CreatePlayer.copyright);
            this.message.doInfo(request, response);            
        }
    }

    
    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
