package view;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Xueyu Yin
 */
public class MessageServlet extends HttpServlet {

    private ArrayList<String> header = new ArrayList<String>();
    private ArrayList<String> message = new ArrayList<String>();
    private ArrayList<String> footer = new ArrayList<String>();
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            for (String s : header){
                out.println(s);
            }
            for (String s : message){
                out.println(s);
            }
            for (String s : footer){
                out.println(s);
            }
        }
    }
  
    public void doProcess(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            for (String s : header){
                out.println(s);
            }
            for (String s : message){
                out.println(s);
            }
            for (String s : footer){
                out.println(s);
            }
        }
    }

    public void doInfo(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            for (String s : header){
                out.println(s);
            }
            for (String s : message){
                out.println(s);
            }
            for (String s : footer){
                out.println(s);
            }
        }
    }
    
    public void setMessage(String message){
        this.message.clear();
        this.message.add("<pre>");
        
        this.message.add(message + "<br>");
        this.message.add("</pre>");
    }
    
    public void addMessage(String message){
        this.message.add("<pre>");
        this.message.add(message + "<br>");
        this.message.add("</pre>");
        
    }
    
    public void setHeader(String header) {
        this.header.clear();
        this.header.add("<!DOCTYPE html>");        
        this.header.add("<html>");
        this.header.add("<head>");
        String s = String.format("<title>%s</title>", header);
        this.header.add(s);
        this.header.add("</head>");
        this.header.add("<body>");
        this.header.add("<div style=\"text-align: center;\">");
        this.header.add("<div style=\"display: inline-block; text-align: left;\">");
    }

    public void setFormInfo(String action, ArrayList<String> labels, ArrayList<String> type, ArrayList<String> inputs, ArrayList<String> values) {
        this.message.clear();
        String s = String.format("<form action=\"%s\" method=\"post\">", action);
        this.message.add(s);
        for (int i = 0; i < inputs.size(); i ++){
            s = String.format("%s:<br>", labels.get(i));
            this.message.add(s);
            if(type.get(i).equals("date")){
                s = String.format("<input type=\"date\" name=\"%s\" min=\"1900-01-01\" max=\"2020-12-30\"><br>", inputs.get(i));
            }else{
                s = String.format("<input type=\"%s\" name=\"%s\" value=\"%s\"><br>", type.get(i), inputs.get(i), values.get(i));
            }
            this.message.add(s);
        }
        this.message.add("<input type=\"submit\" value=\"Submit\">");
        this.message.add("</form>");
    }

    public void setMapKeyValues(String map) {
        this.message.add("<pre>");
        this.message.add("Submitted keys and values:");
        this.message.add(map);
        this.message.add("</pre>");
    }
    
    public void setFooter(String copyright){
        this.footer.clear();
        this.footer.add("<div class=\"row\">");
        this.footer.add("<footer>");
        String s = String.format("<h4>%s</h4>", copyright);
        this.footer.add(s);
        this.footer.add("</footer>");
        this.footer.add("</div>");
        this.footer.add("</body>");
        this.footer.add("</html>"); 
    }
    
    
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
