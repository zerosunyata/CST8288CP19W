package view;

import entity.Score;
import entity.Username;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import logic.ScoreLogic;

/**
 *
 * @author Shariar
 */
public class CreateScore extends HttpServlet {

    private MessageServlet message = new MessageServlet();
    private final static String copyright = "CST8288 Assignment 1";

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        this.message.setHeader("CreateScore");
        ArrayList<String> labels = new ArrayList<String>();
        ArrayList<String> type = new ArrayList<String>();
        ArrayList<String> inputs = new ArrayList<String>();
        ArrayList<String> values = new ArrayList<String>();

        labels.add("Player ID");
        type.add("number");
        inputs.add(ScoreLogic.PLAYER_ID);
        values.add("");
        labels.add("Score");
        type.add("number");
        inputs.add(ScoreLogic.SCORE);
        values.add("");

        this.message.setFormInfo("CreateScore", labels, type, inputs, values);
        this.message.setFooter(CreateScore.copyright);
        this.message.doProcess(request, response);

    }

    private String toStringMap(Map<String, String[]> values) {
        StringBuilder builder = new StringBuilder();
        values.forEach((k, v) -> builder.append("Key=").append(k)
                .append(", ")
                .append("Value/s=").append(Arrays.toString(v))
                .append(System.lineSeparator()));
        return builder.toString();
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //you can add you logic here
        //response.sendRedirect("CourseForm");
        ScoreLogic logic = new ScoreLogic();
        String[] id = request.getParameterValues(ScoreLogic.ID);
        String[] playerid = request.getParameterValues(ScoreLogic.PLAYER_ID);
        String[] score = request.getParameterValues(ScoreLogic.SCORE);
        String[] submission = request.getParameterValues(ScoreLogic.SUBMISSION);

        
        boolean bplayerid = logic.checkPlayerId(playerid[0]);
        boolean bscore = logic.validateScore(score[0]);
        

        
        if (bplayerid && bscore) {
            Score playerscore = logic.createEntity(request.getParameterMap());
            if (playerscore != null) {
                logic.add(playerscore);
                this.message.setHeader("CreateScore");
                this.message.setMessage("Create Score Success!");
                this.message.addMessage("Add Score :");
                this.message.addMessage(toStringMap(request.getParameterMap()));
            }
        } else {
            this.message.setHeader("CreateScore");
            this.message.setMessage("Input Error!");
            if (!bplayerid) {
                this.message.addMessage("Player ID Error:");
                this.message.addMessage(request.getParameterValues(ScoreLogic.PLAYER_ID)[0]);
            }
            if (!bscore) {
                this.message.addMessage("Score Error:");
                this.message.addMessage(request.getParameterValues(ScoreLogic.SCORE)[0]);
            }

        }
        this.message.setFooter(CreateScore.copyright);
        this.message.doInfo(request, response);

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
