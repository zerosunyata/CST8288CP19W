package com.javacodegeeks.patterns.commandpattern;

public class Email {

	public void sendEmail() {
		System.out.println("Sending email.......");
	}
}
