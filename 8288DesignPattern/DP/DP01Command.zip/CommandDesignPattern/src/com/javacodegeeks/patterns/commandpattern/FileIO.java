package com.javacodegeeks.patterns.commandpattern;

public class FileIO {

	public void execute() {
		System.out.println("Executing File IO operations...");
	}
}
