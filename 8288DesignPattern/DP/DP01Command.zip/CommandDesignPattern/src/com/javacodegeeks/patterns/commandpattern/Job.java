package com.javacodegeeks.patterns.commandpattern;

public interface Job {

	public void run();
}
