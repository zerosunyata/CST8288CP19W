package com.javacodegeeks.patterns.commandpattern;

public class Sms {

	public void sendSms() {
		System.out.println("Sending SMS...");
	}
}
