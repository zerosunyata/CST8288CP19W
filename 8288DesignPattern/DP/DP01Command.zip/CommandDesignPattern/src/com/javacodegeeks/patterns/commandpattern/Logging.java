package com.javacodegeeks.patterns.commandpattern;

public class Logging {

	public void log() {
		System.out.println("Logging...");
	}
}
