package raycast.entity.geometry;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import raycast.entity.DrawableObject;
import raycast.entity.geometry.RectangleBounds;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.Map.Entry;

import utility.Point;
import utility.RandUtil;


public class PolyShape implements DrawableObject <PolyShape>{

	private int pointCount;
	private double [][]points;
	private double minX,minY,maxX,maxY,strokeWidth;
	private Color fill,stroke;
	private RectangleBounds bounds; 


	public PolyShape(){      
		strokeWidth = 1;
		fill = null;
		stroke = Color.BLACK;
	}


	public PolyShape setPoints(double... nums ){
	
		minX = maxX = nums[0];
		minY = maxY = nums[1];
		
		pointCount = nums.length / 2;
		
		points = new double[2][pointCount];	
		
		for (int i=0,j=0;i<nums.length;j++,i+=2){
			
			updateMinMax(nums[i],nums[i+1]);
			points[0][j]=nums[i];
			points[1][j]=nums[i+1];
		}

		bounds = new RectangleBounds (minX, minY, maxX-minX, maxY-minY);
		return this ;
	}

	//Bonus part. Lines should not cross each other.
	public PolyShape randomize(double centerX, double centerY, double size, int minPoints, int maxPoints){      
	
		Point centerPoint = new Point(centerX, centerY);		

		int pointNum = RandUtil.getInt(minPoints, maxPoints);
		double nums[] = new double[pointNum * 2];

		
		SortedMap <Double, Point> sortedM = new TreeMap <Double, Point>();
		for (int i = 0; i < pointNum; i++) {
			Point randomPoint = centerPoint.random (size, size + 100);
			
			sortedM.put(new Double (centerPoint.angle (randomPoint)), randomPoint);
		}

		
		Set<Entry<Double, Point>> set = sortedM.entrySet();
		Iterator<Entry<Double, Point>> iterator = set.iterator();
		int counter = 0;
		while (iterator.hasNext()) {
			Map.Entry<Double, Point> map = (Map.Entry<Double, Point>) iterator.next();
			Point point = (Point) map.getValue();
			nums[counter] = point.x();
			nums[counter + 1] = point.y();
			counter=counter+2;
		}

		
		minX = maxX = nums[0];
		minY = maxY = nums[1];
		pointCount = nums.length / 2;	
		points = new double[2][pointCount];	
		for (int i=0, j=0; i<nums.length; j++, i+=2) {
			updateMinMax(nums[i], nums[i+1]);
			points[0][j] = nums[i];
			points[1][j] = nums[i+1];
		}	
		bounds = new RectangleBounds(minX, minY, maxX-minX, maxY-minY);
		return this;
	}


	public void updateMinMax(double x, double y){
		if(x < minX ) {		
			minX = x;
		}
		else if (x > maxX) {
			maxX = x; 
		}	
		if(y < minY ) {		
			minY = y;
		}
		else if (y > maxY) {
			maxY = y; 
		}
	}

	public int pointCount(){
		return pointCount;
	}
	public double [][] points(){
		return points;
	}

	//px and py methods return x and y of specific corner. 
	//remember how points is ordered, read PolyShape description again.
	public double pX( int index){
		return points[0][index];

	}
	public double pY(int index){
		return points[1][index];   
	}


	public void drawCorners (GraphicsContext gc){
		
		gc.setFill(Color.BLUE);
		gc.setStroke(Color.BLACK);
		
		for (int i=0;i<pointCount;i++){
			gc.fillText(Integer.toString(i), points[0][i]-5, points[1][i]-5);
			gc.fillOval(points[0][i]-5, points[1][i] - 5, 10, 10);
		}   
	}

	public RectangleBounds getBounds(){
		return bounds ;
	}

	@Override
	public void draw(GraphicsContext gc) {
		
		gc.setLineWidth(strokeWidth);
		
		if(stroke != null) {
			gc.setStroke(stroke);
			gc.strokePolygon(points[0], points[1], pointCount);
		}
		
		if(fill != null) {
			gc.setFill(fill);;
			gc.fillPolygon(points[0], points[1], pointCount);
		}
	}

	@Override
	public PolyShape setFill(Color color) {
		fill = color;
		return this;
	}

	@Override
	public PolyShape setStroke(Color color) {
		stroke = color;	
		return this;
	}

	@Override
	public PolyShape setWidth(double width) {
		strokeWidth = width;
		return this;
	}

	@Override
	public Color getFill() {
		return fill;
	}

	@Override
	public Color getStroke() {
		return stroke;
	}

	@Override
	public double getWidth() {
		return strokeWidth;
	}
}
