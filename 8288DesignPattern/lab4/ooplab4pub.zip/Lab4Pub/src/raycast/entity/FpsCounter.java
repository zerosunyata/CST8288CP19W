package raycast.entity;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class FpsCounter implements DrawableObject <FpsCounter>{

	public static final double ONE_SECOND = 1000000000L;
	public static final double HALF_SECONG = ONE_SECOND / 2F;
	private Font fpsFont;
	private String fpsDisplay;
	private int frameCount;
	private double lastTime;
	private double strokeWidth;
	private Color fill;
	private Color stroke;	
	private double x;
	private double y;

	

	public FpsCounter(double x, double y) {
		setPos(x, y);
		setFont(Font.font( Font.getDefault().getFamily(), FontWeight.BLACK, 24));	
	}

	

	public void calculateFPS(long now) {
		if (now-lastTime > HALF_SECONG) {
			fpsDisplay = String.valueOf(frameCount * 2);
			frameCount = 0;
			lastTime = now;		
		}
		frameCount++;
	}

	public FpsCounter setFont(Font font) {
		this.fpsFont = font;
		return this;		
	}

	public FpsCounter setPos(double x, double y) {
		this.x = x;
		this.y = y;
		return this;
	}

	//draw needs to draw the current fps on canvas.
	@Override
	public void draw(GraphicsContext gc) {
		//get font from gc and save it in a temp variable so we can set it back later
		Font f = gc.getFont();
		//set fpsFont as font on gc
		gc.setFont(fpsFont);
		//call setFill on gc and pass fill
		gc.setFill(fill);
		//call fillText on gc and pass fpsDisplay, x and y		
		gc.fillText(fpsDisplay, x, y);
		//call setStroke on gc and pass stroke		
		gc.setStroke(stroke);
		//call setLineWidth on gc and pass strokeWidth		
		gc.setLineWidth(strokeWidth);
		//call strokeText on gc and pass fpsDisplay, x and y      
		gc.strokeText(fpsDisplay, x, y);
		//call setFont on gc and pass to it the temp font you created    
		gc.setFont(f);
	}

	@Override
	public FpsCounter setFill(Color color) {
		fill = color;
		return this;
	}

	@Override
	public FpsCounter setStroke(Color color) {
		stroke = color;	
		return this;
	}

	@Override
	public FpsCounter setWidth(double width) {
		strokeWidth = width;
		return this;
	}

	@Override
	public Color getFill() {
		return fill;
	}

	@Override
	public Color getStroke() {
		return stroke;

	}

	@Override
	public double getWidth() {
		return strokeWidth;
	}

}
