package raycast.animator;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import raycast.entity.geometry.PolyShape;

public class StaticShapes extends AbstractAnimator {

	private final static Color BACKGROUND = Color.LAVENDER;

	@Override
	void handle(long now, GraphicsContext gc) {

		clearAndFill(gc, BACKGROUND);

		for (PolyShape p : map.shapes()) {
			p.draw(gc);
		}
	}

	@Override
	public String toString() {
		return "Static Shapes";
	}

}
