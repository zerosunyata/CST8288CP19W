package raycast.animator;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import raycast.entity.geometry.PolyShape;
import utility.Point;


public class MultiRayAnimator extends AbstractAnimator {

	// create a new class variable called intersectPoint of type double array. 
	// the point of this array is to store the result (intersectResult) of intersection 
	// between rays fired from the location of mouse to different shapes.
	private double[] intersectPoint = new double[4]; 
	
	private Color backgroundColor = Color.DARKGRAY;
	private Color lightColor = Color.RED;

	public MultiRayAnimator() {

		
	}


	//add the above method to draw lines.

	/**
	 * Draw line 
	 * @param gc
	 * @param color
	 * @param sx
	 * @param sy
	 * @param ex
	 * @param ey
	 */
	public void drawLine(GraphicsContext gc, Color color, double sx, double sy, double ex, double ey) {
		gc.setLineWidth(1);
		gc.setStroke(color);
		
		// pattern 2
		double angle = Math.atan2(ey-sy, ex-sx);
		Color c[] = {Color.RED, Color.ORANGE, Color.YELLOW, Color.GREEN, Color.AQUAMARINE, Color.BLUE, Color.VIOLET};
		for (int i = 0; i < c.length; i ++) {
			if (Math.round(Math.abs(angle/Math.PI*360+360)/c.length) % c.length == i)
				gc.setStroke(c[i]);
		}
		
		gc.strokeLine(sx, sy, ex, ey);

		if (map.getDrawIntersectPoint()) {
			gc.fillOval(ex - 5, ey - 5, 10, 10);
		}
	}
	
	//create a new toString method and return the name of your animator, name of the class is good enough

	/**
	 * toString
	 */
	@Override
	public String toString() {
		return "MultiRayAnimator";
	}


	//handle method is in sequence diagram
	/**
	 * handle
	 */
	public void handle(long now, GraphicsContext gc) {
		clearAndFill(gc, backgroundColor);
		for (PolyShape shape : map.shapes()) {
			shape.draw(gc);
		}
		drawRays(gc, mouse.x(), mouse.y(), lightColor);

	}

	// drawRays method is in sequence diagram but here are some hint:
	/**
	 * you will need to declare 3 local variables called endX, endY and rayIncrementer.
	 * rayIncremneter will be 360d / c.getRayCount(). it is very important to place d at the end of 360. 
	 * this will let java know that this number must be treated as a double instead of an integer. 
	 * if it is integer this divide will always return zero. alternatively you can write 360.0 as well.
	 * values of endX will be cos of our angel incremented by rayIncremneter in radian. endY with sin.
	 * in the 3rd loop you will need to check ray against all sides of your shapes. 
	 * in a normal loop you can only check sides from zero to point count. 
	 * that means you will need to check for point count to zero manually (last line segment). 
	 * you can either duplicate your code and check the last line or 
	 * you can add a new variable to your loop called j that starts from pointCount -1 and 
	 * on every increment it will be assignment i-1.
	 *  so for a 3 sides shape you will check line segments in this order: 2-0, 0-1 and 1-2. all sides covered. 
	 *  this is the same process you can use in HitBox intersectFull method.
	 *  at the end of mian loop (first loop) assign Double.MAX_VALUE to intersectPoint[2]. 
	 *  if you remember values in intersectResult are stored in following order: x, y, ray distance to intersect and 
	 *  segment distance to intersect. the way we choose which ray should be drawn is based in the smallest ray distance 
	 *  to intersect for each ray. so every time we increment the ray intersectPoint[2] has to be changed 
	 *  to a very large number so the smaller one can be found.
	 */
	/**
	 * Draw rays
	 * @param gc
	 * @param startX
	 * @param startY
	 * @param lightColor
	 */
	public void drawRays(GraphicsContext gc, double startX, double startY, Color lightColor) {
		
		double endX, endY, rayIncrementer;
		
		rayIncrementer = 360d / map.getRayCount();
		
		endX = Math.cos(rayIncrementer);
		endY = Math.sin(rayIncrementer);
		
		for (double rayAngel = 0; rayAngel < 360; rayAngel += rayIncrementer) {

			endX = Math.cos(Math.toRadians(rayAngel));
			endY = Math.sin(Math.toRadians(rayAngel));

			for (PolyShape shape : map.shapes()) {

				for (int i = 0, j = shape.pointCount() - 1; i < shape.pointCount(); i++, j = i - 1) {
					if (getIntersection(startX, startY, startX + endX, startY + endY, shape.pX(i), shape.pY(i),shape.pX(j), shape.pY(j))) {
						if (intersectPoint[2] > intersectResult[2]) {
							System.arraycopy(intersectResult, 0, intersectPoint, 0, intersectPoint.length);
						}	
					}		
				}
			}

			//at the end of mian loop (first loop) assign Double.MAX_VALUE to intersectPoint[2]. 
			//if you remember values in intersectResult are stored in following order: x, y, ray distance 
			//to intersect and segment distance to intersect. the way we choose which ray should 
			//be drawn is based in the smallest ray distance to intersect for each ray. 
			//so every time we increment the ray intersectPoint[2] has to be changed to a very large number 
			//so the smaller one can be found.
			drawLine(gc, lightColor, startX, startY, intersectPoint[0], intersectPoint[1]);
			intersectPoint[2] = Double.MAX_VALUE;
		}
	}
}
