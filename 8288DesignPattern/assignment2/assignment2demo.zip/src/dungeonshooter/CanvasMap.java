package dungeonshooter;

import java.util.ArrayList;
import java.util.List;

import javafx.animation.AnimationTimer;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.scene.Node;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import dungeonshooter.animator.AbstractAnimator;
import dungeonshooter.animator.Animator;
import dungeonshooter.entity.Bullet;
import dungeonshooter.entity.Entity;
import dungeonshooter.entity.PolyShape;
import dungeonshooter.entity.property.HitBox;

/**
 * this class represents the drawing area. it is backed by {@link Canvas} class.
 * this class itself does not handle any of the drawing. this task is
 * accomplished by the {@link AnimationTimer}.
 * 
 * @author Shahriar (Shawn) Emami
 * @version Jan 13, 2019
 */
public class CanvasMap {

	private Canvas map;
	private Animator animator;
	
	// assignment 2 add
	
	private BooleanProperty drawBounds;
	private BooleanProperty drawFPS;
	
	private PolyShape border;
	
	private List<Entity> buffer;
	private List<Entity> players;
	private List<Entity> projectiles;
	private List<PolyShape> staticShapes;
	
	

	
	/**
	 * create a constructor and initialize all class variables.
	 */
	public CanvasMap() {
		this.drawBounds = new SimpleBooleanProperty();
		this.drawFPS = new SimpleBooleanProperty();
		// assignment 2
		/*
		 * Initialize the 4 lists. Initlize buffer and projectiles to size 500, 
		 * static shapes to 50 and player to 1
		 */
		this.staticShapes = new ArrayList<>(50);
		this.players = new ArrayList<>(1);
		this.projectiles = new ArrayList<>(500);
		this.buffer = new ArrayList<>(500);
		// add assets/floor/pavin.png
		this.border = new PolyShape();
		border.getDrawable().
		setFill( new ImagePattern( new Image( "file:assets/floor/pavin.png"), 0, 0, 256, 256, false));
	}
	
	public CanvasMap setDrawingCanvas(Canvas map) {
		//a. check if canvas is null, if it is throw null pointer exception.
		if( map == null)
			throw new NullPointerException();
		/*
		 * b. We want the size of the border to change if the size of canvas changes. 
		 * Get the width and height property of canvas and add to each a listener to 
		 * update the points in border class. You can just call set points and set 
		 * the four corners again. if you decide to go for a shape which is not a 
		 * simple rectangle you need to customize this behavior for your need. 
		 * You can try to add a scrolling page map.
		 */
		this.map = map;
		this.map.widthProperty().addListener((v, o, n)-> border.setPoints(0, 0, w(), 0, w(), h(), 0, h()));
		this.map.heightProperty().addListener((v, o, n)-> border.setPoints(0, 0, w(), 0, w(), h(), 0, h()));
		return this;
	}


	/**
	 * addSampleShapes in this method create bunch of sample shapes as you like. at
	 * least 3. make sure to customize your fill, width and stroke.
	 */
	public void addSampleShapes() {
		// add shape 4 points
		PolyShape ps1 = new PolyShape();
		double nums1[] = { 100, 150, 200, 180, 300, 280, 20, 250 };
		ps1.setPoints(nums1);
		staticShapes.add(ps1);
		// add shape 3 points
		PolyShape ps2 = new PolyShape();
		double nums2[] = { 220, 320, 180, 450, 50, 480, 100, 300 };
		// use [] as param
		ps2.setPoints(nums2);
		staticShapes.add(ps2);
		// add shape 3 points
		PolyShape ps3 = new PolyShape();
		// use ... as param
		ps3.setPoints(400, 450, 600, 250, 650, 300, 500, 600);
		staticShapes.add(ps3);

		// add random shapes
//		PolyShape rp1 = new PolyShape();
//		rp1.randomize(150, 450, 50, 4, 30);
//		staticShapes.add(rp1);
//		PolyShape rp2 = new PolyShape();
//		rp2.randomize(450, 150, 50, 4, 30);
//		staticShapes.add(rp2);
//		PolyShape rp3 = new PolyShape();
//		rp3.randomize(530, 530, 50, 4, 30);
//		staticShapes.add(rp3);
	}

	public BooleanProperty drawBoundsProperty() {
		return drawBounds;
	}

	public BooleanProperty drawFPSProperty() {
		return drawFPS;
	}


	/**
	 * create a method called gc. get the {@link GraphicsContext} of {@link Canvas}
	 * that allows direct drawing.
	 * 
	 * @return {@link GraphicsContext} of {@link Canvas}
	 */
	public GraphicsContext gc() {
		return map.getGraphicsContext2D();
	}

	/**
	 * create a method called getCanvas. get the JavaFX {@link Canvas} node
	 * 
	 * @return {@link Canvas} node
	 */
	public Canvas getCanvas() {
		return map;
	}

	public boolean getDrawBounds() {
		return drawBounds.get();
	}

	public boolean getDrawFPS() {
		return drawFPS.get();
	}


	/**
	 * create a method called h. get the height of the map,
	 * {@link Canvas#getHeight()}
	 * 
	 * @return height of canvas
	 */
	public double h() {
		return map.getHeight();
	}


	/**
	 * create a method called setAnimator. set an {@link AbstractAnimator}. if an
	 * animator exists {@link CanvasMap#stop()} it and call
	 * {@link CanvasMap#removeMouseEvents()}. then set the new animator and call
	 * {@link CanvasMap#start()} and {@link CanvasMap#registerMouseEvents()}.
	 * 
	 * @param newAnimator - new {@link AbstractAnimator} object
	 * @return the current instance of this object
	 */
	public CanvasMap setAnimator(Animator newAnimator) {
		if (animator != null) {
			this.stop();
			//this.removeMouseEvents();
		}
		this.animator = newAnimator;
		this.start();
		//this.registerMouseEvents();
		return this;
	}

	/**
	 * create a method called start. start the animator.
	 * {@link AnimationTimer#start()}
	 */
	public void start() {
		animator.start();

	}

	/**
	 * create a method called stop. stop the animator. {@link AnimationTimer#stop()}
	 */
	public void stop() {
		animator.stop();
	}

	/**
	 * create a method called w. get the width of the map, {@link Canvas#getWidth()}
	 * 
	 * @return width of canvas
	 */
	public double w() {
		return map.getWidth();
	}
	
	// assignment 2
	
	public List<PolyShape> staticShapes(){
		return this.staticShapes;
	}

	/*
	 * c. fireBullet is called by player when left mouse is clicked. 
	 * Pass the bullet argument to buffer. In a more complicated game this will 
	 * be the job of a projectile manager. However, for the sake of simplicity 
	 * we are mixing that job with canvasmap. If you decide to add any other 
	 * type of projectiles you still can use this same method.
	 */
	public void fireBullet(Bullet bullet) {
		buffer.add(bullet);
	}

	
	/*
	 * d. updateProjectilesList is called to add the buffer to projectiles list and then clear the buffer.
	 */
	public void updateProjectilesList() {
		projectiles.addAll(buffer);
		buffer.clear();
	}
	
	public PolyShape getMapShape() {
		return this.border;
	}
	
	/*
	 * e. inMap is used to call check if the HitBox argument is still within the boarder.getHitBox().
	 */	
	public boolean inMap(HitBox hitbox) {
		return border.getHitBox().containsBounds(hitbox);
	}
	
	public List<Entity> players(){
		return this.players;
	}
	
	public List<Entity> projectiles(){
		return this.projectiles;
	}


}
