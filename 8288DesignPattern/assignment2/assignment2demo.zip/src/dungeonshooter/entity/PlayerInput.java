package dungeonshooter.entity;

import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import utility.InputAdapter;

public class PlayerInput extends InputAdapter{

	private double x;
	private double y;
	private boolean left = false;
	private boolean right = false;
	private boolean up = false;
	private boolean down = false;
	private boolean leftClick = false;
	private boolean rightClick = false;
	private boolean middleClick = false;
	private boolean space = false;
	private boolean shift = false;
	
	public boolean hasMoved() {
		// undone
		return false;
	}
	
	public int leftOrRight() {
		//undone
		return 0;
	}
	
	public int upOrDown() {
		//undone
		return 0;
	}
	
	public boolean leftClicked() {
		return this.leftClick;
	}
	
	public boolean rightClicked() {
		return this.rightClick;
	}
	
	public boolean middleClicked() {
		return this.middleClick;
	}
	
	public double x() {
		return this.x;		
	}
	
	public double y() {
		return this.y;
	}
	
	public void mousePressed(MouseEvent e) {
		//undone
	}
	
	public void mouseRelease(MouseEvent e) {
		//undone
	}
	
	public void changeKeyStatus(KeyCode key, boolean isPressed) {
		//undone
	}
	
	public void keyPressed(KeyEvent key) {
		//undone
	}
	
	public void keyReleased(KeyEvent key) {
		//undone
	}
	
	public void moved(double x, double y) {
		//undone
	}
	
	public void dragged(double x, double y) {
		//undone
	}
	
	public boolean isSpace() {
		return this.space;
	}
	
	public boolean isShift() {
		return this.shift;
	}
}
