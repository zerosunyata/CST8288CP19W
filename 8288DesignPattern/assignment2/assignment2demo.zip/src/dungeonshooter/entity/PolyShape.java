package dungeonshooter.entity;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import dungeonshooter.entity.geometry.RectangleBounds;
import dungeonshooter.entity.property.Drawable;
import dungeonshooter.entity.property.HitBox;
import dungeonshooter.entity.property.Sprite;
import utility.Point;
import utility.RandUtil;

/**
 * PolyShape create this class inside of geometry. this object represents a
 * multi sided shape. this object keeps track of corners coordinates. this
 * coordinates are stored in an 2 dimensional array called points. each column
 * is one point. meaning row zero is x and row 1 is y. this is important do not
 * mix it up. example, third corner (x,y) is (points[0][2], points[1][2])
 * 
 */
public class PolyShape implements Entity {

	/*
	 * this class implements entity, you can use most of the code from your lab.
	 * Remove Colors, bound and strokeWidth class variables. Instead add Hitbox and
	 * Sprite.
	 */
	private int pointCount;
	private double[][] points = new double[4][4];
	private double minX, minY, maxX, maxY;
	private HitBox hitbox;
	private Sprite sprite;

	public PolyShape() {
		/*
		 * Hit box can be customized for custom shapes like PolyShape. 
		 * By overriding hasIntersectFull method and returning true hitbox will check for 
		 * more detailed points which is returned in getPoints which also must be overridden.
		 */
		hitbox = new HitBox() {
			protected boolean hasIntersectFull() {
				return true;
			}

			protected double[][] getPoints() {
				return points;
			}
		};
		sprite = new Sprite() {
			{
				setFill(new ImagePattern(new Image("file:assets/concrete/dsc_1621.png")));
			}

			public void draw(GraphicsContext gc) {
				gc.setLineWidth(getWidth());
				if (getStroke() != null) {
					gc.setStroke(getStroke());
					gc.strokePolygon(points[0], points[1], pointCount);
				}
				if (getFill() != null) {
					gc.setFill(getFill());
					gc.fillPolygon(points[0], points[1], pointCount);
				}
			}
		};
	}

	/**
	 * draw is simply to draw the shape.
	 * 
	 */
	public void draw(GraphicsContext gc) {
		// 1. call setLineWidth on gc and pass strokeWidth
		gc.setLineWidth(sprite.getWidth());
		// 2. if stroke is not null
		if (sprite.getStroke() != null) {
			// 1. call setStroke on gc and pass stroke
			gc.setStroke(sprite.getStroke());
			// 2. call strokePolygon on gc and pass points[0], points[1] and pointCount
			gc.strokePolygon(points[0], points[1], pointCount);
		}
		// 3. if fill is not null
		if (sprite.getFill() != null) {
			// 1. call setFill on gc and pass fill
			gc.setFill(sprite.getFill());
			// 2. call fillPolygon on gc and pass points[0], points[1] and pointCount
			gc.fillPolygon(points[0], points[1], pointCount);
		}
	}

	/**
	 * drawCorners is going to draw little circles on the corners of the shape plus
	 * a little number
	 * 
	 * @param gc
	 */
	public void drawCorners(GraphicsContext gc) {
		// 1. set a new fill if you like to use a different color
		gc.setFill(Color.AZURE);
		// 2. start a for loop which should be smaller than pointCount
		for (int i = 0; i < pointCount; i++) {
			// 1. call fillText on gc and pass to it Integer.toString( i), points[0][i] - 5
			// and points[1][i] - 5.
			// this will make a little number counter near the corner
			gc.fillText(Integer.toString(i), points[0][i] - 5, points[1][i] - 5);
			// 2. call fillOval on gc and pass to it points[0][i] - 5, points[1][i] - 5, 10
			// and 10
			gc.fillOval(points[0][i] - 5, points[1][i] - 5, 10, 10);
		}
	}


	public int pointCount() {
		return pointCount;

	}

	public double[][] points() {
		return points;

	}

	/**
	 * px and py methods return x and y of specific corner. remember how points is
	 * ordered, read PolyShape description again.
	 * 
	 * @param index
	 * @return
	 */
	public double pX(int index) {
		// 4. px and py methods return x and y of specific corner.
		return points[index][0];

	}

	/**
	 * px and py methods return x and y of specific corner. remember how points is
	 * ordered, read PolyShape description again.
	 * 
	 * @param index
	 * @return
	 */
	public double pY(int index) {
		// 4. px and py methods return x and y of specific corner.
		return points[index][1];

	}

	/**
	 * randomize, this is bonus. create this function based on class diagram. the
	 * purpose of it is to randomly create a shape, the trick is the lines should
	 * not cross each other. it should do everything else that setPoint does.
	 * 
	 * @param centerX
	 * @param centerY
	 * @param size
	 * @param minPoints
	 * @param maxPoints
	 * @return
	 */
	public PolyShape randomize(double centerX, double centerY, double size, int minPoints, int maxPoints) {
		int numpoints = RandUtil.getInt(minPoints, maxPoints);
		double nums[] = new double[numpoints * 2];

		Point center = new Point(centerX, centerY);
		SortedMap<Double, Point> sp = new TreeMap<Double, Point>();
		for (int i = 0; i < numpoints; i++) {
			// Point p = center.random(size, size + 100);
			// sp.put(new Double(center.angle(p)), p);
		}

		Set s = sp.entrySet();
		Iterator iter = s.iterator();
		int counter = 0;
		while (iter.hasNext()) {
			Map.Entry m = (Map.Entry) iter.next();
			Point p = (Point) m.getValue();
			nums[counter] = p.x();
			nums[counter + 1] = p.y();
			counter += 2;
		}

		double angels[] = new double[numpoints];
		// 1. set nums[0] to minX and maxX
		minX = nums[0];
		maxX = nums[0];
		// 2. set nums[1] to minY and maxY
		minY = nums[1];
		maxY = nums[1];
		// 3. set nums.length / 2 to pointCount
		pointCount = nums.length / 2;
		// 4. initialize points with 2 rows and pointCount of columns
		points = new double[2][pointCount];
		// 5. start a for loop with i and j at zero. j increments by 1 and i increments
		// by 2.
		// continue looping as long as i is smaller than nums.length.
		// i is used to access every 2 point in nums array while j is used to fill
		// points array.
		for (int i = 0, j = 0; i < nums.length; j++, i += 2) {
			// 1. call updateMinMax and pass nums[i] and nums[i + 1].
			// this method checks if min and max has changed
			updateMinMax(nums[i], nums[i + 1]);
			// 2. assign nums[i] to points[0][j]
			points[0][j] = nums[i];
			// 3. assign nums[i + 1] to points[1][j]
			points[1][j] = nums[i + 1];
		}
		// 6. initialize bounds with minX, minY, maxX-minX and maxY-minY
		
		this.hitbox.setBounds(minX, minY, maxX - minX, maxY - minY);
		// 7. return this
		return this;
	}


	/**
	 * setPoints can take many points. this method uses "..." which is called
	 * vararg. tread it the same as array inside of the function. nums is a one
	 * dimensional array, every 2 index is considered one point. it is formatted as
	 * x1,y1,x2,y2,x3,y3... . this method will initialize rest of variables in
	 * PolyShape object. min and max variables are used in this method to determine
	 * the 4 corners of PolyShape so bounds can be initialized.
	 *
	 * @param nums
	 * @return
	 */
	public PolyShape setPoints(double... nums) {
		// 1. set nums[0] to minX and maxX
		minX = nums[0];
		maxX = nums[0];
		// 2. set nums[1] to minY and maxY
		minY = nums[1];
		maxY = nums[1];
		// 3. set nums.length / 2 to pointCount
		pointCount = nums.length / 2;
		// 4. initialize points with 2 rows and pointCount of columns
		points = new double[2][pointCount];
		// 5. start a for loop with i and j at zero. j increments by 1 and i increments
		// by 2.
		// continue looping as long as i is smaller than nums.length.
		// i is used to access every 2 point in nums array while j is used to fill
		// points array.
		for (int i = 0, j = 0; i < nums.length; j++, i += 2) {
			// 1. call updateMinMax and pass nums[i] and nums[i + 1].
			// this method checks if min and max has changed
			updateMinMax(nums[i], nums[i + 1]);
			// 2. assign nums[i] to points[0][j]
			points[0][j] = nums[i];
			// 3. assign nums[i + 1] to points[1][j]
			points[1][j] = nums[i + 1];
		}
		// 6. initialize bounds with minX, minY, maxX-minX and maxY-minY
		this.hitbox.setBounds(minX, minY, maxX - minX, maxY - minY);
		// 7. return this
		return this;
	}


	/**
	 * updateMinMax, this is an internal helper method to update min and max values
	 * based on the x and y input. inside check if minX and maxX needs to be updated
	 * based on new x, then do the same fo y.
	 * 
	 * @param x
	 * @param y
	 */
	private void updateMinMax(double x, double y) {
		if (minX > x)
			minX = x;
		if (maxX < x)
			maxX = x;
		if (minY > y)
			minY = y;
		if (maxY < y)
			maxY = y;
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean hasHitbox() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public Sprite getDrawable() {
		// TODO Auto-generated method stub
		return this.sprite;
	}

	@Override
	public boolean isDrawable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public HitBox getHitBox() {
		// TODO Auto-generated method stub
		return this.hitbox;
	}


}
