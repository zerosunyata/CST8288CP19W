package dungeonshooter.entity.property;

import java.util.Arrays;

import dungeonshooter.entity.Entity;
import dungeonshooter.entity.geometry.RectangleBounds;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import utility.Point;

/*
 * 1. this class implements Entity.
 */
public class HitBox implements Entity {
	private Point prev;
	private RectangleBounds bounds;
	private Sprite sprite;
	private double[][] points;
	private double[] result;

	public HitBox() {
		// 5. In constructor initialize points to size 2 by 4 and results to 4. Create
		// prev point as well.
		points = new double[2][4];
		result = new double[4];
		prev = new Point();
		sprite = new Sprite() {
			public void draw(GraphicsContext gc) {
				gc.setStroke(getStroke());
				gc.setLineWidth(getWidth());
				gc.strokeRect(bounds.x(), bounds.y(), bounds.w(), bounds.h());
			}
		};
		sprite.setStroke(Color.RED).setWidth(3);
	}

	public HitBox setBounds(RectangleBounds bounds) {
		this.bounds = bounds;
		return this;
	}

	public HitBox setBounds(double x, double y, double w, double h) {
		this.bounds = new RectangleBounds(x, y, w, h);
		return this;
	}

	public HitBox translate(double dx, double dy) {
		// undone
		return this;
	}

	public HitBox undoTranslate() {
		// undone
		return this;
	}

	public boolean containsBounds(HitBox box) {
		// undone
		return false;
	}

	public boolean intersectBounds(HitBox box) {
		// undone
		return false;
	}

	public boolean intersectFull(HitBox box) {
		// undone
		return false;
	}

	public boolean intersectFull(double[][] ohterPoints) {
		// undone
		return false;
	}

	protected boolean hasIntersectFull() {
		// undone
		return false;
	}

	protected double[][] getPoints() {
		return this.points;
	}

	public void update() {
		// undone
	}

	public boolean hasHitbox() {
		// undone
		return false;
	}

	public HitBox getHitBox() {
		return this;
	}

	public boolean isDrawable() {
		// undone
		return true;
	}

	public Sprite getDrawable() {
		return this.sprite;
	}

	public RectangleBounds getBound() {
		return this.bounds;
	}

	public Point getPrev() {
		return this.prev;
	}

	@Override
	public String toString() {
		return "HitBox [prev=" + prev + ", bounds=" + bounds + ", sprite=" + sprite + ", points="
				+ Arrays.toString(points) + ", result=" + Arrays.toString(result) + "]";
	}

}
