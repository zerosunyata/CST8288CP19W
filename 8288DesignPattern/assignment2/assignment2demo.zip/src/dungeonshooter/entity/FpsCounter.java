package dungeonshooter.entity;

import dungeonshooter.entity.property.Drawable;
import dungeonshooter.entity.property.HitBox;
import dungeonshooter.entity.property.Sprite;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import utility.Point;

/**
 * FpsCounter create this class inside of entity package.
 */

/*
 * 1. Same as the lab
 */
public class FpsCounter implements Entity {
	public static final double ONE_SECOND = 1000000000L;
	public static final double HALF_SECOND = ONE_SECOND / 2f;

	private Font fpsFont;
	private String fpsDisplay;
	private int frameCount;
	private double lastTime;
	private Point pos = new Point();
	private Sprite sprite;
	

	/*
	 * constructor needs to setPos and setFont. for font use Font.font(
	 * Font.getDefault().getFamily(), FontWeight.BLACK, 24).
	 */
	public FpsCounter(double x, double y) {
		sprite = new Sprite() {

			@Override
			public void draw(GraphicsContext gc) {
				Font font = gc.getFont();
				gc.setFont(fpsFont);
				gc.setFill(getFill());
				gc.fillText(fpsDisplay, pos.x(), pos.y());
				gc.setStroke(getStroke());
				gc.setLineWidth(getWidth());
				gc.strokeText(fpsDisplay, pos.x(), pos.y());
				gc.setFont(font);
			}			
		};
		setPos(x, y);
		setFont(Font.font(Font.getDefault().getFamily(), FontWeight.BLACK, 24));
	}

	/**
	 * 
	 * calculateFPS needs to update the frame count.
	 * 
	 * @param now
	 */
	public void calculateFPS(long now) {
		// 1. in an if condition check if now - lastTime is bigger than HALF_SECOND
		if (now - lastTime >= HALF_SECOND) {
			// 1. assign frameCount*2 to fpsDisplay
			fpsDisplay = Integer.toString(frameCount * 2);
			// 2. set frameCount to 0
			frameCount = 0;
			// 3. set lastTime to now
			lastTime = now;
		}
		// 2. increment frameCount
		frameCount++;
	}

	/**
	 * draw needs to draw the current fps on canvas.
	 */
	public void draw(GraphicsContext gc) {
		// 1. get font from gc and save it in a temp variable so we can set it back
		// later
		Font font = gc.getFont();
		// 2. set fpsFont as font on gc
		gc.setFont(fpsFont);
		gc.setFont(font);
	}


	public FpsCounter setFont(Font font) {
		this.fpsFont = font;
		return this;
	}

	public FpsCounter setPos(double x, double y) {
		this.pos.set(x, y);
		return this;
	}
	
	public void update() {
		//undone
	}
	
	public boolean hasHitbox() {
		//undone
		return false;
	}	

	@Override
	public Drawable getDrawable() {
		// TODO Auto-generated method stub
		return this.sprite;
	}

	@Override
	public boolean isDrawable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public HitBox getHitBox() {
		// TODO Auto-generated method stub
		return null;
	}

}
