package dungeonshooter.entity;

import dungeonshooter.CanvasMap;
import dungeonshooter.entity.property.Drawable;
import dungeonshooter.entity.property.HitBox;
import dungeonshooter.entity.property.Sprite;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.transform.Rotate;
import utility.Point;

public class Player implements Entity {

	private Rotate rotationPlayer;
	private double angle;
	private double playerFrame = 0;
	private double muzzleFrame = 0;
	private Point pos = new Point();
	private Point prev = new Point();
	private Point dimension = new Point();
	private Sprite sprite;
	private HitBox hitbox;

	private PlayerInput input;

	private CanvasMap map;

	public PlayerInput getInput() {
		return input;
	}

	public void setInput(PlayerInput input) {
		this.input = input;
	}

	public Player(double x, double y, double w, double h) {
		rotationPlayer = new Rotate();
		pos = new Point(x - w / 2, y - 5 / 2);
		prev = new Point(pos);
		dimension = new Point(w, h);
		double size = h * .74;
		hitbox = new HitBox().setBounds( pos.x() + dimension.x() * .303 - size / 2, pos.y() + dimension.y() * .58 - size / 2, size, size);

		sprite = new Sprite() {
			private final Image[] PLAYER = new Image[20];
			private final Image[] MUZZLE = new Image[16];
			// constructor
			{
				for (int i = 0; i < PLAYER.length; i++) {
					PLAYER[i] = new Image("file:assets\\rifle\\idle\\survivor-idle_rifle_" + i + ".png");
				}
				for (int i = 0; i < MUZZLE.length; i++) {
					MUZZLE[i] = new Image("file:assets\\muzzle_flashes\\m_" + i + ".png");
				}
			}

			public void draw(GraphicsContext gc) {
				gc.save();
				// rotate gc for drawing
				gc.setTransform(rotationPlayer.getMxx(), rotationPlayer.getMyx(), rotationPlayer.getMxy(),
						rotationPlayer.getMyy(), rotationPlayer.getTx(), rotationPlayer.getTy());
				// if left click display fire animation
				if (input.leftClicked()) {
					// undone
					//gc.drawImage(MUZZLE[(int) muzzleFrame], getRifleMuzzleX() - 8, getRifleMuzzleY() - 25, 50, 50); 
					muzzleFrame += .5;
				}
				// darw player image
				gc.drawImage(PLAYER[(int) playerFrame], pos.x(), pos.y(), dimension.x(), dimension.y());
				gc.restore(); // this number is how fast the next frame of player animation will be drawn. The
								// higher the faster.
				playerFrame += 0.25;
				// reset frame counts if reach the max frame
				if (playerFrame >= PLAYER.length) {
					playerFrame = 0;
				}
				if (muzzleFrame >= MUZZLE.length || !input.leftClicked()) {
					muzzleFrame = 0;
				}
			}
		};

	}

	public Player setMap(CanvasMap map) {
		this.map = map;
		return this;
	}

	public double getPlayerCenterX() {
		return 0;
	}

	public void stepBack() {

	}

	@Override
	public void update() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean hasHitbox() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public Drawable getDrawable() {
		// TODO Auto-generated method stub
		return this.sprite;
	}

	@Override
	public boolean isDrawable() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public HitBox getHitBox() {
		// TODO Auto-generated method stub
		return this.hitbox;
	}
}
