package dungeonshooter.entity;

import dungeonshooter.entity.property.Drawable;
import dungeonshooter.entity.property.HitBox;
import javafx.scene.image.Image;
/*
 * 1. This class is an entity. Meaning it must implement Entity
 */
public class Bullet implements Entity {
	/*
	 * Load the static final BULLET image using: new Image( "file:assets\\bullet\\b_3.png");
	 */
	private static final Image BULLET = new Image( "file:assets\\bullet\\b_3.png");
	
	/*
	 * There are 2 constructors. One constructor does not take width and height. 
	 * When chaining to next constructor use 6 and 6 as width and height.
	 */
	public Bullet() {
		this(6,6);
	}

	public Bullet(int width, int height) {
		
	}
	
	/**
	 * a. Angle is defined by the position of mouse relevant to center of player which is given by player.
b. Create a new hitbox and setBounds with given x,y,w,and h.
c. Create a new sprite like this: sprite = new Sprite(){
private RectangleBounds bounds = hitbox.getBounds();
public void draw( GraphicsContext gc){
gc.drawImage( BULLET, bounds.x(), bounds.y(), bounds.w(), bounds.h());
}
};
	 */
	
	
	/*
	 * In the update method you need to calculate the x and y like: double x = Math.cos( Math.toRadians( angle)) * 7;
double y = Math.sin( Math.toRadians( angle)) * 7;
hitbox.translate( x, y);
7 is the speed at which the bullets travel. Feel free to customize it. 
Finally translate the hitbox to the new position. 
Have in mind translate adds x and y to current position, it is not a set.
	 */
	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean hasHitbox() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Drawable getDrawable() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isDrawable() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public HitBox getHitBox() {
		// TODO Auto-generated method stub
		return null;
	}
}
