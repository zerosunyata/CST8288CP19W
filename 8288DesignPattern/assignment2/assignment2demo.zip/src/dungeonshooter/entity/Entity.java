package dungeonshooter.entity;

import dungeonshooter.entity.property.Drawable;
import dungeonshooter.entity.property.HitBox;
import dungeonshooter.entity.property.Sprite;

/*
 * 1. This is an interface used by all entities in the game. Look at class diagram for details
 */
public interface Entity{

	public void update();
	public boolean hasHitbox();
	public Drawable getDrawable();
	public boolean isDrawable();
	public HitBox getHitBox();
}
