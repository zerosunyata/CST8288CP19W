package dungeonshooter.animator;

import java.util.Iterator;

import dungeonshooter.entity.Bullet;
import dungeonshooter.entity.Entity;
import dungeonshooter.entity.Player;
import dungeonshooter.entity.PolyShape;
import dungeonshooter.entity.property.HitBox;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 * this class handles the job of drawing on the canvas. it must extend
 * {@link AbstractAnimator}
 * 
 * @author Shahriar (Shawn) Emami
 * @version Jan 13, 2019
 */

/*
 * details are in sequence diagram. The job of this animator is to update all entities first and then draw them. during the update all entities will be looped. Each entity has a update method that needs to be called. After the update all interactions between entities must be checked.
a. Are the entities still in map? if not remove them.
b. Have the projectiles hit anything such as static shapes? If so remove them.
c. Has the player hit a shape? If so, do not go through the shape and step back.
d. If there are other entities that can attack to be attacked must be checked.
e. If bounds option is active change color of bounding box to something else if near shape.
 */
public class Animator extends AbstractAnimator {

	private Color background = Color.ANTIQUEWHITE;
	
	@Override
	protected void handle(GraphicsContext gc, long now) {
		updateEntities();
		clearAndFill(gc, background);
		drawEntities(gc);
	}

	/**
	 * create a toString method and return "Animator" as the name of this class
	 */
	@Override
	public String toString() {
		return "Animator";

	}
	
	/*
	 * SD updateEntities()
	 */
	public void updateEntities() {
		map.updateProjectilesList();
		map.players();
		map.projectiles();
		map.staticShapes();
		
		for (Entity bullet: map.projectiles())
			bullet.update();
		
		for(Entity player: map.players())
			player.update();
		
		for(PolyShape shape: map.staticShapes())
			shape.update();
		
		if(map.getDrawBounds()) {
			for(Entity bullet: map.projectiles()) {
				bullet.getHitBox().getDrawable().setStroke(Color.RED);
			}
			for(Entity player: map.players()) {
				//player.getHitBox().getDrawable().setStroke(Color.RED);
			}
		}
		
		for(PolyShape shape: map.staticShapes()) {
			processEntityList(map.projectiles().iterator(), shape.getHitBox());
			processEntityList(map.players().iterator(), shape.getHitBox());
		}		
	}
	
	/*
	 * SD processEntityList()
	 */
	public void processEntityList(Iterator<Entity> iterator, HitBox shapeHitBox) {
		while(iterator.hasNext()) {
			Entity e = iterator.next();
			HitBox hit = e.getHitBox();
			if(!map.inMap(hit)) {
				if (e instanceof Player) {
					((Player) e).stepBack();
				}else if (e instanceof Bullet) {
					iterator.remove();
				}
			}else if(shapeHitBox.intersectBounds(hit)) {
				if(map.getDrawBounds()) {
					hit.getDrawable().setStroke(Color.BLUEVIOLET);
				}
				if(shapeHitBox.intersectFull(hit)) {
					if(e instanceof Player) {
						((Player) e).stepBack();						
					}else if(e instanceof Bullet) {
						iterator.remove();
					}
				}
			}
		}
	}

}








