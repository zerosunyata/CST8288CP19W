package dungeonshooter.animator;

import java.util.function.Consumer;

import javafx.animation.AnimationTimer;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import dungeonshooter.CanvasMap;
import dungeonshooter.entity.Entity;
import dungeonshooter.entity.FpsCounter;
import dungeonshooter.entity.PolyShape;
import utility.Point;

/**
 * this class must extend {@link AnimationTimer}. job of this class is to hold
 * common functionality among animators.
 * 
 * @author Shahriar (Shawn) Emami
 * @version Jan 13, 2019
 */

/*
 * AbstractAnimator
1. this class does not contain the intersect calculation anymore That method is moved to utility in a class called IntersectUtil.
2. Mouse movement methods have also been removed and placed in InputAdapter.
3. Handle method has been simplified as now it only needs to deal with fps. Other options are removed.
4. A new method drawEntites is added. Details are in sequence diagram.
o when drawing order matters. If you draw canvas last it will cover all other entities.
 */
public abstract class AbstractAnimator extends AnimationTimer {

	/**
	 * create a protected class variable of type {@link CanvasMap} and name it map.
	 */

	protected CanvasMap map;

	/**
	 * create a protected class variable of type {@link Point} and name it mouse.
	 */

	protected Point mouse;

	private FpsCounter fps;

	/**
	 * in constructor initialize fpsCounter object. add fill, stroke and width as desired.
	 */
	public AbstractAnimator() {
		mouse = new Point();
		fps = new FpsCounter(10,25);
	}

	/**
	 * clearAndFill, clear the canvas
	 *
	 * @param gc
	 * @param background
	 */
	public void clearAndFill( GraphicsContext gc, Color background) {
		//1.	call setFill on gc and pass background
		gc.setFill(background);
		//2.	call clearRect on gc and pass 0, 0, c.w() and c.h()
		gc.clearRect(0, 0, map.w(), map.h());
		//3.	call fillRect on gc and pass 0, 0, c.w() and c.h()
		gc.fillRect(0, 0, map.w(), map.h());
		
	}


	/**
	 * <p>
	 * create a method called handle that is inherited from
	 * {@link AnimationTimer#handle(long)}. this method is called by JavaFX
	 * application, it should not be called directly.
	 * </p>
	 * <p>
	 * inside of this method call the abstract handle method
	 * {@link AbstractAnimator#handle(GraphicsContext, long)}.
	 * {@link GraphicsContext} can be retrieved from {@link CanvasMap#gc()}
	 * </p>
	 * 
	 * @param now - current time in nanoseconds, represents the time that this
	 *            function is called.
	 */
	
	/**
	 * 3.	handle, this method needs to be modified so fps can be drawn. 
	 * fps drawing will be placed in AbstractAnimator since it is shared.
	 */
	@Override
	public void handle(long now) {
		GraphicsContext gc = map.gc();
		if(map.getDrawFPS()) 
			fps.calculateFPS(now);
		handle(gc, now);		

		if(map.getDrawFPS()) {
			fps.getDrawable().draw(gc);
		}
	}

	/**
	 * create a protected abstract method called handle, this method to be
	 * overridden by subclasses.
	 * 
	 * @param gc  - {@link GraphicsContext} object.
	 * @param now - current time in nanoseconds, represents the time that this
	 *            function is called.
	 */

	abstract protected void handle(GraphicsContext gc, long now);


	/**
	 * create a setter called setCanvas to inject (set) the {@link CanvasMap}
	 * 
	 * @param map - {@link CanvasMap} object
	 */
	public void setCanvas(CanvasMap map) {
		this.map = map;
	}

	public void drawEntities(GraphicsContext gc) {
		//
		Consumer<Entity> draw = e->{
			if(e.isDrawable()) {
				e.getDrawable().draw(gc);
				if(map.getDrawBounds()) {
					if(e.getHitBox()!=null && e.getHitBox().getDrawable()!=null)
						try {
						e.getHitBox().getDrawable().draw(gc);
						}catch(Exception err) {
							System.out.println(err);
							System.out.println(e);
						}
					else
						System.out.print(e);
				}				
			}
		};
		draw.accept(map.getMapShape());
		for(PolyShape e: map.staticShapes())
			draw.accept(e);
		for(Entity e: map.projectiles())
			draw.accept(e);
		for(Entity e: map.players())
			draw.accept(e);
	}
}
