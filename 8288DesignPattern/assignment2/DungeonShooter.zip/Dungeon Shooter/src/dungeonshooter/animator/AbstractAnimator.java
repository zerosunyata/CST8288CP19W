package dungeonshooter.animator;

import java.util.function.Consumer;
import javafx.animation.AnimationTimer;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import dungeonshooter.CanvasMap;
import dungeonshooter.entity.Entity;
import dungeonshooter.entity.FpsCounter;
import dungeonshooter.entity.PolyShape;
import dungeonshooter.entity.Score;
import utility.Point;


public abstract class AbstractAnimator extends AnimationTimer{

	/**
	 * create a protected class variable of type {@link CanvasMap} and name it map.
	 */
	protected CanvasMap map;

	/**
	 * create a protected class variable of type {@link Point} and name it mouse.
	 */
	protected Point mouse;
	
	private FpsCounter fps;
	
	private Score score;

	/**
	 * this array has in order x, y, scalar of intersect point with ray and scalar of intersect with line segment.
	 */
	protected double[] intersectResult;

	/**
	 * create a protected constructor and initialize the {@link AbstractAnimator#mouse} variable
	 */

	
	public AbstractAnimator(){
		mouse = new Point();
		intersectResult = new double[4];
	    fps = new FpsCounter(10,25);
	    fps.getDrawable().setFill(Color.PURPLE).setStroke(Color.WHEAT).setWidth(1);
	   
	    score =  new Score(10,50);
	    score.getDrawable().setFill(Color.PURPLE).setStroke(Color.WHEAT).setWidth(1);
		//fps = new FpsCounter(10,25);
	}
	
	/**
	 * create a setter called setCanvas to inject (set) the {@link CanvasMap}
	 * @param map - {@link CanvasMap} object
	 */
	public void setCanvas( CanvasMap map){
		this.map = map;
	}
		
	
	public void clearAndFill(GraphicsContext gc, Color background) {
		gc.setFill(background);
		gc.clearRect(0, 0, map.w(), map.h());
		gc.fillRect(0, 0, map.w(), map.h());
	}

	
	public void drawEntities (GraphicsContext gc) {

		
		Consumer<Entity> draw = e-> {
			
			if(e.isDrawable()) {
				e.getDrawable().draw(gc);
				
				if(map.getDrawBounds()) {
					e.getHitBox().getDrawable().draw(gc);
				}
			}				
		};
	
		
		draw.accept( map.getMapShape());			
		
		for(PolyShape e: map.staticShapes())
		draw.accept(e);				
		
		for(Entity e: map.projectiles())		
	    draw.accept(e);				
		
		for(Entity e: map.players())		
		draw.accept(e);	
	}
		
	/**
	 * <p>create a method called handle that is inherited from {@link AnimationTimer#handle(long)}.
	 * this method is called by JavaFX application, it should not be called directly.</p>
	 * <p>inside of this method call the abstract handle method {@link AbstractAnimator#handle(GraphicsContext, long)}.
	 * {@link GraphicsContext} can be retrieved from {@link CanvasMap#gc()}</p>
	 * @param now - current time in nanoseconds, represents the time that this function is called.
	 */

	
	@Override
	public void handle( long now){
		
		GraphicsContext gc = map.gc();
		
		if(map.getDrawFPS())
			fps.calculateFPS(now);
		
		if(map.getDrawScore())
			score.calculateScore(now);
		
		
		handle( gc, now);
		

		if(map.getDrawFPS())
			fps.getDrawable().draw(gc);
		
		if(map.getDrawScore())
			score.getDrawable().draw(gc);
	}

	/**
	 * create a protected abstract method called handle, this method to be overridden by subclasses.
	 * @param gc - {@link GraphicsContext} object.
	 * @param now - current time in nanoseconds, represents the time that this function is called.
	 */
	protected abstract void handle(GraphicsContext gc,  long now);
}
