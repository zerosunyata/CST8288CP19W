package dungeonshooter.entity;

import dungeonshooter.entity.property.Drawable;
import dungeonshooter.entity.property.HitBox;
import dungeonshooter.entity.property.Sprite;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import utility.Point;

public class Score implements Entity{
	
	public static final double ONE_SECOND = 1000000000L;
	public static final double HALF_SECONG = ONE_SECOND / 2F;
	private Font scoreFont;
	private String scoreDisplay;
	private int frameCount;
	private double lastTime;
	private Point pos;
	private Sprite sprite;
	
	private static int score = 0;
	
	public Score (double x, double y) {
		sprite = new Sprite() {
			
			@Override
			public void draw(GraphicsContext gc) {
				
				Font f = gc.getFont();
				
				gc.setFont(scoreFont);
				
				gc.setFill(getFill());
					
				gc.fillText(scoreDisplay, pos.x(), pos.y());
					
				gc.setStroke(getStroke());
					
				gc.setLineWidth(getWidth());
     
				gc.strokeText(scoreDisplay, pos.x(), pos.y());
				 
				gc.setFont(f);
			}
		};
		setPos(x, y);
		setFont(Font.font( Font.getDefault().getFamily(), FontWeight.BLACK, 24));	
	}
	
	public void calculateScore(long now) {
		if (now-lastTime > HALF_SECONG) {
			scoreDisplay = String.valueOf(score += 100);
			frameCount = 0;
			lastTime = now;		
		}
		frameCount++;
	}
	
	public Score setFont(Font font) {
		this.scoreFont = font;
		return this;		
	}

	public Score setPos(double x, double y) {
		this.pos = new Point( x,  y);	
		return this;
	}
	
	@Override
	public void update() {
					
	}
	@Override
	public boolean hasHitbox() {
		return false;
	}
	@Override
	public HitBox getHitBox() {
		return null;
	}		
	@Override
	public boolean isDrawable() {
		return true;
	}		
	@Override
	public Sprite getDrawable() {
		return sprite;
	}
	
}
