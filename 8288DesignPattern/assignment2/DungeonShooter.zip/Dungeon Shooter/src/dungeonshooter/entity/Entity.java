package dungeonshooter.entity;

import dungeonshooter.entity.property.Drawable;
import dungeonshooter.entity.property.HitBox;

public interface Entity {
	
	abstract public void update();
	
	abstract public boolean hasHitbox();
	
	abstract public Drawable<?> getDrawable();
	
	abstract public boolean isDrawable();
	
	abstract public HitBox getHitBox();
	
}
