package dungeonshooter.entity;

import javafx.scene.Node;
import javafx.scene.canvas.Canvas;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import utility.InputAdapter;
import dungeonshooter.entity.Player;

public class PlayerInput extends InputAdapter <Canvas> {
	private double x;
	private double y; 
	private boolean left = false;
	private boolean right = false;
	private boolean up = false;


	private boolean down = false;
	private boolean leftClick = false;
	private boolean rightClick = false;
	private boolean middleClick = false;
	private boolean space = false;
	private boolean shift = false;
	
	private boolean changeWeapon1 = true;
	private boolean changeWeapon2 = false;
	private boolean changeWeapon3 = false;
	
	private int playerNumber = Player.PLAYER1;

	public boolean hasMoved() {
		return up || down || left || right;
	}

	
	public int leftOrRight() {
		if (!right && !left)
			return 0;
		if(right)
			return 1;
		return -1;
		
	}

	public int upOrDown() {
		if (!up && !down)
			return 0;
		if(up)
			return -1;
		return 1;		
		
	}

	public boolean leftClicked() {
		return leftClick;
	}

	public boolean rightClicked() {
		return rightClick;
	}

	public boolean middleClicked() {
		return middleClick;
	}

	public double x() {
		return x;
	}

	public double y() {
		return y;
	}


	@Override
	protected void mousePressed(MouseEvent e) {
		leftClick=e.isPrimaryButtonDown();
		rightClick = e.isSecondaryButtonDown();
		middleClick = e.isMiddleButtonDown();		
		super.mousePressed(e);
	}


	@Override
	protected void mouseReleased(MouseEvent e) {	
		leftClick=false;
		rightClick=false;	
		middleClick = false;		
		super.mouseReleased(e);		
	}
	
	
	/**
	 * check key status
	 * @param key
	 * @param isPressed
	 */
	public void changeKeyStatusPlayer1(KeyCode key, boolean isPressed) {
		switch(key) {					
		case W:	        
			up = isPressed;
			break;
		case A:
			left =  isPressed;
			break;
		case S:
			down = isPressed;
			break;
		case D:
			right = isPressed;
			break;
		case SHIFT:
			shift = isPressed;
			break;
		case SPACE:
			space = isPressed;
			break;
		case R:
			setChangeWeapon1(isPressed);
			break;
		case T:
			setChangeWeapon2(isPressed);
			break;
		}
	}

	// bonus
	public void changeKeyStatusPlayer2(KeyCode key, boolean isPressed) {
	}

	@Override
	protected void keyPressed(KeyEvent key) {	
		if(getPlayerNumber() == Player.PLAYER1)
			changeKeyStatusPlayer1(key.getCode(), true);	
		if(getPlayerNumber() == Player.PLAYER2)	
			changeKeyStatusPlayer2(key.getCode(), true);
	}

	@Override
	protected void keyReleased(KeyEvent key) {	
		if(getPlayerNumber() == Player.PLAYER1)	
			changeKeyStatusPlayer1(key.getCode(), false);		
		if(getPlayerNumber() == Player.PLAYER2)
			changeKeyStatusPlayer2(key.getCode(), false);	
	}


	@Override
	protected void moved(double x, double y) {	
		this.x = x;
		this.y = y;
	}

	@Override
	protected void dragged(double x, double y) {
		this.x = x;
		this.y = y;	
	}

	//property
	public boolean isSpace() {
		return space;
	}

	public boolean isShift() {
		return shift;
	}

	public void setSpace(boolean space) {
		this.space = space;
	}

	public void setShift(boolean shift) {
		this.shift = shift;
	}


	public int getPlayerNumber() {
		return playerNumber;
	}


	public void setPlayerNumber(int playerNumber) {
		this.playerNumber = playerNumber;
	}


	public boolean isChangeWeapon1() {
		return changeWeapon1;
	}


	public void setChangeWeapon1(boolean changeWeapon1) {
		this.changeWeapon1 = changeWeapon1;
	}


	public boolean isChangeWeapon2() {
		return changeWeapon2;
	}


	public void setChangeWeapon2(boolean changeWeapon2) {
		this.changeWeapon2 = changeWeapon2;
	}


	public boolean isChangeWeapon3() {
		return changeWeapon3;
	}


	public void setChangeWeapon3(boolean changeWeapon3) {
		this.changeWeapon3 = changeWeapon3;
	}
	
	public boolean isLeft() {
		return left;
	}


	public void setLeft(boolean left) {
		this.left = left;
	}


	public boolean isRight() {
		return right;
	}


	public void setRight(boolean right) {
		this.right = right;
	}


	public boolean isUp() {
		return up;
	}


	public void setUp(boolean up) {
		this.up = up;
	}


	public boolean isDown() {
		return down;
	}


	public void setDown(boolean down) {
		this.down = down;
	}

}
