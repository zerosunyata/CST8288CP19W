package dungeonshooter.entity;

import dungeonshooter.CanvasMap;
import dungeonshooter.entity.property.Drawable;
import dungeonshooter.entity.property.HitBox;
import dungeonshooter.entity.property.Sprite;
import javafx.geometry.Point2D;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.transform.Rotate;
import utility.Point;

public class Player implements Entity {
	public static final int PLAYER1 = 1;
	public static final int PLAYER2 = 2;

	private Rotate rotationPlayer;
	private double angle;
	private double playerFrame = 0;
	private double muzzleFrame = 0;
	private Point pos;
	private Point dimension;
	private Point prev;
	private Sprite sprite;
	private HitBox hitbox;
	private PlayerInput input;
	private CanvasMap map;
	
	private boolean weapon1 = true;
	private boolean weapon2 = false;
	private boolean weapon3 = false;

	public Player(double x, double y, double w, double h) {

		
		rotationPlayer = new Rotate();
		
		pos = new Point(x - w / 2, y - h / 2);
		
		prev = new Point(x - w / 2, y - h / 2);
		
		dimension = new Point(w, h);
		
		sprite = new Sprite() {
		
			private final Image[] PLAYER = new Image[20];
			private final Image[] MUZZLE = new Image[16];

			{
				// load the images
				for (int i = 0; i < PLAYER.length; i++) {
					PLAYER[i] = new Image("file:assets\\rifle\\idle\\survivor-idle_rifle_" + i + ".png");
				}
						
				for (int i = 0; i < MUZZLE.length; i++) {
					MUZZLE[i] = new Image("file:assets\\muzzle_flashs\\m_" + i + ".png");
				}
			}

			public void draw(GraphicsContext gc) {
				gc.save();
				
				gc.setTransform(rotationPlayer.getMxx(), rotationPlayer.getMyx(), rotationPlayer.getMxy(),
						rotationPlayer.getMyy(), rotationPlayer.getTx(), rotationPlayer.getTy());
				
				if (input.leftClicked() && input.getPlayerNumber() == Player.PLAYER1) {
					gc.drawImage(MUZZLE[(int) muzzleFrame], getRifleMuzzleX() - 8, getRifleMuzzleY() - 25, 50, 50);
					// this number is how fast the next frame of fire animation will be drawn. The
					// higher the faster.
					muzzleFrame += .5;
				}
				
				if (input.rightClicked() && input.getPlayerNumber() == Player.PLAYER2) {
					gc.drawImage(MUZZLE[(int) muzzleFrame], getRifleMuzzleX() - 8, getRifleMuzzleY() - 25, 50, 50);
					// this number is how fast the next frame of fire animation will be drawn. The
					// higher the faster.
					muzzleFrame += .5;
				}
				
				gc.drawImage(PLAYER[(int) playerFrame], pos.x(), pos.y(), dimension.x(), dimension.y());
				gc.restore();
				
				playerFrame += 0.25;
				
				if (playerFrame >= PLAYER.length) {
					playerFrame = 0;
				}
				if (muzzleFrame >= MUZZLE.length || (!input.leftClicked() && input.getPlayerNumber()==Player.PLAYER1)) {
					muzzleFrame = 0;
				}
				if (muzzleFrame >= MUZZLE.length || (!input.rightClicked() && input.getPlayerNumber()==Player.PLAYER2)) {
					muzzleFrame = 0;
				}
			}
		};

		double size = h * .74;
		hitbox = new HitBox().setBounds(pos.x() + dimension.x() * .303 - size / 2,
				pos.y() + dimension.y() * .58 - size / 2, size, size);
	}

	public Player setMap(CanvasMap map) {
		this.map = map;
		return this;
	}

	public double getPlayerCenterX() {
		return pos.x() + dimension.x() * .303;

	}

	public double getPlayerCenterY() {
		return pos.y() + dimension.y() * .58;

	}

	public double getRifleMuzzleX() {
		return pos.x() + dimension.x() * .93;

	}

	public double getRifleMuzzleY() {
		return pos.y() + dimension.y() * .73;

	}

	
	public void calculateAngles() {
		angle = Math.toDegrees(Math.atan2(input.y() - getPlayerCenterY(), input.x() - getPlayerCenterX()));
		rotationPlayer.setAngle(angle);
		rotationPlayer.setPivotX(getPlayerCenterX());
		rotationPlayer.setPivotY(getPlayerCenterY());
	}


	public void stepBack() {
		hitbox.undoTranslate();
		pos.move(prev);
	}

	public PlayerInput getInput() {
		return input;
	}

	public Player setInput(PlayerInput input) {
		this.input = input;
		return this;
	}

	@Override
	/**
	 * update the entity
	 */

	public void update() {
		calculateAngles();
		// old version move
		if (input.hasMoved()) {
			double speed = input.isShift() ? 5 : 2.4;

			double dx = input.leftOrRight() * speed;
			double dy = input.upOrDown() * speed;

			prev.move(pos);
			pos.translate(dx, dy);
			hitbox.translate(dx, dy);
		}
		
//		if (input.hasMoved()) {
//			double speed = input.isShift() ? 5 : 1;
//
//			double dx = input.leftOrRight() * speed;
//			double dy = input.upOrDown() * speed;
//			if(input.isUp()) {
//				Point p = new Point();
//				
//				p=p.pointXY(pos, new Point(input.x(),input.y()), 2);
//				if(Math.abs(p.x())>0.0001)			
//					dx = (p.x() - pos.x())*speed;
//				if(Math.abs(p.y())>0.0001)
//					dy = (p.y() - pos.y())*speed;
//			}
//	
//			prev.move(pos);
//			pos.translate(dx, dy);
//			hitbox.translate(dx, dy);
//		}
		
		if(input.getPlayerNumber() == Player.PLAYER1) {
			if(!weapon1 && input.isChangeWeapon1()) {
				weapon1 = true;
				weapon2 = false;
				weapon3 = false;
			}
			if(!weapon2 && input.isChangeWeapon2()) {
				weapon2 = true;
				weapon1 = false;
				weapon3 = false;
			}
			if(!weapon3 && input.isChangeWeapon3()) {
				weapon3 = true;
				weapon2 = false;
				weapon1 = false;
			}
		}
		
		if(input.getPlayerNumber() == Player.PLAYER2) {
			if(!weapon1 && input.isChangeWeapon1()) {
				weapon1 = true;
				weapon2 = false;
				weapon3 = false;
			}
			if(!weapon2 && input.isChangeWeapon2()) {
				weapon2 = true;
				weapon1 = false;
				weapon3 = false;
			}
			if(!weapon3 && input.isChangeWeapon3()) {
				weapon3 = true;
				weapon2 = false;
				weapon1 = false;
			}
		}
			
		// player1
		if (input.leftClicked() && input.getPlayerNumber() == Player.PLAYER1 && weapon1) {
			Point2D muzzle = rotationPlayer.transform(getRifleMuzzleX(), getRifleMuzzleY());
			map.fireBullet(new Bullet(this.angle, muzzle.getX(), muzzle.getY()));
		}
		if (input.leftClicked() && input.getPlayerNumber() == Player.PLAYER1 && weapon2) {
			Point2D muzzle = rotationPlayer.transform(getRifleMuzzleX(), getRifleMuzzleY());
			map.fireBullet(new Bullet(this.angle, muzzle.getX(), muzzle.getY()));
			map.fireBullet(new Bullet(this.angle+30/Math.PI/2, muzzle.getX(), muzzle.getY()));
			map.fireBullet(new Bullet(this.angle+60/Math.PI/2, muzzle.getX(), muzzle.getY()));
			map.fireBullet(new Bullet(this.angle+90/Math.PI/2, muzzle.getX(), muzzle.getY()));
			map.fireBullet(new Bullet(this.angle+120/Math.PI/2, muzzle.getX(), muzzle.getY()));
			map.fireBullet(new Bullet(this.angle-30/Math.PI/2, muzzle.getX(), muzzle.getY()));
			map.fireBullet(new Bullet(this.angle-60/Math.PI/2, muzzle.getX(), muzzle.getY()));
			map.fireBullet(new Bullet(this.angle-90/Math.PI/2, muzzle.getX(), muzzle.getY()));
			map.fireBullet(new Bullet(this.angle-120/Math.PI/2, muzzle.getX(), muzzle.getY()));
		}		
	}

	@Override
	public boolean isDrawable() {
		return true;
	}

	@Override
	public boolean hasHitbox() {
		return true;
	}

	@Override
	public HitBox getHitBox() {
		return hitbox;
	}

	@Override
	public Sprite getDrawable() {
		return sprite;
	}

	public boolean isWeapon1() {
		return weapon1;
	}

	public void setWeapon1(boolean weapon1) {
		this.weapon1 = weapon1;
	}

	public boolean isWeapon2() {
		return weapon2;
	}

	public void setWeapon2(boolean weapon2) {
		this.weapon2 = weapon2;
	}

	public boolean isWeapon3() {
		return weapon3;
	}

	public void setWeapon3(boolean weapon3) {
		this.weapon3 = weapon3;
	}
}
