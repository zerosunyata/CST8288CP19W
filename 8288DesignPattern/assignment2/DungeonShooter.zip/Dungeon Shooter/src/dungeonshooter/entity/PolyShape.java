package dungeonshooter.entity;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import dungeonshooter.entity.geometry.RectangleBounds;
import dungeonshooter.entity.property.Drawable;
import dungeonshooter.entity.property.HitBox;
import dungeonshooter.entity.property.Sprite;
import java.util.Map.Entry;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import utility.Point;
import utility.RandUtil;

public class PolyShape implements Entity{

	private int pointCount;
	private double [][] points;
	private double minX;
	private double minY;
	private double maxX;
	private double maxY;
	
	private RectangleBounds bounds; 
	private HitBox hitbox;
	private Sprite sprite;


	public PolyShape(){
		
		
		hitbox = new HitBox(){
			protected boolean hasIntersectFull(){
				return true;
			}
			protected double[][] getPoints(){
				return points;
			}
		};		
		sprite = new Sprite(){
			{
				// bonus part
				setFill( new ImagePattern( new Image( "file:assets/concrete/dsc_1621.png")));
			}
			public void draw( GraphicsContext gc){
				gc.setLineWidth( getWidth());
				if( getStroke() != null){
					gc.setStroke( getStroke());
					gc.strokePolygon( points[0], points[1], pointCount);
				}
				if( getFill() != null){
					gc.setFill( getFill());
					gc.fillPolygon( points[0], points[1], pointCount);
				}
			}
		};
	}

	
	public PolyShape setPoints(double... nums ){
	
		minX = maxX = nums[0];
		minY = maxY = nums[1];
		
		pointCount = nums.length / 2;
		
		points = new double[2][pointCount];	
		
		for (int i=0,j=0;i<nums.length;j++,i+=2){
			
			updateMinMax(nums[i],nums[i+1]);
			points[0][j]=nums[i];
			points[1][j]=nums[i+1];
		}
		
		hitbox.setBounds(minX, minY, maxX-minX, maxY-minY);
		return this ;
	}

	
	public PolyShape randomize(double centerX, double centerY, double size, int minPoints, int maxPoints){      
		
		Point centerPoint = new Point(centerX, centerY);		

		int pointNum = RandUtil.getInt(minPoints, maxPoints);
		double nums[] = new double[pointNum * 2];

	
		SortedMap <Double, Point> sortedM = new TreeMap <Double, Point>();
		for (int i = 0; i < pointNum; i++) {
			Point randomPoint = centerPoint.random (size, size + 60);
			
			sortedM.put(new Double (centerPoint.angle (randomPoint)), randomPoint);
		}

		
		Set<Entry<Double, Point>> set = sortedM.entrySet();
		Iterator<Entry<Double, Point>> iterator = set.iterator();
		int counter = 0;
		while (iterator.hasNext()) {
			Map.Entry<Double, Point> map = (Map.Entry<Double, Point>) iterator.next();
			Point point = (Point) map.getValue();
			nums[counter] = point.x();
			nums[counter + 1] = point.y();
			counter=counter+2;
		}

		
		minX = maxX = nums[0];
		minY = maxY = nums[1];
		pointCount = nums.length / 2;	
		points = new double[2][pointCount];	
		for (int i=0, j=0; i<nums.length; j++, i+=2) {
			updateMinMax(nums[i], nums[i+1]);
			points[0][j] = nums[i];
			points[1][j] = nums[i+1];
		}	
		
		hitbox.setBounds(minX, minY, maxX-minX, maxY-minY);
		return this;
	}

	
	public void updateMinMax(double x, double y){
		if(x < minX ) {		
			minX = x;
		}
		else if (x > maxX) {
			maxX = x; 
		}	
		if(y < minY ) {		
			minY = y;
		}
		else if (y > maxY) {
			maxY = y; 
		}
	}

	public int pointCount(){
		return pointCount;
	}
	public double [][] points(){
		return points;
	}

	
	public double pX( int index){
		return points[0][index];

	}
	public double pY(int index){
		return points[1][index];   
	}


	@Override
	public void update() {

	}

	@Override
	public boolean hasHitbox() {
		return true;
	}

	@Override
	public HitBox getHitBox() {	
		return hitbox;
	}

	@Override
	public boolean isDrawable() {
		return true;
	}

	@Override
	public Sprite getDrawable() {
		return sprite;
	}
}
