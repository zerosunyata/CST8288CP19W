package dungeonshooter;


import java.util.List;
import java.util.ArrayList;
import javafx.beans.property.BooleanProperty;
import javafx.scene.canvas.Canvas;
import javafx.animation.AnimationTimer;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import dungeonshooter.CanvasMap;
import dungeonshooter.animator.AbstractAnimator;
import dungeonshooter.entity.Bullet;
import dungeonshooter.entity.Entity;
import dungeonshooter.entity.PolyShape;
import dungeonshooter.entity.property.HitBox;


public class CanvasMap{

	private Canvas map;	
	private BooleanProperty drawBounds;
	private BooleanProperty drawFPS;
	private BooleanProperty drawScore;
	private List<Entity> players;
	private List<Entity> projectiles; 
	private PolyShape border;
	private AbstractAnimator animator;
	private List<Entity> buffer;
	private List<PolyShape> staticShapes;

	
	public CanvasMap() {
		map = new Canvas();
		drawFPS = new SimpleBooleanProperty(false);		
		drawScore = new SimpleBooleanProperty(false);		
		drawBounds = new SimpleBooleanProperty(true);		
		
		players = new ArrayList<Entity>(1);
		
		projectiles = new ArrayList<Entity>(500);
		
		buffer = new ArrayList<Entity>(500);
		
		staticShapes = new ArrayList<PolyShape>(50);	
		border = new PolyShape();
		//// add image change png bonus
		border.getDrawable().setFill(new ImagePattern(new Image("file:assets/floor/pavin.png"),0,0,256,256,false));
	}

	/**
	 * create the property class variables functions here
	 */
	public BooleanProperty drawFPSProperty() {
		return drawFPS;	
	}
	public boolean getDrawFPS() {
		return drawFPS.get();		
	}
	
	public BooleanProperty drawScoreProperty() {
		return drawScore;	
	}
	public boolean getDrawScore() {
		return drawScore.get();		
	}
	
	public BooleanProperty drawBoundsProperty() {
		return drawBounds;		
	}
	public boolean getDrawBounds() {
		return drawBounds.get();
	}

	//setDrawingCanvas sets the new canvas.
	public CanvasMap setDrawingCanvas(Canvas map) {
		
		if( map == null) {
			throw new NullPointerException();
		}

		
		this.map = map;
		this.map.widthProperty().addListener((v, o, n)-> border.setPoints( 0,0, w(),0, w(),h(), 0,h()));	
		this.map.heightProperty().addListener((v, o, n)-> border.setPoints( 0,0, w(),0, w(),h(), 0,h()));		
		
		return this;		
	}
	
	/**
	 * create a method called setAnimator.
	 * set an {@link AbstractAnimator}. if an animator exists {@link CanvasMap#stop()} it and 
	 * call {@link CanvasMap#removeMouseEvents()}. then set the new animator and
	 * call {@link CanvasMap#start()} and {@link CanvasMap#registerMouseEvents()}.
	 * @param newAnimator - new {@link AbstractAnimator} object 
	 * @return the current instance of this object
	 */
	public CanvasMap setAnimator(AbstractAnimator newAnimator) {
		if( animator != null){
			stop();
			
		}
		animator = newAnimator;

		return this;
	}

	/**
	 * create a method called start.
	 * start the animator. {@link AnimationTimer#start()}
	 */
	public void start() {
		animator.start();		
	}

	/**
	 * create a method called stop.
	 * stop the animator. {@link AnimationTimer#stop()}
	 */
	public void stop() {
		animator.stop();
	}

	/**
	 * create a method called getCanvas.
	 * get the JavaFX {@link Canvas} node 
	 * @return {@link Canvas} node 
	 */
	public Canvas getCanvas() {
		return map;		
	}

	/**
	 * create a method called gc.
	 * get the {@link GraphicsContext} of {@link Canvas} that allows direct drawing.
	 * @return {@link GraphicsContext} of {@link Canvas}
	 */
	public GraphicsContext gc() {
		return map.getGraphicsContext2D();
	}

	/**
	 * create a method called w.
	 * get the height of the map, {@link Canvas#getHeight()}
	 * @return height of canvas
	 */
	public double h() {
		return map.getHeight();
	}

	/**
	 * create a method called w.
	 * get the width of the map, {@link Canvas#getWidth()}
	 * @return width of canvas
	 */
	public double w() {
		return map.getWidth();
	}

	public List<PolyShape> staticShapes(){
		return staticShapes;
	}

	public List<Entity> players(){
		return players;
	}

	public List<Entity> projectiles(){
		return projectiles;
	}

	public CanvasMap addSampleShapes() {
	
		// bonus part 
		staticShapes.add(new PolyShape().randomize(150, 510, 25, 5, 30));
		staticShapes.add(new PolyShape().randomize(150, 300, 25, 5, 30));
		
		staticShapes.add(new PolyShape().randomize(350, 100, 25, 5, 30));
		staticShapes.add(new PolyShape().randomize(620, 100, 25, 5, 30));
		staticShapes.add(new PolyShape().randomize(620, 300, 25, 5, 30));
		
		
		return this;
	}
	
	public void fireBullet(Bullet bullet ) {		
		 buffer.add(bullet);		  	   	 
	}
	
	
	public void updateProjectilesList() {  
		projectiles.addAll( buffer);
		buffer.clear();
	}

	public PolyShape getMapShape() {
		return border;
	}

  
	public boolean inMap(HitBox hitbox) {
		return border.getHitBox().containsBounds(hitbox);
	}

	public<E extends Event> void addEventHandler(EventType<E>event, EventHandler<E> handler) {
		
		map.addEventHandler(event, handler);
		
	}
}