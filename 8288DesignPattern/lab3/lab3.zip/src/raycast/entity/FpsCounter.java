package raycast.entity;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

/**
 * FpsCounter create this class inside of entity package.
 */
public class FpsCounter implements DrawableObject<FpsCounter> {
	public static final double ONE_SECOND = 1000000000L;
	public static final double HALF_SECOND = ONE_SECOND / 2f;

	private Font fpsFont;
	private String fpsDisplay;
	private int frameCount;
	private double lastTime;
	private double strokeWidth;
	private Color fill;
	private double x;
	private double y;
	private Color stroke;

	/*
	 * constructor needs to setPos and setFont. for font use Font.font(
	 * Font.getDefault().getFamily(), FontWeight.BLACK, 24).
	 */
	public FpsCounter(double x, double y) {
		setPos(x, y);
		setFont(Font.font(Font.getDefault().getFamily(), FontWeight.BLACK, 24));
	}

	/**
	 * 
	 * calculateFPS needs to update the frame count.
	 * 
	 * @param now
	 */
	public void calculateFPS(long now) {
		// 1. in an if condition check if now - lastTime is bigger than HALF_SECOND
		if (now - lastTime >= HALF_SECOND) {
			// 1. assign frameCount*2 to fpsDisplay
			fpsDisplay = Integer.toString(frameCount * 2);
			// 2. set frameCount to 0
			frameCount = 0;
			// 3. set lastTime to now
			lastTime = now;
		}
		// 2. increment frameCount
		frameCount++;
	}

	/**
	 * draw needs to draw the current fps on canvas.
	 */
	@Override
	public void draw(GraphicsContext gc) {
		// 1. get font from gc and save it in a temp variable so we can set it back
		// later
		Font font = gc.getFont();
		// 2. set fpsFont as font on gc
		gc.setFont(fpsFont);
		// 3. call setFill on gc and pass fill
		gc.setFill(fill);
		// 4. call fillText on gc and pass fpsDisplay, x and y
		gc.fillText(fpsDisplay, x, y);
		// 5. call setStroke on gc and pass stroke
		gc.setStroke(stroke);
		// 6. call setLineWidth on gc and pass strokeWidth
		gc.setLineWidth(strokeWidth);
		// 7. call strokeText on gc and pass fpsDisplay, x and y
		gc.strokeText(fpsDisplay, x, y);
		// 8. call setFont on gc and pass to it the temp font you created
		gc.setFont(font);
	}

	@Override
	public Color getFill() {
		return fill;
	}

	@Override
	public Color getStroke() {
		return stroke;
	}

	@Override
	public double getWidth() {
		return strokeWidth;
	}

	@Override
	public FpsCounter setFill(Color color) {
		fill = color;
		return this;
	}

	public FpsCounter setFont(Font font) {
		this.fpsFont = font;
		return this;
	}

	public FpsCounter setPos(double x, double y) {
		this.x = x;
		this.y = y;
		return this;
	}

	@Override
	public FpsCounter setStroke(Color color) {
		stroke = color;
		return this;
	}

	@Override
	public FpsCounter setWidth(double width) {
		strokeWidth = width;
		return this;
	}
}
