package raycast;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import raycast.animator.AbstractAnimator;

/**
 * this is the new animator even though it will not have any moving pieces. make
 * sure to properly name it in toString.
 */
public class StaticShapes extends AbstractAnimator {
	private static final Color BACKGROUND = Color.BLACK;
	// private static final Color BACKGROUND = Color.AQUA;
	//private static final Color BACKGROUND = Color.BLUE;

	/**
	 * handle
	 * 
	 * @param now
	 * @param gc
	 */
	@Override
	public void handle(long now, GraphicsContext gc) {
		// 1. call clearAndFill and pass gc and color of your choice
		clearAndFill(gc, BACKGROUND);
		// 2. for each shape in c.shapes() call draw and pass gc
		for (PolyShape shape : c.shapes()) {
			shape.draw(gc);
		}
	}

	@Override
	public String toString() {
		return "StaticShapes [toString()=" + super.toString() + "]";
	}
}
